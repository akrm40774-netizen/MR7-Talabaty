package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.viewmodel.MainViewModel
import com.example.ui.components.RtlProvider
import com.example.ui.components.UserAvatar

val CurrencyOptions = listOf("ج.م", "ر.س", "د.إ", "د.ك", "ر.ع", "ر.ق", "د.أ", "$", "€")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit,
    onNavigateToAccount: () -> Unit = {},
    onNavigateToStores: () -> Unit = {},
    onNavigateToCategories: () -> Unit = {},
    onNavigateToBills: () -> Unit = {},
    onNavigateToHelp: () -> Unit = {},
    onNavigateToAbout: () -> Unit = {},
    onNavigateToAdmin: () -> Unit = {}
) {
    val context = LocalContext.current
    val settings by viewModel.settingsState.collectAsState()
    val currentUser by viewModel.currentUserState.collectAsState()

    var currencyDropdownExpanded by remember { mutableStateOf(false) }

    var showBackupDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }

    var showRestoreDialog by remember { mutableStateOf(false) }
    var importJsonText by remember { mutableStateOf("") }

    var showPasswordChangeDialog by remember { mutableStateOf(false) }
    var newPasswordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var passwordChangeError by remember { mutableStateOf<String?>(null) }

    var notificationsEnabled by remember { mutableStateOf(true) }
    var pantryAlertsEnabled by remember { mutableStateOf(true) }

    val isSuperAdminOrAdmin = currentUser?.id == 777L || currentUser?.role == "SUPER_ADMIN" || currentUser?.role == "ADMIN"

    RtlProvider {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "الإعدادات العامة",
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.testTag("btn_back")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // 1. Account Summary Card
                item {
                    val cardShape = RoundedCornerShape(22.dp)
                    Card(
                        shape = cardShape,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(cardShape)
                            .clickable { onNavigateToAccount() }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                UserAvatar(
                                    avatarUri = currentUser?.avatarUri,
                                    size = 56.dp,
                                    borderWidth = 2.dp,
                                    borderColor = MaterialTheme.colorScheme.primary
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = currentUser?.name ?: "مستخدم MR7",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = currentUser?.email ?: "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isSuperAdminOrAdmin) Color(0xFFFEF3C7) else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.padding(top = 2.dp)
                                    ) {
                                        Text(
                                            text = if (currentUser?.role == "SUPER_ADMIN") "👑 المشرف الأساسي" else if (currentUser?.role == "ADMIN") "🛡️ مسؤول إدارة" else "👤 مستخدم",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSuperAdminOrAdmin) Color(0xFFB45309) else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                contentDescription = "فتح الملف الشخصي",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                // 2. Appearance & Customization Section
                item {
                    SettingsSectionCard(title = "🎨 المظهر والتخصيص") {
                        // Dark Theme Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                SectionIcon(Icons.Default.DarkMode, Color(0xFF6366F1))
                                Column {
                                    Text("الوضع الداكن (Dark Mode)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("واجهة ليلية مريحة للعينين وحافظة للبطارية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Switch(
                                checked = settings.darkTheme,
                                onCheckedChange = { viewModel.updateTheme(it) }
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // Currency Selector
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                SectionIcon(Icons.Default.Paid, Color(0xFF10B981))
                                Column {
                                    Text("رمز العملة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("تحديد العملة المستخدمة في الفواتير والأسعار", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            ExposedDropdownMenuBox(
                                expanded = currencyDropdownExpanded,
                                onExpandedChange = { currencyDropdownExpanded = !currencyDropdownExpanded }
                            ) {
                                OutlinedTextField(
                                    value = settings.currency,
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = currencyDropdownExpanded) },
                                    modifier = Modifier
                                        .width(105.dp)
                                        .menuAnchor(),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                ExposedDropdownMenu(
                                    expanded = currencyDropdownExpanded,
                                    onDismissRequest = { currencyDropdownExpanded = false }
                                ) {
                                    CurrencyOptions.forEach { curr ->
                                        DropdownMenuItem(
                                            text = { Text(curr, fontWeight = FontWeight.Bold) },
                                            onClick = {
                                                viewModel.updateCurrency(curr)
                                                currencyDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // Language Display
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                SectionIcon(Icons.Default.Language, Color(0xFF0284C7))
                                Column {
                                    Text("لغة التطبيق", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("اللغة المفضلة لواجهة المستخدم", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "العربية (افتراضي)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                // 3. Notifications Section
                item {
                    SettingsSectionCard(title = "🔔 الإشعارات والتنبيهات") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                SectionIcon(Icons.Default.Notifications, Color(0xFFF59E0B))
                                Column {
                                    Text("تنبيهات التسوق والقوائم", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("تذكير بالقوائم النشطة عند مغادرة المنزل", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Switch(
                                checked = notificationsEnabled,
                                onCheckedChange = { notificationsEnabled = it }
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                SectionIcon(Icons.Default.CleaningServices, Color(0xFFEC4899))
                                Column {
                                    Text("إنذار قرب نفاد المخزون", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("إشعار عند وصول منتج للحد الأدنى في المخزن", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Switch(
                                checked = pantryAlertsEnabled,
                                onCheckedChange = { pantryAlertsEnabled = it }
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        OutlinedButton(
                            onClick = {
                                Toast.makeText(context, "🔔 تجربة: نظام التنبيهات في MR7 طلباتي يعمل بكفاءة!", Toast.LENGTH_LONG).show()
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إرسال إشعار تجريبي", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // 4. Quick Content Management
                item {
                    SettingsSectionCard(title = "📦 إدارة المحتوى والمتاجر") {
                        SettingsNavRow(
                            title = "إدارة المتاجر وأماكن التسوق",
                            subtitle = "إضافة وتعديل فروع المتاجر وأماكنها",
                            icon = Icons.Default.Store,
                            iconColor = Color(0xFF059669),
                            onClick = onNavigateToStores
                        )

                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        SettingsNavRow(
                            title = "إدارة التصنيفات والألوان",
                            subtitle = "ترتيب أقسام المنتجات ورموزها",
                            icon = Icons.Default.Category,
                            iconColor = Color(0xFF6366F1),
                            onClick = onNavigateToCategories
                        )

                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        SettingsNavRow(
                            title = "سجل الفواتير والمشتريات",
                            subtitle = "مراجعة تقارير الشراء السابقة وإجمالي الإنفاق",
                            icon = Icons.Default.ReceiptLong,
                            iconColor = Color(0xFF8B5CF6),
                            onClick = onNavigateToBills
                        )
                    }
                }

                // 5. Data & Backup Section
                item {
                    SettingsSectionCard(title = "💾 النسخ الاحتياطي واستعادة البيانات") {
                        Text(
                            text = "احفظ نسخة من بياناتك وقوائمك ومخزونك لنقلها أو استرجاعها بسهولة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.exportBackup { json ->
                                        backupJsonText = json
                                        showBackupDialog = true
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("تصدير نسخة JSON")
                            }

                            OutlinedButton(
                                onClick = { showRestoreDialog = true },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("استعادة نسخة")
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        OutlinedButton(
                            onClick = {
                                Toast.makeText(context, "🧹 تم تنظيف الذاكرة المؤقتة وضغط التخزين المحلي بنجاح", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تنظيف الذاكرة المؤقتة (Clear Cache)")
                        }
                    }
                }

                // 6. Privacy & Security
                item {
                    SettingsSectionCard(title = "🔒 الخصوصية والأمان") {
                        SettingsNavRow(
                            title = "تغيير كلمة المرور",
                            subtitle = "تحديث كلمة سر حسابك الحالية لحماية أكبر",
                            icon = Icons.Default.Lock,
                            iconColor = Color(0xFFD97706),
                            onClick = { showPasswordChangeDialog = true }
                        )

                        if (isSuperAdminOrAdmin) {
                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                            SettingsNavRow(
                                title = "لوحة تحكم الأدمن (MR7 Control)",
                                subtitle = "إدارة الحسابات، الصلاحيات، والعمليات الإدارية",
                                icon = Icons.Default.Security,
                                iconColor = Color(0xFFDC2626),
                                onClick = onNavigateToAdmin
                            )
                        }
                    }
                }

                // 7. Help & About Section
                item {
                    SettingsSectionCard(title = "ℹ️ المساعدة والمعلومات") {
                        SettingsNavRow(
                            title = "مركز مساعدة MR7 طلباتي",
                            subtitle = "دليل الاستخدام، البدء السريع، والأسئلة الشائعة",
                            icon = Icons.Default.HelpOutline,
                            iconColor = Color(0xFF2563EB),
                            onClick = onNavigateToHelp
                        )

                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        SettingsNavRow(
                            title = "حول التطبيق ورقم الإصدار",
                            subtitle = "الإصدار v2.5.0 • مطور بواسطة MR7",
                            icon = Icons.Default.Info,
                            iconColor = Color(0xFF475569),
                            onClick = onNavigateToAbout
                        )
                    }
                }

                // 8. Logout
                item {
                    val logoutShape = RoundedCornerShape(16.dp)
                    Card(
                        shape = logoutShape,
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(logoutShape)
                            .clickable {
                                viewModel.logout()
                                onBackClick()
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "تسجيل الخروج",
                                tint = Color(0xFFDC2626)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تسجيل الخروج من الحساب",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            // Change Password Dialog
            if (showPasswordChangeDialog) {
                AlertDialog(
                    onDismissRequest = {
                        showPasswordChangeDialog = false
                        passwordChangeError = null
                        newPasswordInput = ""
                        confirmPasswordInput = ""
                    },
                    title = { Text("تغيير كلمة المرور") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            passwordChangeError?.let { err ->
                                Text(err, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                            }
                            OutlinedTextField(
                                value = newPasswordInput,
                                onValueChange = { newPasswordInput = it },
                                label = { Text("كلمة المرور الجديدة") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = confirmPasswordInput,
                                onValueChange = { confirmPasswordInput = it },
                                label = { Text("تأكيد كلمة المرور الجديدة") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                if (newPasswordInput.length < 6) {
                                    passwordChangeError = "كلمة المرور يجب أن لا تقل عن 6 أحرف"
                                    return@Button
                                }
                                if (newPasswordInput != confirmPasswordInput) {
                                    passwordChangeError = "كلمتا المرور غير متطابقتين"
                                    return@Button
                                }
                                currentUser?.email?.let { email ->
                                    viewModel.resetPassword(email, newPasswordInput) {
                                        Toast.makeText(context, "تم تغيير كلمة المرور بنجاح!", Toast.LENGTH_SHORT).show()
                                        showPasswordChangeDialog = false
                                    }
                                }
                            }
                        ) {
                            Text("تحديث")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showPasswordChangeDialog = false }) {
                            Text("إلغاء")
                        }
                    }
                )
            }

            // Export Backup Dialog
            if (showBackupDialog) {
                AlertDialog(
                    onDismissRequest = { showBackupDialog = false },
                    title = { Text("نسخة احتياطية من البيانات") },
                    text = {
                        Column {
                            Text("تم إنشاء كود JSON لقاعدة البيانات. يمكنك نسخه وحفظه:")
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = backupJsonText,
                                onValueChange = {},
                                readOnly = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                val clip = android.content.ClipData.newPlainText("MR7_Backup", backupJsonText)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "تم نسخ البيانات إلى الحافظة بنجاح", Toast.LENGTH_SHORT).show()
                                showBackupDialog = false
                            }
                        ) {
                            Text("نسخ إلى الحافظة")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showBackupDialog = false }) {
                            Text("إغلاق")
                        }
                    }
                )
            }

            // Import Backup Dialog
            if (showRestoreDialog) {
                AlertDialog(
                    onDismissRequest = { showRestoreDialog = false },
                    title = { Text("استعادة نسخة احتياطية") },
                    text = {
                        Column {
                            Text("الصق كود JSON الخاص بالنسخة الاحتياطية هنا:")
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = importJsonText,
                                onValueChange = { importJsonText = it },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.importBackup(importJsonText)
                                showRestoreDialog = false
                            },
                            enabled = importJsonText.isNotBlank()
                        ) {
                            Text("استعادة البيانات")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showRestoreDialog = false }) {
                            Text("إلغاء")
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            content()
        }
    }
}

@Composable
private fun SectionIcon(icon: ImageVector, color: Color) {
    Surface(
        shape = CircleShape,
        color = color.copy(alpha = 0.12f),
        modifier = Modifier.size(36.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun SettingsNavRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit
) {
    val rowShape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(rowShape)
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            SectionIcon(icon, iconColor)
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
            contentDescription = "فتح",
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
