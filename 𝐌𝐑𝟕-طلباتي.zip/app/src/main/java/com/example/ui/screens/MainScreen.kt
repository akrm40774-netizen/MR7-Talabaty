package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.viewmodel.MainViewModel
import com.example.ui.components.CurrencyFormatter
import com.example.ui.components.RtlProvider
import com.example.ui.components.UserAvatar
import com.example.ui.theme.GradientEnd
import com.example.ui.theme.GradientMiddle
import com.example.ui.theme.GradientStart
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MissingProductSample(
    val id: Int,
    val name: String,
    val countBadge: Int,
    val iconEmoji: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current

    val currentUser by viewModel.currentUserState.collectAsState()
    val activeLists by viewModel.activeListsState.collectAsState()
    val products by viewModel.productsState.collectAsState()
    val stores by viewModel.storesState.collectAsState()
    val categories by viewModel.categoriesState.collectAsState()
    val bills by viewModel.billsState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()
    val pantryItems by viewModel.pantryItemsState.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    // 0: الرئيسية, 1: القوائم, 2: المنتجات, 3: الإحصائيات, 4: المزيد
    var selectedBottomTab by remember { mutableIntStateOf(0) }
    var showNotificationsDialog by remember { mutableStateOf(false) }

    // Intercept Back Press to return to Home Tab
    BackHandler(enabled = selectedBottomTab != 0) {
        selectedBottomTab = 0
    }

    // Dynamic stats
    val totalSpent = remember(bills) { bills.sumOf { it.totalCost } }
    val lastActiveList = activeLists.firstOrNull()

    // Missing products
    val missingProducts = remember(pantryItems, products) {
        val fromPantry = pantryItems.filter { it.currentQuantity <= it.minLimit }.map { item ->
            MissingProductSample(
                id = item.id.toInt(),
                name = item.name,
                countBadge = 1,
                iconEmoji = "🛒"
            )
        }
        if (fromPantry.isNotEmpty()) {
            fromPantry
        } else {
            products.take(5).map { p ->
                MissingProductSample(
                    id = p.id.toInt(),
                    name = p.name,
                    countBadge = 1,
                    iconEmoji = "🛒"
                )
            }
        }
    }

    RtlProvider {
        Scaffold(
            floatingActionButton = {
                // Show FAB on Home or Lists tab
                if (selectedBottomTab == 0 || selectedBottomTab == 1) {
                    FloatingActionButton(
                        onClick = { onNavigate("create_list") },
                        shape = CircleShape,
                        containerColor = Color(0xFF2563EB),
                        contentColor = Color.White,
                        elevation = FloatingActionButtonDefaults.elevation(8.dp),
                        modifier = Modifier
                            .size(58.dp)
                            .testTag("btn_create_list_fab")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "إنشاء قائمة",
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
            },
            bottomBar = {
                // Custom Bottom Bar in the style of MR7 ممرضي:
                // Icon on top, title below, no overlap, fixed bottom, proper insets
                MR7BottomNavigationBar(
                    selectedTab = selectedBottomTab,
                    onTabSelected = { selectedBottomTab = it }
                )
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Smooth AnimatedContent page transitions between sections within the same app shell
                AnimatedContent(
                    targetState = selectedBottomTab,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally { width -> width / 3 } + fadeIn()).togetherWith(
                                slideOutHorizontally { width -> -width / 3 } + fadeOut()
                            )
                        } else {
                            (slideInHorizontally { width -> -width / 3 } + fadeIn()).togetherWith(
                                slideOutHorizontally { width -> width / 3 } + fadeOut()
                            )
                        }
                    },
                    label = "TabContentAnimation"
                ) { targetTab ->
                    when (targetTab) {
                        0 -> {
                            // Home Tab Content
                            HomeScreenDashboard(
                                viewModel = viewModel,
                                currentUser = currentUser,
                                activeLists = activeLists,
                                products = products,
                                stores = stores,
                                settings = settings,
                                totalSpent = totalSpent,
                                lastActiveList = lastActiveList,
                                missingProducts = missingProducts,
                                onNavigate = onNavigate,
                                onOpenNotifications = { showNotificationsDialog = true },
                                onTabSelect = { selectedBottomTab = it }
                            )
                        }
                        1 -> {
                            // Lists Tab Content (embedded directly!)
                            ShoppingListsScreen(
                                viewModel = viewModel,
                                onBackClick = { selectedBottomTab = 0 },
                                onOpenList = { listId -> onNavigate("shopping_active/$listId") },
                                onCreateNewClick = { onNavigate("create_list") }
                            )
                        }
                        2 -> {
                            // Products Tab Content (embedded directly!)
                            ProductsScreen(
                                viewModel = viewModel,
                                onBackClick = { selectedBottomTab = 0 }
                            )
                        }
                        3 -> {
                            // Statistics Tab Content (embedded directly!)
                            StatisticsScreen(
                                viewModel = viewModel,
                                onBackClick = { selectedBottomTab = 0 }
                            )
                        }
                        4 -> {
                            // More Menu / Sections Tab Content
                            MoreSectionsScreen(
                                viewModel = viewModel,
                                categoriesCount = categories.size,
                                pantryCount = pantryItems.size,
                                onNavigate = onNavigate,
                                onBackClick = { selectedBottomTab = 0 }
                            )
                        }
                    }
                }
            }

            // Notifications Dialog
            if (showNotificationsDialog) {
                AlertDialog(
                    onDismissRequest = { showNotificationsDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("مركز الإشعارات والتنبيهات", fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            NotificationItem("🔔 تنبيه مشتريات", "قائمتك النشطة تحتوي على منتجات غير مشتراة بعد.", "منذ 10 دقائق")
                            NotificationItem("📦 المخزون المنزلي", "أحد المنتجات وصل للحد الأدنى، هل ترغب بشرائه؟", "منذ ساعة")
                            NotificationItem("✨ اقتراح MR7", "تذكير بشراء المخبوزات الطازجة لعطلة نهاية الأسبوع.", "اليوم")
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showNotificationsDialog = false }) {
                            Text("إغلاق")
                        }
                    }
                )
            }
        }
    }
}

/**
 * Custom Bottom Navigation Bar styled after MR7 ممرضي:
 * - Icon strictly on top
 * - Category / screen name strictly below the icon
 * - Generous spacing (4dp) preventing text/icon overlap
 * - Fixed bottom with proper navigationBarsPadding
 * - Rounded clip for press ripple
 */
@Composable
fun MR7BottomNavigationBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {
    Surface(
        tonalElevation = 8.dp,
        shadowElevation = 12.dp,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(68.dp)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MR7BottomNavItem(
                title = "الرئيسية",
                icon = Icons.Default.Home,
                isSelected = selectedTab == 0,
                onClick = { onTabSelected(0) },
                testTag = "nav_tab_home"
            )
            MR7BottomNavItem(
                title = "القوائم",
                icon = Icons.Default.FormatListBulleted,
                isSelected = selectedTab == 1,
                onClick = { onTabSelected(1) },
                testTag = "nav_tab_lists"
            )
            MR7BottomNavItem(
                title = "المنتجات",
                icon = Icons.Default.Inventory,
                isSelected = selectedTab == 2,
                onClick = { onTabSelected(2) },
                testTag = "nav_tab_products"
            )
            MR7BottomNavItem(
                title = "الإحصائيات",
                icon = Icons.Default.PieChart,
                isSelected = selectedTab == 3,
                onClick = { onTabSelected(3) },
                testTag = "nav_tab_stats"
            )
            MR7BottomNavItem(
                title = "المزيد",
                icon = Icons.Default.MoreHoriz,
                isSelected = selectedTab == 4,
                onClick = { onTabSelected(4) },
                testTag = "nav_tab_more"
            )
        }
    }
}

@Composable
private fun MR7BottomNavItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val activeColor = Color(0xFF2563EB)
    val inactiveColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
    val shape = RoundedCornerShape(14.dp)

    Column(
        modifier = Modifier
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Icon container with active pill
        Box(
            modifier = Modifier
                .size(width = 46.dp, height = 28.dp)
                .clip(CircleShape)
                .background(if (isSelected) activeColor.copy(alpha = 0.14f) else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) activeColor else inactiveColor,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.height(3.dp))

        // Title strictly below icon
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 11.sp
            ),
            color = if (isSelected) activeColor else inactiveColor,
            maxLines = 1,
            softWrap = false
        )
    }
}

/**
 * Home Screen Dashboard Content:
 * Header gradient + modern Settings icon + profile click + search + fixed responsive stats cards + quick actions.
 */
@Composable
fun HomeScreenDashboard(
    viewModel: MainViewModel,
    currentUser: com.example.data.local.entity.UserEntity?,
    activeLists: List<com.example.data.local.entity.ShoppingListEntity>,
    products: List<com.example.data.local.entity.ProductEntity>,
    stores: List<com.example.data.local.entity.StoreEntity>,
    settings: com.example.data.local.entity.AppSettingsEntity,
    totalSpent: Double,
    lastActiveList: com.example.data.local.entity.ShoppingListEntity?,
    missingProducts: List<MissingProductSample>,
    onNavigate: (String) -> Unit,
    onOpenNotifications: () -> Unit,
    onTabSelect: (Int) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }

    val currentDateStr = remember {
        try {
            val sdf = SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar"))
            sdf.format(Date())
        } catch (_: Exception) {
            "اليوم"
        }
    }

    // Voice Search
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                searchQuery = spokenText
                viewModel.setSearchQuery(spokenText)
                onTabSelect(2) // Switch to Products Tab
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Header with Gradient, User Avatar, Settings & Notifications Actions
        item {
            Box(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(GradientStart, GradientMiddle, GradientEnd)
                            )
                        )
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // User Profile Click: Opens Settings directly as requested
                            val avatarShape = RoundedCornerShape(16.dp)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier
                                    .clip(avatarShape)
                                    .clickable { onNavigate("settings") }
                                    .padding(4.dp)
                            ) {
                                UserAvatar(
                                    avatarUri = currentUser?.avatarUri,
                                    size = 50.dp,
                                    borderWidth = 2.dp,
                                    borderColor = Color.White.copy(alpha = 0.8f)
                                )

                                Column {
                                    val displayName = currentUser?.name?.takeIf { it.isNotBlank() } ?: "عزيزي المستخدم"
                                    Text(
                                        text = "مرحباً بك، $displayName 👋",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 16.sp
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "MR7 طلباتي",
                                        style = MaterialTheme.typography.headlineSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            color = Color.White,
                                            fontSize = 21.sp
                                        )
                                    )
                                    Text(
                                        text = "📅 $currentDateStr",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = Color.White.copy(alpha = 0.85f),
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }

                            // Top Action Buttons: Modern Settings Icon placed NEXT to Notifications Bell!
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Settings Button
                                IconButton(
                                    onClick = { onNavigate("settings") },
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.22f))
                                        .testTag("btn_top_settings")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "الإعدادات",
                                        tint = Color.White
                                    )
                                }

                                // Notifications Bell Button with Badge
                                IconButton(
                                    onClick = onOpenNotifications,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.22f))
                                        .testTag("btn_top_notifications")
                                ) {
                                    BadgedBox(
                                        badge = {
                                            Badge(
                                                containerColor = Color(0xFFEF4444),
                                                contentColor = Color.White
                                            ) {
                                                Text("3", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Notifications,
                                            contentDescription = "الإشعارات",
                                            tint = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Search Bar Overlay at Bottom of Gradient
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .align(Alignment.BottomCenter)
                        .shadow(6.dp, RoundedCornerShape(24.dp))
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            if (it.isNotBlank()) {
                                viewModel.setSearchQuery(it)
                            }
                        },
                        placeholder = {
                            Text(
                                text = "ابحث عن منتج، متجر، قائمة...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "بحث",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        trailingIcon = {
                            IconButton(onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "MR7 MIC")
                                }
                                try {
                                    speechLauncher.launch(intent)
                                } catch (_: Exception) {
                                    Toast.makeText(context, "خاصية البحث الصوتي غير متاحة على هذا الجهاز", Toast.LENGTH_SHORT).show()
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "بحث صوتي",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("main_search_input"),
                        shape = RoundedCornerShape(24.dp)
                    )
                }
            }
        }

        // 2. DASHBOARD STATS SECTION (Responsive 2 Rows - Never Cut Off!)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row 1: Total Spend & Lists Count
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardStatCard(
                        title = "إجمالي الإنفاق",
                        value = "${CurrencyFormatter.format(totalSpent)} ${settings.currency}",
                        badgeText = "المصاريف",
                        badgeColor = Color(0xFF10B981),
                        icon = Icons.Default.AccountBalanceWallet,
                        iconBgColor = Color(0xFFEEF2FF),
                        iconColor = Color(0xFF4F46E5),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate("bills") }
                    )

                    DashboardStatCard(
                        title = "عدد القوائم",
                        value = "${activeLists.size} قائمة",
                        badgeText = "نشطة",
                        badgeColor = Color(0xFF10B981),
                        icon = Icons.Default.ShoppingCart,
                        iconBgColor = Color(0xFFECFDF5),
                        iconColor = Color(0xFF059669),
                        modifier = Modifier.weight(1f),
                        onClick = { onTabSelect(1) }
                    )
                }

                // Row 2: Products Count & Stores Count (Fully visible now without height restrictions!)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardStatCard(
                        title = "عدد المنتجات",
                        value = "${products.size} منتج",
                        badgeText = "مسجل",
                        badgeColor = Color(0xFFF59E0B),
                        icon = Icons.Default.Inventory,
                        iconBgColor = Color(0xFFFFFBEB),
                        iconColor = Color(0xFFD97706),
                        modifier = Modifier.weight(1f),
                        onClick = { onTabSelect(2) }
                    )

                    DashboardStatCard(
                        title = "عدد المتاجر",
                        value = "${stores.size} متاجر",
                        badgeText = "متاح",
                        badgeColor = Color(0xFF0284C7),
                        icon = Icons.Default.Store,
                        iconBgColor = Color(0xFFF0F9FF),
                        iconColor = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate("stores") }
                    )
                }
            }
        }

        // 3. QUICK ACTION BUTTONS (With wrap to prevent "منتج جديد" cutoff!)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "⚡ إجراءات سريعة",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionButton(
                        title = "قائمة جديدة",
                        icon = Icons.Default.Add,
                        iconBg = Color(0xFF10B981),
                        modifier = Modifier.weight(1f).testTag("btn_create_list"),
                        onClick = { onNavigate("create_list") }
                    )

                    QuickActionButton(
                        title = "منتج جديد",
                        icon = Icons.Default.Inventory,
                        iconBg = Color(0xFFF59E0B),
                        modifier = Modifier.weight(1f).testTag("btn_new_product"),
                        onClick = { onTabSelect(2) }
                    )

                    QuickActionButton(
                        title = "متجر جديد",
                        icon = Icons.Default.Store,
                        iconBg = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f).testTag("btn_stores"),
                        onClick = { onNavigate("stores") }
                    )

                    QuickActionButton(
                        title = "فاتورة جديدة",
                        icon = Icons.Default.ReceiptLong,
                        iconBg = Color(0xFF8B5CF6),
                        modifier = Modifier.weight(1f).testTag("btn_bills"),
                        onClick = { onNavigate("bills") }
                    )
                }
            }
        }

        // 4. ACTIVE SHOPPING CARD
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "🛒 متابعة التسوق",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp)
                )

                val activeCardShape = RoundedCornerShape(20.dp)
                Card(
                    shape = activeCardShape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(activeCardShape)
                        .testTag("active_shopping_card")
                ) {
                    if (lastActiveList != null) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = Color(0xFFEFF6FF),
                                        modifier = Modifier.size(52.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text("🧺", fontSize = 28.sp)
                                        }
                                    }

                                    Column {
                                        Text(
                                            text = lastActiveList.title,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "قائمة نشطة • تم التحديث اليوم",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Text(
                                    text = "نشطة",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { onNavigate("shopping_active/${lastActiveList.id}") },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                                ) {
                                    Text("متابعة التسوق الآن", fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                TextButton(onClick = { onTabSelect(1) }) {
                                    Text("عرض كل القوائم (${activeLists.size})", fontSize = 12.sp)
                                }
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("🛍️ لا توجد قائمة تسوق نشطة حالياً", fontWeight = FontWeight.Bold)
                            Text(
                                "أنشئ قائمة جديدة لبدء التسوق الذكي المنظم",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = { onNavigate("create_list") },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Text("+ إنشاء قائمة جديدة")
                            }
                        }
                    }
                }
            }
        }

        // 5. MISSING PRODUCTS
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🍳 منتجات ناقصة",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    )

                    TextButton(onClick = { onTabSelect(2) }) {
                        Text(
                            text = "عرض الكل >",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(missingProducts) { sample ->
                        MissingProductCard(
                            sample = sample,
                            onClick = { onNavigate("create_list") }
                        )
                    }
                }
            }
        }

        // 6. SMART SUGGESTIONS
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "✨ اقتراحات ذكية",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp)
                )

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "يبدو أنك تشتري \"حليب\" بانتظام",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF065F46)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "هل ترغب بإضافته لقائمتك القادمة بنقرة واحدة؟",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF047857)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    Toast.makeText(context, "تمت إضافة \"حليب\" إلى القادمة بنجاح ✨", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                            ) {
                                Text("إضافة للقائمة", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🥛", fontSize = 28.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * More Sections Screen (Tab 4):
 * Grid of all sections and utilities (Pantry, Stores, Categories, Bills, Account, Settings, Admin).
 */
@Composable
fun MoreSectionsScreen(
    viewModel: MainViewModel,
    categoriesCount: Int,
    pantryCount: Int,
    onNavigate: (String) -> Unit,
    onBackClick: () -> Unit
) {
    val currentUser by viewModel.currentUserState.collectAsState()
    val isSuperAdminOrAdmin = currentUser?.id == 777L || currentUser?.role == "SUPER_ADMIN" || currentUser?.role == "ADMIN"

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "المزيد من الأقسام والخدمات",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "جميع أدوات إدارة مشترياتك ومخزونك في مكان واحد",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MoreMenuItemCard(
                    title = "المخزون المنزلي",
                    subtitle = "$pantryCount منتج بالمخزن",
                    icon = Icons.Default.Inventory,
                    iconBg = Color(0xFF2563EB),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("pantry") }
                )
                MoreMenuItemCard(
                    title = "إدارة المتاجر",
                    subtitle = "الفروع وأماكن الشراء",
                    icon = Icons.Default.Store,
                    iconBg = Color(0xFF059669),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("stores") }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MoreMenuItemCard(
                    title = "التصنيفات",
                    subtitle = "$categoriesCount تصنيف مسجل",
                    icon = Icons.Default.Category,
                    iconBg = Color(0xFF6366F1),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("categories") }
                )
                MoreMenuItemCard(
                    title = "الفواتير السابقة",
                    subtitle = "سجل الإنفاق والمشتريات",
                    icon = Icons.Default.ReceiptLong,
                    iconBg = Color(0xFF8B5CF6),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("bills") }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MoreMenuItemCard(
                    title = "الملف الشخصي",
                    subtitle = currentUser?.name ?: "إدارة الحساب",
                    icon = Icons.Default.Person,
                    iconBg = Color(0xFFEC4899),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("my_account") }
                )
                MoreMenuItemCard(
                    title = "الإعدادات العامة",
                    subtitle = "المظهر، النسخ، الأمان",
                    icon = Icons.Default.Settings,
                    iconBg = Color(0xFF475569),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("settings") }
                )
            }
        }

        if (isSuperAdminOrAdmin) {
            item {
                MoreMenuItemCard(
                    title = "🛡️ لوحة تحكم الأدمن — MR7",
                    subtitle = "إدارة النظام والمستخدمين والعمليات الإدارية الكاملة",
                    icon = Icons.Default.Security,
                    iconBg = Color(0xFFDC2626),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onNavigate("admin_control_panel") }
                )
            }
        }
    }
}

@Composable
fun DashboardStatCard(
    title: String,
    value: String,
    badgeText: String,
    badgeColor: Color,
    icon: ImageVector,
    iconBgColor: Color,
    iconColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val cardShape = RoundedCornerShape(20.dp)
    Card(
        shape = cardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .clip(cardShape)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = iconBgColor,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = iconColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun QuickActionButton(
    title: String,
    icon: ImageVector,
    iconBg: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Card(
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .height(96.dp)
            .clip(shape)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = CircleShape,
                color = iconBg,
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    lineHeight = 13.sp
                ),
                maxLines = 2,
                softWrap = true,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun MissingProductCard(
    sample: MissingProductSample,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Card(
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .width(100.dp)
            .height(115.dp)
            .clip(shape)
            .clickable(onClick = onClick)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Surface(
                shape = CircleShape,
                color = Color(0xFF2563EB),
                modifier = Modifier
                    .padding(8.dp)
                    .size(22.dp)
                    .align(Alignment.TopStart)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "${sample.countBadge}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = sample.iconEmoji, fontSize = 32.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = sample.name,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun MoreMenuItemCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Card(
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .height(84.dp)
            .clip(shape)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = iconBg,
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 14.sp)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun NotificationItem(title: String, body: String, time: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(time, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
}
