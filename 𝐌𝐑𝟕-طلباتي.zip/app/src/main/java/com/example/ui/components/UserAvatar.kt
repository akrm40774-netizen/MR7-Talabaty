package com.example.ui.components

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.io.File
import java.io.FileOutputStream

object AvatarUtils {
    /**
     * Copies a gallery Uri into local app internal storage so it is persistent across
     * restarts and doesn't expire or lose Android Uri permissions.
     */
    fun saveUriToInternalStorage(context: Context, sourceUri: Uri): String {
        return try {
            val avatarsDir = File(context.filesDir, "avatars").apply {
                if (!exists()) mkdirs()
            }
            val destFile = File(avatarsDir, "avatar_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { inputStream ->
                FileOutputStream(destFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            destFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            sourceUri.toString()
        }
    }
}

/**
 * Renders user avatar seamlessly supporting:
 * - Local file paths & URIs (via Coil AsyncImage)
 * - Emoji avatars (👤, 👑, etc.)
 * - Default fallback
 */
@Composable
fun UserAvatar(
    avatarUri: String?,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    borderWidth: Dp = 0.dp,
    borderColor: Color = Color.Transparent,
    backgroundColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    defaultEmoji: String = "👤"
) {
    val cleanUri = avatarUri?.trim()
    val isImageUri = cleanUri != null && (
        cleanUri.startsWith("/") ||
        cleanUri.startsWith("content://") ||
        cleanUri.startsWith("file://") ||
        cleanUri.startsWith("http://") ||
        cleanUri.startsWith("https://")
    )

    Surface(
        shape = CircleShape,
        color = backgroundColor,
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .then(
                if (borderWidth > 0.dp) Modifier.border(borderWidth, borderColor, CircleShape)
                else Modifier
            )
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.clip(CircleShape)
        ) {
            if (isImageUri && cleanUri != null) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(cleanUri)
                        .crossfade(true)
                        .build(),
                    contentDescription = "الصورة الشخصية",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(size)
                        .clip(CircleShape)
                )
            } else {
                val emojiText = if (!cleanUri.isNullOrBlank()) cleanUri else defaultEmoji
                val fontSize = (size.value * 0.5f).coerceAtLeast(14f).sp
                Text(
                    text = emojiText,
                    fontSize = fontSize,
                    lineHeight = fontSize
                )
            }
        }
    }
}
