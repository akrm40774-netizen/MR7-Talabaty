package com.example.data.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.AdminLogEntity
import com.example.data.local.entity.AdminNotificationEntity
import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.PantryHistoryEntity
import com.example.data.local.entity.PantryItemEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ShoppingListEntity
import com.example.data.local.entity.ShoppingListItemEntity
import com.example.data.local.entity.StoreEntity
import com.example.data.local.entity.UserEntity
import com.example.data.repository.AppRepository
import com.example.util.LocationUtils
import com.example.util.NotificationHelper
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AppStatistics(
    val totalListsCount: Int = 0,
    val totalProductsCount: Int = 0,
    val totalSpent: Double = 0.0,
    val averageSpendPerList: Double = 0.0,
    val mostVisitedStore: String = "غير متوفر",
    val mostUsedCategory: String = "غير متوفر",
    val mostBoughtProduct: String = "غير متوفر",
    val unfoundItemsCount: Int = 0,
    val carriedItemsCount: Int = 0
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = AppRepository(application)

    // Current Authenticated User State
    val currentUserState: StateFlow<UserEntity?> = repository.currentUser
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    fun clearAuthError() {
        _authError.value = null
    }

    fun setAuthError(error: String) {
        _authError.value = error
    }

    fun checkSession(onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val isValid = repository.checkAndValidateSession()
            onResult(isValid)
        }
    }

    fun login(email: String, pass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.loginUser(email, pass)
            _authLoading.value = false
            result.onSuccess {
                _userMessage.value = "مرحبًا بك مجددًا، ${it.name}!"
                onSuccess()
            }.onFailure {
                _authError.value = it.message ?: "حدث خطأ أثناء تسجيل الدخول"
            }
        }
    }

    fun register(name: String, email: String, pass: String, avatarUri: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.registerUser(name, email, pass, avatarUri)
            _authLoading.value = false
            result.onSuccess {
                _userMessage.value = "تم إنشاء حسابك بنجاح!"
                onSuccess()
            }.onFailure {
                _authError.value = it.message ?: "حدث خطأ أثناء إنشاء الحساب"
            }
        }
    }

    fun loginWithSocial(provider: String, email: String, name: String, avatarUrl: String = "", onSuccess: () -> Unit) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.loginOrRegisterSocialUser(provider, email, name, avatarUrl)
            _authLoading.value = false
            result.onSuccess {
                val providerLabel = if (provider == "GOOGLE") "Google" else "Facebook"
                _userMessage.value = "تم تسجيل الدخول عبر $providerLabel بنجاح! مرحباً ${it.name}"
                onSuccess()
            }.onFailure {
                _authError.value = it.message ?: "فشل تسجيل الدخول عبر $provider"
            }
        }
    }

    fun resetPassword(email: String, newPass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.resetPassword(email, newPass)
            _authLoading.value = false
            result.onSuccess {
                _userMessage.value = "تم تغيير كلمة المرور بنجاح. يرجى تسجيل الدخول"
                onSuccess()
            }.onFailure {
                _authError.value = it.message ?: "حدث خطأ أثناء إعادة تعيين كلمة المرور"
            }
        }
    }

    fun updateProfile(name: String, avatarUri: String) {
        viewModelScope.launch {
            val result = repository.updateUserProfile(name, avatarUri)
            result.onSuccess {
                _userMessage.value = "تم تحديث الملف الشخصي بنجاح"
            }.onFailure {
                _userMessage.value = it.message ?: "فشل في تحديث البيانات"
            }
        }
    }

    // Camera / Image Capture State for OCR and Receipts
    private val _capturedImageUri = MutableStateFlow<String?>(null)
    val capturedImageUri: StateFlow<String?> = _capturedImageUri.asStateFlow()

    fun setCapturedImageUri(uri: String?) {
        _capturedImageUri.value = uri
    }

    fun clearCapturedImageUri() {
        _capturedImageUri.value = null
    }

    fun logout(onLoggedOut: () -> Unit = {}) {
        viewModelScope.launch {
            repository.logoutUser()
            _userMessage.value = "تم تسجيل الخروج بنجاح"
            onLoggedOut()
        }
    }

    // Settings
    val settingsState: StateFlow<AppSettingsEntity> = repository.settingsFlow
        .map { it ?: AppSettingsEntity() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettingsEntity()
        )

    // Categories
    val categoriesState: StateFlow<List<CategoryEntity>> = repository.allCategories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Stores
    val storesState: StateFlow<List<StoreEntity>> = repository.allStores
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Master Products
    val productsState: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Search query for master products
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val searchResults: StateFlow<List<ProductEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allProducts
            else repository.searchProducts(query)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Shopping Lists
    val activeListsState: StateFlow<List<ShoppingListEntity>> = repository.activeLists
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val finishedListsState: StateFlow<List<ShoppingListEntity>> = repository.finishedLists
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Selected Shopping List for Active Shopping Screen
    private val _selectedListId = MutableStateFlow<Long?>(null)
    val selectedListId: StateFlow<Long?> = _selectedListId.asStateFlow()

    fun selectList(id: Long?) {
        _selectedListId.value = id
    }

    suspend fun getListById(id: Long): ShoppingListEntity? {
        return repository.getListById(id)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeListItemsState: StateFlow<List<ShoppingListItemEntity>> = _selectedListId
        .flatMapLatest { id ->
            if (id != null) repository.getItemsForList(id)
            else flowOf(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Bills
    val billsState: StateFlow<List<BillEntity>> = repository.allBills
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun deleteBill(bill: BillEntity) {
        viewModelScope.launch {
            repository.billDao.deleteBill(bill)
            _userMessage.value = "تم حذف الفاتورة"
        }
    }

    suspend fun getBillById(id: Long): BillEntity? {
        return repository.getBillById(id)
    }

    suspend fun getPurchasedItemsForBill(listId: Long): List<ShoppingListItemEntity> {
        return repository.shoppingListDao.getItemsForListOnce(listId).filter { it.isPurchased }
    }

    // Toast / Message State for User Feedback
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // Category Actions
    fun saveCategory(category: CategoryEntity) {
        viewModelScope.launch {
            if (category.id == 0L) {
                repository.insertCategory(category)
                _userMessage.value = "تمت إضافة التصنيف بنجاح"
            } else {
                repository.updateCategory(category)
                _userMessage.value = "تم تعديل التصنيف بنجاح"
            }
        }
    }

    fun deleteCategory(category: CategoryEntity) {
        viewModelScope.launch {
            repository.deleteCategory(category)
            _userMessage.value = "تم حذف التصنيف"
        }
    }

    // Store Actions
    fun saveStore(store: StoreEntity) {
        viewModelScope.launch {
            if (store.id == 0L) {
                repository.insertStore(store)
                _userMessage.value = "تمت إضافة المتجر بنجاح"
            } else {
                repository.updateStore(store)
                _userMessage.value = "تم تعديل المتجر بنجاح"
            }
        }
    }

    fun deleteStore(store: StoreEntity) {
        viewModelScope.launch {
            repository.deleteStore(store)
            _userMessage.value = "تم حذف المتجر"
        }
    }

    // Product Actions
    fun saveProduct(product: ProductEntity) {
        viewModelScope.launch {
            if (product.id == 0L) {
                repository.insertProduct(product)
                _userMessage.value = "تمت إضافة المنتج بقاعدة البيانات"
            } else {
                repository.updateProduct(product)
                _userMessage.value = "تم تحديث بيانات المنتج"
            }
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            _userMessage.value = "تم حذف المنتج"
        }
    }

    // Create New Shopping List
    fun createList(title: String, budget: Double?, items: List<ShoppingListItemEntity>, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val listId = repository.createShoppingList(title, budget, items)
            _selectedListId.value = listId
            _userMessage.value = "تم إنشاء قائمة التسوق بنجاح"
            onCreated(listId)
        }
    }

    // Active Shopping Item Actions
    fun toggleItemPurchased(item: ShoppingListItemEntity) {
        viewModelScope.launch {
            val updated = item.copy(isPurchased = !item.isPurchased)
            repository.updateListItem(updated)
        }
    }

    fun updateListItem(item: ShoppingListItemEntity) {
        viewModelScope.launch {
            repository.updateListItem(item)
        }
    }

    // User Location for Proximity Sorting
    private val _userLocation = MutableStateFlow(Pair(LocationUtils.DEFAULT_USER_LAT, LocationUtils.DEFAULT_USER_LNG))
    val userLocation: StateFlow<Pair<Double, Double>> = _userLocation.asStateFlow()

    fun updateUserLocation(lat: Double, lng: Double) {
        _userLocation.value = Pair(lat, lng)
    }

    // Quick Add Product Feature (منتج سريع)
    fun quickAddProduct(
        name: String,
        quantity: Double,
        price: Double?,
        isPriceUnknown: Boolean,
        targetListId: Long? = null,
        onComplete: ((Long) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val lists = activeListsState.value
            val listIdToUse = when {
                targetListId != null && targetListId > 0 -> targetListId
                _selectedListId.value != null && _selectedListId.value!! > 0 -> _selectedListId.value!!
                lists.isNotEmpty() -> lists.first().id
                else -> {
                    // Create default active list
                    repository.createShoppingList("قائمة التسوق السريعة", budget = null, items = emptyList())
                }
            }

            val master = repository.findProductByName(name)
            val finalPrice = price ?: (if (isPriceUnknown) 0.0 else (master?.lastPrice ?: 0.0))
            val newItem = ShoppingListItemEntity(
                listId = listIdToUse,
                productId = master?.id,
                name = name.trim(),
                quantity = if (quantity > 0) quantity else 1.0,
                unit = master?.defaultUnit ?: "قطعة",
                price = finalPrice,
                isPriceUnknown = isPriceUnknown || finalPrice <= 0.0,
                isPurchased = false,
                categoryId = master?.categoryId,
                storeId = master?.defaultStoreId
            )
            repository.insertItemToList(newItem)
            _userMessage.value = "⚡ تمت إضافة \"${name.trim()}\" بسبعة ثوانٍ للقائمة!"
            onComplete?.invoke(listIdToUse)
        }
    }

    // Proximity Store Notification Trigger
    fun triggerStoreProximityNotification(store: StoreEntity, unboughtItemsCount: Int = 3) {
        NotificationHelper.showNearbyStoreNotification(
            getApplication(),
            store.name,
            unboughtItemsCount
        )
        _userMessage.value = "🔔 تم إرسال إشعار الاقتراب من متجر \"${store.name}\""
    }

    fun addItemToActiveList(
        listId: Long,
        name: String,
        quantity: Double,
        unit: String,
        price: Double,
        storeId: Long?,
        categoryId: Long?
    ) {
        viewModelScope.launch {
            val master = repository.findProductByName(name)
            val newItem = ShoppingListItemEntity(
                listId = listId,
                productId = master?.id,
                name = name.trim(),
                quantity = if (quantity > 0) quantity else 1.0,
                unit = unit.ifBlank { master?.defaultUnit ?: "قطعة" },
                price = if (price > 0) price else (master?.lastPrice ?: 0.0),
                isPriceUnknown = price <= 0 && (master == null || master.lastPrice <= 0),
                isPurchased = false,
                categoryId = categoryId ?: master?.categoryId,
                storeId = storeId ?: master?.defaultStoreId
            )
            repository.insertItemToList(newItem)
            _userMessage.value = "تمت إضافة المنتج للقائمة"
        }
    }

    fun deleteListItem(item: ShoppingListItemEntity) {
        viewModelScope.launch {
            repository.deleteListItem(item)
        }
    }

    fun deleteShoppingList(list: ShoppingListEntity) {
        viewModelScope.launch {
            repository.deleteShoppingList(list)
            _userMessage.value = "تم حذف القائمة"
        }
    }

    // Finalize List
    fun finalizeList(
        listId: Long,
        incompleteActionMap: Map<Long, String>,
        onFinished: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val billId = repository.finalizeShoppingList(listId, incompleteActionMap)
            _userMessage.value = "تم إنهاء القائمة وحفظ الفاتورة"
            onFinished(billId)
        }
    }

    // Settings
    fun updateTheme(dark: Boolean) {
        viewModelScope.launch {
            val curr = settingsState.value
            repository.updateSettings(curr.copy(darkTheme = dark))
        }
    }

    fun updateCurrency(currStr: String) {
        viewModelScope.launch {
            val curr = settingsState.value
            repository.updateSettings(curr.copy(currency = currStr))
        }
    }

    fun updateSortOrder(orderStr: String) { // STORE, CATEGORY, MANUAL
        viewModelScope.launch {
            val curr = settingsState.value
            repository.updateSettings(curr.copy(defaultSortOrder = orderStr))
        }
    }

    fun updateVibration(enabled: Boolean) {
        viewModelScope.launch {
            val curr = settingsState.value
            repository.updateSettings(curr.copy(vibrationEnabled = enabled))
        }
    }

    fun updateSound(enabled: Boolean) {
        viewModelScope.launch {
            val curr = settingsState.value
            repository.updateSettings(curr.copy(soundEnabled = enabled))
        }
    }

    // Backup & Restore
    fun exportBackup(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportDataToJson()
            onResult(json)
        }
    }

    fun importBackup(jsonStr: String) {
        viewModelScope.launch {
            val success = repository.importDataFromJson(jsonStr)
            if (success) {
                _userMessage.value = "تمت استعادة النسخة الاحتياطية بنجاح"
            } else {
                _userMessage.value = "فشل في استعادة النسخة الاحتياطية. يرجى التأكد من صحة الملف."
            }
        }
    }

    // Home Pantry / Inventory Management
    val pantryItemsState: StateFlow<List<PantryItemEntity>> = repository.allPantryItems
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun getPantryHistoryForItem(pantryItemId: Long): Flow<List<PantryHistoryEntity>> {
        return repository.getPantryHistoryForItem(pantryItemId)
    }

    fun insertPantryItem(item: PantryItemEntity) {
        viewModelScope.launch {
            repository.insertPantryItem(item)
            _userMessage.value = "تمت إضافة \"${item.name}\" للمخزون المنزلي"
        }
    }

    fun updatePantryItem(item: PantryItemEntity) {
        viewModelScope.launch {
            repository.updatePantryItem(item)
            _userMessage.value = "تم تحديث بيات المنتج بالمخزون"
        }
    }

    fun deletePantryItem(item: PantryItemEntity) {
        viewModelScope.launch {
            repository.deletePantryItem(item)
            _userMessage.value = "تم حذف المنتج من المخزون المنزلي"
        }
    }

    fun updatePantryQuantity(itemId: Long, change: Double, actionType: String = "تعديل", note: String = "") {
        viewModelScope.launch {
            repository.updatePantryQuantity(itemId, change, actionType, note)
        }
    }

    fun addLowStockPantryItemsToShoppingList(pantryItems: List<PantryItemEntity>, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            if (pantryItems.isEmpty()) {
                _userMessage.value = "لا توجد منتجات ناقصة لإضافتها"
                return@launch
            }
            val listTitle = "قائمة المشتريات من المخزون الناقص"
            val shoppingItems = pantryItems.map { pantry ->
                val quantityToAdd = if (pantry.maxLimit > pantry.currentQuantity) {
                    pantry.maxLimit - pantry.currentQuantity
                } else 1.0

                ShoppingListItemEntity(
                    listId = 0,
                    productId = pantry.productId,
                    name = pantry.name,
                    quantity = quantityToAdd,
                    unit = pantry.unit,
                    price = 0.0,
                    isPriceUnknown = true,
                    isPurchased = false,
                    categoryId = pantry.categoryId
                )
            }
            val listId = repository.createShoppingList(listTitle, budget = null, items = shoppingItems)
            _userMessage.value = "تمت إضافة ${pantryItems.size} منتج لقائمة التسوق"
            onComplete(listId)
        }
    }

    // --- MR7 ADMIN SYSTEM STATE AND OPERATIONS ---
    val isAdminPanelUnlocked = MutableStateFlow(false)

    val adminUsersList: StateFlow<List<UserEntity>> = repository.getAllUsersFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val adminAdminsList: StateFlow<List<UserEntity>> = repository.getAdminsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val adminLogsList: StateFlow<List<AdminLogEntity>> = repository.getAdminLogsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val adminNotificationsList: StateFlow<List<AdminNotificationEntity>> = repository.getAdminNotificationsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val adminStatistics = MutableStateFlow<Map<String, Any>>(emptyMap())

    fun verifyAdminPanelPassword(password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.verifyControlPanelPassword(password)
            if (success) {
                isAdminPanelUnlocked.value = true
                refreshAdminStatistics()
            }
            onResult(success)
        }
    }

    fun logoutAdminPanel() {
        isAdminPanelUnlocked.value = false
    }

    fun refreshAdminStatistics() {
        viewModelScope.launch {
            val stats = repository.getAdminStatistics()
            adminStatistics.value = stats
        }
    }

    fun banUser(
        targetUserId: Long,
        isPermanent: Boolean,
        banDays: Int?,
        reason: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.banUser(targetUserId, isPermanent, banDays, reason)
            if (result.isSuccess) {
                _userMessage.value = "تم تنفيذ الحظر بنجاح"
                refreshAdminStatistics()
                onComplete(true, "تم حظر المستخدم بنجاح")
            } else {
                val err = result.exceptionOrNull()?.message ?: "حدث خطأ أثناء تنفيذ الحظر"
                _userMessage.value = err
                onComplete(false, err)
            }
        }
    }

    fun unbanUser(targetUserId: Long, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = repository.unbanUser(targetUserId)
            if (result.isSuccess) {
                _userMessage.value = "تم فك الحظر عن المستخدم بنجاح"
                refreshAdminStatistics()
                onComplete(true, "تم فك الحظر بنجاح")
            } else {
                val err = result.exceptionOrNull()?.message ?: "حدث خطأ أثناء فك الحظر"
                _userMessage.value = err
                onComplete(false, err)
            }
        }
    }

    fun addAdmin(
        name: String,
        email: String,
        loginPass: String,
        controlPass: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.addAdmin(name, email, loginPass, controlPass)
            if (result.isSuccess) {
                _userMessage.value = "تمت إضافة الأدمن الجديد بنجاح"
                refreshAdminStatistics()
                onComplete(true, "تم إضافة الأدمن بنجاح")
            } else {
                val err = result.exceptionOrNull()?.message ?: "حدث خطأ أثناء إضافة الأدمن"
                _userMessage.value = err
                onComplete(false, err)
            }
        }
    }

    fun updateAdmin(
        adminId: Long,
        name: String,
        email: String,
        loginPass: String?,
        controlPass: String?,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.updateAdmin(adminId, name, email, loginPass, controlPass)
            if (result.isSuccess) {
                _userMessage.value = "تمت تحديث بيانات الأدمن بنجاح"
                onComplete(true, "تم التحديث بنجاح")
            } else {
                val err = result.exceptionOrNull()?.message ?: "حدث خطأ أثناء تعديل الأدمن"
                _userMessage.value = err
                onComplete(false, err)
            }
        }
    }

    fun removeAdmin(adminId: Long, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = repository.removeAdmin(adminId)
            if (result.isSuccess) {
                _userMessage.value = "تمت إزالة صلاحيات الأدمن بنجاح"
                refreshAdminStatistics()
                onComplete(true, "تم إزالة الأدمن")
            } else {
                val err = result.exceptionOrNull()?.message ?: "حدث خطأ أثناء إزالة الأدمن"
                _userMessage.value = err
                onComplete(false, err)
            }
        }
    }

    fun getUserByIdForAdmin(userId: Long, onResult: (UserEntity?) -> Unit) {
        viewModelScope.launch {
            val user = repository.getUserByIdForAdmin(userId)
            onResult(user)
        }
    }

    fun markAllAdminNotificationsRead() {
        viewModelScope.launch {
            repository.markAllAdminNotificationsRead()
        }
    }

    fun deleteAdminNotification(id: Long) {
        viewModelScope.launch {
            repository.deleteAdminNotification(id)
        }
    }

    // --- SMART OCR / VOICE / BARCODE / BACKUP HELPER METHODS ---
    suspend fun getProductByBarcode(barcode: String): ProductEntity? {
        return repository.getProductByBarcode(barcode)
    }

    suspend fun getAllProductsOnce(): List<ProductEntity> {
        return repository.getAllProductsOnce()
    }

    fun addSmartItemToList(
        listId: Long,
        name: String,
        quantity: Double,
        unit: String,
        price: Double = 0.0,
        barcode: String? = null,
        notes: String = "",
        storeId: Long? = null,
        categoryId: Long? = null
    ) {
        viewModelScope.launch {
            repository.insertItemToList(
                ShoppingListItemEntity(
                    listId = listId,
                    name = name,
                    quantity = quantity,
                    unit = unit,
                    price = price,
                    storeId = storeId,
                    categoryId = categoryId,
                    notes = notes,
                    barcode = barcode
                )
            )
            _userMessage.value = "تمت إضافة «$name» إلى القائمة ✅"
        }
    }
}


