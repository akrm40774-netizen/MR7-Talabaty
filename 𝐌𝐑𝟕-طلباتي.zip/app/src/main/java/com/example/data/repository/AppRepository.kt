package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AdminLogEntity
import com.example.data.local.entity.AdminNotificationEntity
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.PantryHistoryEntity
import com.example.data.local.entity.PantryItemEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ShoppingListEntity
import com.example.data.local.entity.ShoppingListItemEntity
import com.example.data.local.entity.StoreEntity
import com.example.data.local.entity.UserEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

@OptIn(ExperimentalCoroutinesApi::class)
class AppRepository(context: Context) {

    private val db = AppDatabase.getDatabase(context)
    val userDao = db.userDao()
    private val categoryDao = db.categoryDao()
    private val storeDao = db.storeDao()
    private val productDao = db.productDao()
    val shoppingListDao = db.shoppingListDao()
    val billDao = db.billDao()
    private val settingsDao = db.appSettingsDao()
    val pantryDao = db.pantryDao()
    val adminLogDao = db.adminLogDao()
    val adminNotificationDao = db.adminNotificationDao()

    private val prefs: SharedPreferences =
        context.getSharedPreferences("mr7_talabati_prefs", Context.MODE_PRIVATE)

    private val _currentUserId = MutableStateFlow<Long>(getSavedUserId())
    val currentUserId: StateFlow<Long> = _currentUserId.asStateFlow()

    val currentUser: Flow<UserEntity?> = _currentUserId.flatMapLatest { id ->
        if (id > 0) userDao.getUserByIdFlow(id) else flowOf(null)
    }

    private fun getSavedUserId(): Long {
        val isLoggedIn = prefs.getBoolean("is_logged_in", false)
        return if (isLoggedIn) prefs.getLong("current_user_id", -1L) else -1L
    }

    private fun setSavedUserId(id: Long) {
        if (id > 0) {
            prefs.edit()
                .putLong("current_user_id", id)
                .putBoolean("is_logged_in", true)
                .putLong("session_login_time", System.currentTimeMillis())
                .apply()
        } else {
            prefs.edit()
                .putLong("current_user_id", -1L)
                .putBoolean("is_logged_in", false)
                .apply()
        }
        _currentUserId.value = id
    }

    suspend fun checkAndValidateSession(): Boolean {
        ensureSuperAdminExists()
        val savedId = prefs.getLong("current_user_id", -1L)
        val isLoggedIn = prefs.getBoolean("is_logged_in", false)

        if (!isLoggedIn || savedId <= 0) {
            setSavedUserId(-1L)
            return false
        }

        // Verify user exists in Room database
        val user = userDao.getUserById(savedId)
        if (user == null) {
            setSavedUserId(-1L)
            return false
        }

        _currentUserId.value = savedId
        return true
    }

    fun getCurrentUserId(): Long = _currentUserId.value

    // Password hashing helper
    private fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.trim().toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // Ensure Super Admin 777 exists
    suspend fun ensureSuperAdminExists() {
        val superAdmin = userDao.getUserById(777L)
        if (superAdmin == null) {
            val adminEntity = UserEntity(
                id = 777L,
                name = "الأدمن الأساسي 👑",
                email = "mr7.mr.mor3eb@gmail.com",
                passwordHash = hashPassword("MR7 ON TOP 111"),
                controlPanelPasswordHash = hashPassword("MR7 ON TOP 2013"),
                role = "SUPER_ADMIN",
                status = "ACTIVE",
                avatarUri = "👑",
                createdAt = 1722470400000L,
                firstLaunchAt = 1722470400000L,
                lastActiveAt = System.currentTimeMillis()
            )
            userDao.insertUser(adminEntity)

            settingsDao.insertOrUpdateSettings(AppSettingsEntity(userId = 777L))

            val defaultCategories = listOf(
                CategoryEntity(userId = 777L, name = "خضروات وفواكه", colorHex = "#4CAF50", iconName = "Apple", displayOrder = 1),
                CategoryEntity(userId = 777L, name = "ألبان وأجبان", colorHex = "#2196F3", iconName = "Cheese", displayOrder = 2),
                CategoryEntity(userId = 777L, name = "مخبوزات", colorHex = "#FF9800", iconName = "Bread", displayOrder = 3),
                CategoryEntity(userId = 777L, name = "لحوم وأسماك", colorHex = "#E91E63", iconName = "Meat", displayOrder = 4),
                CategoryEntity(userId = 777L, name = "مشروبات", colorHex = "#00BCD4", iconName = "Drink", displayOrder = 5),
                CategoryEntity(userId = 777L, name = "منظفات ومعطرات", colorHex = "#9C27B0", iconName = "Cleaning", displayOrder = 6),
                CategoryEntity(userId = 777L, name = "أخرى", colorHex = "#607D8B", iconName = "More", displayOrder = 7)
            )
            defaultCategories.forEach { categoryDao.insertCategory(it) }

            val defaultStores = listOf(
                StoreEntity(userId = 777L, name = "سوبر ماركت عبد الرحمن", storeType = "سوبر ماركت", colorHex = "#4CAF50", notes = "المتجر الرئيسي للمستلزمات اليومية"),
                StoreEntity(userId = 777L, name = "هايبر ماركت العثيم", storeType = "هايبر ماركت", colorHex = "#2196F3", notes = "عروض المشتريات الشهرية"),
                StoreEntity(userId = 777L, name = "مخبز المدينة", storeType = "مخبز", colorHex = "#FF9800", notes = "المخبوزات والحلويات الطازجة")
            )
            defaultStores.forEach { storeDao.insertStore(it) }
        } else {
            val targetControlHash = hashPassword("MR7 ON TOP 2013")
            if (superAdmin.role != "SUPER_ADMIN" || superAdmin.email != "mr7.mr.mor3eb@gmail.com" || superAdmin.controlPanelPasswordHash != targetControlHash) {
                userDao.updateUser(
                    superAdmin.copy(
                        role = "SUPER_ADMIN",
                        email = "mr7.mr.mor3eb@gmail.com",
                        passwordHash = hashPassword("MR7 ON TOP 111"),
                        controlPanelPasswordHash = targetControlHash,
                        status = "ACTIVE"
                    )
                )
            }
        }
    }

    // Centralized safe unique ID generator (7 digits -> 8 digits etc., reserving 777)
    suspend fun generateUniqueUserId(): Long {
        val existingUsers = userDao.getAllUsers()
        val existingIds = existingUsers.map { it.id }.toSet()
        for (i in 0..1000) {
            val candidate = (1000000L..9999999L).random()
            if (candidate != 777L && !existingIds.contains(candidate)) {
                return candidate
            }
        }
        for (i in 0..1000) {
            val candidate = (10000000L..99999999L).random()
            if (candidate != 777L && !existingIds.contains(candidate)) {
                return candidate
            }
        }
        return System.currentTimeMillis()
    }

    // Helper for robust user lookup by email
    suspend fun findUserByEmail(email: String): UserEntity? {
        val cleanEmail = email.trim().lowercase()
        val direct = userDao.getUserByEmail(cleanEmail)
        if (direct != null) return direct
        return userDao.getAllUsers().firstOrNull { it.email.trim().equals(cleanEmail, ignoreCase = true) }
    }

    // --- AUTHENTICATION ---
    suspend fun registerUser(
        name: String,
        email: String,
        pass: String,
        avatarUri: String = "👤"
    ): Result<UserEntity> {
        ensureSuperAdminExists()
        val cleanEmail = email.trim().lowercase()
        val cleanName = name.trim()
        val cleanPass = pass.trim()
        if (cleanName.isBlank()) return Result.failure(Exception("يرجى إدخال الاسم كاملًا"))
        if (cleanEmail.isBlank() || !cleanEmail.contains("@")) return Result.failure(Exception("يرجى إدخال بريد إلكتروني صحيح"))
        if (cleanPass.length < 6) return Result.failure(Exception("كلمة المرور يجب أن لا تقل عن 6 أحرف"))

        val existing = findUserByEmail(cleanEmail)
        if (existing != null) {
            return Result.failure(Exception("البريد الإلكتروني مسجل بالفعل"))
        }

        val newId = generateUniqueUserId()
        val newUser = UserEntity(
            id = newId,
            name = cleanName,
            email = cleanEmail,
            passwordHash = hashPassword(cleanPass),
            avatarUri = avatarUri,
            createdAt = System.currentTimeMillis(),
            firstLaunchAt = System.currentTimeMillis(),
            lastActiveAt = System.currentTimeMillis(),
            role = "USER",
            status = "ACTIVE"
        )
        userDao.insertUser(newUser)
        val createdUser = newUser

        // Set session
        setSavedUserId(newId)

        // Initialize default settings for user
        settingsDao.insertOrUpdateSettings(AppSettingsEntity(userId = newId))

        // Initialize default categories for new user
        val defaultCategories = listOf(
            CategoryEntity(userId = newId, name = "خضروات وفواكه", colorHex = "#4CAF50", iconName = "Apple", displayOrder = 1),
            CategoryEntity(userId = newId, name = "ألبان وأجبان", colorHex = "#2196F3", iconName = "Cheese", displayOrder = 2),
            CategoryEntity(userId = newId, name = "مخبوزات", colorHex = "#FF9800", iconName = "Bread", displayOrder = 3),
            CategoryEntity(userId = newId, name = "لحوم وأسماك", colorHex = "#E91E63", iconName = "Meat", displayOrder = 4),
            CategoryEntity(userId = newId, name = "مشروبات", colorHex = "#00BCD4", iconName = "Drink", displayOrder = 5),
            CategoryEntity(userId = newId, name = "منظفات ومعطرات", colorHex = "#9C27B0", iconName = "Cleaning", displayOrder = 6),
            CategoryEntity(userId = newId, name = "أخرى", colorHex = "#607D8B", iconName = "More", displayOrder = 7)
        )
        defaultCategories.forEach { categoryDao.insertCategory(it) }

        // Initialize default stores for new user
        val defaultStores = listOf(
            StoreEntity(userId = newId, name = "سوبر ماركت عبد الرحمن", storeType = "سوبر ماركت", colorHex = "#4CAF50", notes = "المتجر الرئيسي للمستلزمات اليومية"),
            StoreEntity(userId = newId, name = "هايبر ماركت العثيم", storeType = "هايبر ماركت", colorHex = "#2196F3", notes = "عروض المشتريات الشهرية"),
            StoreEntity(userId = newId, name = "مخبز المدينة", storeType = "مخبز", colorHex = "#FF9800", notes = "المخبوزات والحلويات الطازجة")
        )
        defaultStores.forEach { storeDao.insertStore(it) }

        // Notify Admin of new user
        try {
            adminNotificationDao.insertNotification(
                AdminNotificationEntity(
                    userId = newId,
                    userName = cleanName,
                    userEmail = cleanEmail,
                    title = "🔔 مستخدم جديد!",
                    body = "قام $cleanName بإنشاء حساب جديد بالمعرف ID: $newId",
                    type = "NEW_USER"
                )
            )
        } catch (e: Exception) {
            // ignore
        }

        return Result.success(createdUser)
    }

    suspend fun loginUser(email: String, pass: String): Result<UserEntity> {
        ensureSuperAdminExists()
        val cleanEmail = email.trim().lowercase()
        val cleanPass = pass.trim()
        if (cleanEmail.isBlank() || cleanPass.isBlank()) {
            return Result.failure(Exception("يرجى إدخال البريد الإلكتروني وكلمة المرور"))
        }

        val user = findUserByEmail(cleanEmail)
            ?: return Result.failure(Exception("الحساب غير موجود، يرجى إنشاء حساب جديد"))

        if (user.passwordHash != hashPassword(cleanPass)) {
            return Result.failure(Exception("كلمة المرور غير صحيحة"))
        }

        // Check ban status
        if (user.status == "BANNED") {
            return Result.failure(Exception("الحساب محظور حظرًا دائمًا: ${user.banReason ?: "مخالفة شروط الاستخدام"}"))
        } else if (user.status == "TEMP_BANNED") {
            val now = System.currentTimeMillis()
            if (user.banEndDate != null && now > user.banEndDate) {
                val unbanned = user.copy(status = "ACTIVE", banReason = null, banEndDate = null, banStartDate = null)
                userDao.updateUser(unbanned)
            } else {
                return Result.failure(Exception("الحساب محظور مؤقتًا حتى تاريخ انتهاء الحظر. السبب: ${user.banReason ?: "مخالفة الشروط"}"))
            }
        }

        val updatedUser = user.copy(lastActiveAt = System.currentTimeMillis())
        userDao.updateUser(updatedUser)

        setSavedUserId(user.id)
        return Result.success(updatedUser)
    }

    suspend fun loginOrRegisterSocialUser(
        provider: String,
        email: String,
        name: String,
        avatarUri: String = ""
    ): Result<UserEntity> {
        ensureSuperAdminExists()
        val cleanEmail = email.trim().lowercase()
        val cleanName = name.trim().ifBlank { if (provider == "GOOGLE") "مستخدم Google" else "مستخدم Facebook" }
        if (cleanEmail.isBlank()) return Result.failure(Exception("البريد الإلكتروني لحساب المصادقة غير متوفر"))

        val existing = findUserByEmail(cleanEmail)
        if (existing != null) {
            if (existing.status == "BANNED") {
                return Result.failure(Exception("الحساب محظور حظرًا دائمًا: ${existing.banReason ?: "مخالفة شروط الاستخدام"}"))
            } else if (existing.status == "TEMP_BANNED") {
                val now = System.currentTimeMillis()
                val end = existing.banEndDate ?: 0L
                if (now < end) {
                    val remainingHours = ((end - now) / (1000 * 60 * 60)).coerceAtLeast(1)
                    return Result.failure(Exception("الحساب محظور مؤقتًا. متبقي: $remainingHours ساعة تقريبًا. السبب: ${existing.banReason ?: "مخالفة النظام"}"))
                } else {
                    userDao.updateUser(existing.copy(status = "ACTIVE", banReason = null, banEndDate = null))
                }
            }
            val updated = existing.copy(
                lastActiveAt = System.currentTimeMillis(),
                avatarUri = if (existing.avatarUri.isBlank() || existing.avatarUri == "👤") avatarUri.ifBlank { existing.avatarUri } else existing.avatarUri
            )
            userDao.updateUser(updated)
            setSavedUserId(existing.id)
            return Result.success(updated)
        }

        // Register new social user
        val newId = generateUniqueUserId()
        val chosenAvatar = if (avatarUri.isNotBlank()) avatarUri else if (provider == "GOOGLE") "🌐" else "🔵"
        val newUser = UserEntity(
            id = newId,
            name = cleanName,
            email = cleanEmail,
            passwordHash = hashPassword("SOCIAL_LOGIN_${provider}_$newId"),
            avatarUri = chosenAvatar,
            createdAt = System.currentTimeMillis(),
            firstLaunchAt = System.currentTimeMillis(),
            lastActiveAt = System.currentTimeMillis(),
            role = "USER",
            status = "ACTIVE"
        )
        userDao.insertUser(newUser)
        setSavedUserId(newId)
        settingsDao.insertOrUpdateSettings(AppSettingsEntity(userId = newId))

        val defaultCategories = listOf(
            CategoryEntity(userId = newId, name = "خضروات وفواكه", colorHex = "#4CAF50", iconName = "Apple", displayOrder = 1),
            CategoryEntity(userId = newId, name = "ألبان وأجبان", colorHex = "#2196F3", iconName = "Cheese", displayOrder = 2),
            CategoryEntity(userId = newId, name = "مخبوزات", colorHex = "#FF9800", iconName = "Bread", displayOrder = 3),
            CategoryEntity(userId = newId, name = "لحوم وأسماك", colorHex = "#E91E63", iconName = "Meat", displayOrder = 4),
            CategoryEntity(userId = newId, name = "مشروبات", colorHex = "#00BCD4", iconName = "Drink", displayOrder = 5),
            CategoryEntity(userId = newId, name = "منظفات ومعطرات", colorHex = "#9C27B0", iconName = "Cleaning", displayOrder = 6),
            CategoryEntity(userId = newId, name = "أخرى", colorHex = "#607D8B", iconName = "More", displayOrder = 7)
        )
        defaultCategories.forEach { categoryDao.insertCategory(it) }

        val defaultStores = listOf(
            StoreEntity(userId = newId, name = "سوبر ماركت عبد الرحمن", storeType = "سوبر ماركت", colorHex = "#4CAF50", notes = "المتجر الرئيسي للمستلزمات اليومية"),
            StoreEntity(userId = newId, name = "هايبر ماركت العثيم", storeType = "هايبر ماركت", colorHex = "#2196F3", notes = "عروض المشتريات الشهرية"),
            StoreEntity(userId = newId, name = "مخبز المدينة", storeType = "مخبز", colorHex = "#FF9800", notes = "المخبوزات والحلويات الطازجة")
        )
        defaultStores.forEach { storeDao.insertStore(it) }

        try {
            adminNotificationDao.insertNotification(
                AdminNotificationEntity(
                    userId = newId,
                    userName = cleanName,
                    userEmail = cleanEmail,
                    title = "🔔 مستخدم جديد عبر $provider",
                    body = "سجل $cleanName الدخول بحساب $provider الجديد (ID: $newId)",
                    type = "NEW_USER"
                )
            )
        } catch (_: Exception) {}

        return Result.success(newUser)
    }

    suspend fun resetPassword(email: String, newPass: String): Result<Unit> {
        val cleanEmail = email.trim().lowercase()
        val cleanPass = newPass.trim()
        if (cleanEmail.isBlank()) return Result.failure(Exception("يرجى إدخال البريد الإلكتروني"))
        if (cleanPass.length < 6) return Result.failure(Exception("كلمة المرور الجديدة يجب أن لا تقل عن 6 أحرف"))

        val user = findUserByEmail(cleanEmail)
            ?: return Result.failure(Exception("لم يتم العثور على حساب بهذا البريد الإلكتروني"))

        val updated = user.copy(passwordHash = hashPassword(cleanPass))
        userDao.updateUser(updated)
        return Result.success(Unit)
    }

    suspend fun updateUserProfile(name: String, avatarUri: String): Result<Unit> {
        val uid = getCurrentUserId()
        if (uid <= 0) return Result.failure(Exception("غير مسجل الدخول"))

        val user = userDao.getUserById(uid) ?: return Result.failure(Exception("المستخدم غير موجود"))
        val updated = user.copy(name = name.trim().ifBlank { user.name }, avatarUri = avatarUri)
        userDao.updateUser(updated)
        return Result.success(Unit)
    }

    fun logoutUser() {
        setSavedUserId(-1L)
    }

    // --- MR7 ADMIN SYSTEM FUNCTIONS ---
    suspend fun verifyControlPanelPassword(password: String): Boolean {
        ensureSuperAdminExists()
        val uid = getCurrentUserId()
        if (uid <= 0) return false
        val user = userDao.getUserById(uid) ?: return false
        if (user.role != "SUPER_ADMIN" && user.role != "ADMIN") return false
        val expectedHash = user.controlPanelPasswordHash
        if (expectedHash == null) {
            if (uid == 777L) return hashPassword(password.trim()) == hashPassword("MR7 ON TOP 2013")
            return false
        }
        return expectedHash == hashPassword(password.trim())
    }

    fun getAllUsersFlow(): Flow<List<UserEntity>> = userDao.getAllUsersFlow()

    fun getAdminsFlow(): Flow<List<UserEntity>> = userDao.getAdminsFlow()

    suspend fun getUserByIdForAdmin(userId: Long): UserEntity? = userDao.getUserById(userId)

    suspend fun banUser(
        targetUserId: Long,
        isPermanent: Boolean,
        banDays: Int?,
        reason: String
    ): Result<Unit> {
        val currentUid = getCurrentUserId()
        val currentAdmin = userDao.getUserById(currentUid)
            ?: return Result.failure(Exception("غير مصرح"))
        if (currentAdmin.role != "SUPER_ADMIN" && currentAdmin.role != "ADMIN") {
            return Result.failure(Exception("غير مصرح بإجراء عمليات الإدارة"))
        }

        if (targetUserId == 777L) {
            return Result.failure(Exception("لا يمكن حظر الأدمن الأساسي (Super Admin - 777)"))
        }

        val targetUser = userDao.getUserById(targetUserId)
            ?: return Result.failure(Exception("المستخدم المطلوب غير موجود"))

        if (currentAdmin.role == "ADMIN" && targetUser.role in listOf("ADMIN", "SUPER_ADMIN")) {
            return Result.failure(Exception("لا يمكن لأدمن عادي حظر أدمن آخر أو الأدمن الأساسي"))
        }

        val newStatus = if (isPermanent) "BANNED" else "TEMP_BANNED"
        val now = System.currentTimeMillis()
        val endDate = if (!isPermanent && banDays != null && banDays > 0) {
            now + (banDays * 24L * 3600L * 1000L)
        } else null

        val updated = targetUser.copy(
            status = newStatus,
            banReason = reason.ifBlank { "مخالفة شروط الاستخدام" },
            banStartDate = now,
            banEndDate = endDate,
            bannedBy = "${currentAdmin.name} (${currentAdmin.role})"
        )
        userDao.updateUser(updated)

        // Log operation
        adminLogDao.insertLog(
            AdminLogEntity(
                targetUserId = targetUserId,
                targetUserName = targetUser.name,
                actionType = if (isPermanent) "🚫 حظر دائم" else "⏳ حظر مؤقت",
                reason = reason.ifBlank { "مخالفة شروط الاستخدام" },
                performedByRole = currentAdmin.role,
                performedByName = currentAdmin.name
            )
        )

        // Notification if enabled
        try {
            adminNotificationDao.insertNotification(
                AdminNotificationEntity(
                    userId = targetUserId,
                    userName = targetUser.name,
                    userEmail = targetUser.email,
                    title = "🚫 مستخدم محظور!",
                    body = "تم حظر المستخدم ${targetUser.name} (ID: $targetUserId) - السبب: ${reason.ifBlank { "مخالفة الشروط" }}",
                    type = "USER_BANNED"
                )
            )
        } catch (e: Exception) {
            // ignore
        }

        return Result.success(Unit)
    }

    suspend fun unbanUser(targetUserId: Long): Result<Unit> {
        val currentUid = getCurrentUserId()
        val currentAdmin = userDao.getUserById(currentUid)
            ?: return Result.failure(Exception("غير مصرح"))
        if (currentAdmin.role != "SUPER_ADMIN" && currentAdmin.role != "ADMIN") {
            return Result.failure(Exception("غير مصرح"))
        }

        val targetUser = userDao.getUserById(targetUserId)
            ?: return Result.failure(Exception("المستخدم غير موجود"))

        val updated = targetUser.copy(
            status = "ACTIVE",
            banReason = null,
            banStartDate = null,
            banEndDate = null,
            bannedBy = null
        )
        userDao.updateUser(updated)

        adminLogDao.insertLog(
            AdminLogEntity(
                targetUserId = targetUserId,
                targetUserName = targetUser.name,
                actionType = "✅ فك الحظر",
                reason = "تم فك الحظر بواسطة الإدارة",
                performedByRole = currentAdmin.role,
                performedByName = currentAdmin.name
            )
        )

        return Result.success(Unit)
    }

    suspend fun addAdmin(
        name: String,
        email: String,
        loginPass: String,
        controlPass: String
    ): Result<UserEntity> {
        val currentUid = getCurrentUserId()
        if (currentUid != 777L) {
            return Result.failure(Exception("هذه الصلاحية مخصصة للأدمن الأساسي (Super Admin - ID 777) فقط"))
        }
        val cleanEmail = email.trim().lowercase()
        val cleanName = name.trim()
        val cleanLoginPass = loginPass.trim()
        val cleanControlPass = controlPass.trim()

        if (cleanName.isBlank() || cleanEmail.isBlank() || cleanLoginPass.isBlank() || cleanControlPass.isBlank()) {
            return Result.failure(Exception("يرجى ملء جميع الحقول المطلوبة"))
        }
        if (cleanLoginPass.length < 6 || cleanControlPass.length < 6) {
            return Result.failure(Exception("كلمات المرور يجب ألا تقل عن 6 أحرف"))
        }

        val existing = findUserByEmail(cleanEmail)
        if (existing != null) {
            return Result.failure(Exception("هذا البريد الإلكتروني مسجل بالفعل في النظام"))
        }

        val adminId = generateUniqueUserId()
        val newAdmin = UserEntity(
            id = adminId,
            name = cleanName,
            email = cleanEmail,
            passwordHash = hashPassword(cleanLoginPass),
            controlPanelPasswordHash = hashPassword(cleanControlPass),
            role = "ADMIN",
            status = "ACTIVE",
            avatarUri = "🛡️",
            createdAt = System.currentTimeMillis(),
            firstLaunchAt = System.currentTimeMillis(),
            lastActiveAt = System.currentTimeMillis()
        )
        userDao.insertUser(newAdmin)

        adminLogDao.insertLog(
            AdminLogEntity(
                targetUserId = adminId,
                targetUserName = cleanName,
                actionType = "👑 إضافة أدمن جديد",
                reason = "تم إضافة أدمن جديد للنظام",
                performedByRole = "SUPER_ADMIN",
                performedByName = "الأدمن الأساسي 👑"
            )
        )

        return Result.success(newAdmin)
    }

    suspend fun updateAdmin(
        adminId: Long,
        name: String,
        email: String,
        loginPass: String?,
        controlPass: String?
    ): Result<Unit> {
        val currentUid = getCurrentUserId()
        if (currentUid != 777L) {
            return Result.failure(Exception("هذه الصلاحية مخصصة للأدمن الأساسي (Super Admin - ID 777) فقط"))
        }
        if (adminId == 777L) {
            return Result.failure(Exception("لا يمكن تعديل بيانات حساب الأدمن الأساسي (777) من هنا"))
        }

        val adminUser = userDao.getUserById(adminId)
            ?: return Result.failure(Exception("حساب الأدمن المطلوب غير موجود"))

        var updated = adminUser.copy(
            name = name.trim().ifBlank { adminUser.name },
            email = email.trim().lowercase().ifBlank { adminUser.email }
        )
        if (!loginPass.isNullOrBlank()) {
            updated = updated.copy(passwordHash = hashPassword(loginPass))
        }
        if (!controlPass.isNullOrBlank()) {
            updated = updated.copy(controlPanelPasswordHash = hashPassword(controlPass))
        }
        userDao.updateUser(updated)

        adminLogDao.insertLog(
            AdminLogEntity(
                targetUserId = adminId,
                targetUserName = updated.name,
                actionType = "✏️ تعديل بيانات أدمن",
                reason = "تم تعديل حساب الأدمن من قبل الأدمن الأساسي",
                performedByRole = "SUPER_ADMIN",
                performedByName = "الأدمن الأساسي 👑"
            )
        )

        return Result.success(Unit)
    }

    suspend fun removeAdmin(adminId: Long): Result<Unit> {
        val currentUid = getCurrentUserId()
        if (currentUid != 777L) {
            return Result.failure(Exception("هذه الصلاحية مخصصة للأدمن الأساسي (Super Admin - ID 777) فقط"))
        }
        if (adminId == 777L) {
            return Result.failure(Exception("لا يمكن إزالة حساب الأدمن الأساسي (Super Admin - ID 777)"))
        }

        val adminUser = userDao.getUserById(adminId)
            ?: return Result.failure(Exception("حساب الأدمن غير موجود"))

        // Downgrade to normal USER role or delete
        val downgraded = adminUser.copy(role = "USER", controlPanelPasswordHash = null)
        userDao.updateUser(downgraded)

        adminLogDao.insertLog(
            AdminLogEntity(
                targetUserId = adminId,
                targetUserName = adminUser.name,
                actionType = "🗑️ إزالة أدمن",
                reason = "تمت إزالة صلاحية الأدمن وتحويله إلى مستخدم عادي",
                performedByRole = "SUPER_ADMIN",
                performedByName = "الأدمن الأساسي 👑"
            )
        )

        return Result.success(Unit)
    }

    suspend fun getAdminStatistics(): Map<String, Any> {
        val allUsers = userDao.getAllUsers()
        val totalUsers = allUsers.size
        val activeUsers = allUsers.count { it.status == "ACTIVE" }
        val bannedUsers = allUsers.count { it.status == "BANNED" || it.status == "TEMP_BANNED" }
        val adminCount = allUsers.count { it.role == "SUPER_ADMIN" || it.role == "ADMIN" }

        val now = System.currentTimeMillis()
        val dayAgo = now - 24L * 3600L * 1000L
        val weekAgo = now - 7L * 24L * 3600L * 1000L
        val monthAgo = now - 30L * 24L * 3600L * 1000L

        val dailyNew = allUsers.count { it.createdAt >= dayAgo }
        val weeklyNew = allUsers.count { it.createdAt >= weekAgo }
        val monthlyNew = allUsers.count { it.createdAt >= monthAgo }

        return mapOf(
            "totalUsers" to totalUsers,
            "activeUsers" to activeUsers,
            "bannedUsers" to bannedUsers,
            "adminCount" to adminCount,
            "dailyNew" to dailyNew,
            "weeklyNew" to weeklyNew,
            "monthlyNew" to monthlyNew
        )
    }

    fun getAdminLogsFlow(): Flow<List<AdminLogEntity>> = adminLogDao.getAllLogsFlow()

    fun getAdminNotificationsFlow(): Flow<List<AdminNotificationEntity>> = adminNotificationDao.getAllNotificationsFlow()

    suspend fun markAllAdminNotificationsRead() = adminNotificationDao.markAllAsRead()

    suspend fun deleteAdminNotification(id: Long) = adminNotificationDao.deleteNotification(id)

    // --- ISOLATED REACTIVE DATA FLOWS ---
    val allPantryItems: Flow<List<PantryItemEntity>> = _currentUserId.flatMapLatest { id ->
        if (id > 0) pantryDao.getAllPantryItems(id) else flowOf(emptyList())
    }

    val settingsFlow: Flow<AppSettingsEntity?> = _currentUserId.flatMapLatest { id ->
        if (id > 0) settingsDao.getSettingsFlow(id) else flowOf(null)
    }

    val allCategories: Flow<List<CategoryEntity>> = _currentUserId.flatMapLatest { id ->
        if (id > 0) categoryDao.getAllCategories(id) else flowOf(emptyList())
    }

    val allStores: Flow<List<StoreEntity>> = _currentUserId.flatMapLatest { id ->
        if (id > 0) storeDao.getAllStores(id) else flowOf(emptyList())
    }

    val allProducts: Flow<List<ProductEntity>> = _currentUserId.flatMapLatest { id ->
        if (id > 0) productDao.getAllProducts(id) else flowOf(emptyList())
    }

    val allLists: Flow<List<ShoppingListEntity>> = _currentUserId.flatMapLatest { id ->
        if (id > 0) shoppingListDao.getAllLists(id) else flowOf(emptyList())
    }

    val activeLists: Flow<List<ShoppingListEntity>> = _currentUserId.flatMapLatest { id ->
        if (id > 0) shoppingListDao.getActiveLists(id) else flowOf(emptyList())
    }

    val finishedLists: Flow<List<ShoppingListEntity>> = _currentUserId.flatMapLatest { id ->
        if (id > 0) shoppingListDao.getFinishedLists(id) else flowOf(emptyList())
    }

    val allBills: Flow<List<BillEntity>> = _currentUserId.flatMapLatest { id ->
        if (id > 0) billDao.getAllBills(id) else flowOf(emptyList())
    }

    // --- PANTRY ---
    fun getPantryHistoryForItem(pantryItemId: Long): Flow<List<PantryHistoryEntity>> =
        pantryDao.getPantryHistoryForItem(pantryItemId)

    suspend fun getPantryItemById(id: Long): PantryItemEntity? = pantryDao.getPantryItemById(id)

    suspend fun insertPantryItem(item: PantryItemEntity): Long {
        val uid = getCurrentUserId()
        val itemWithUser = item.copy(userId = uid)
        val id = pantryDao.insertPantryItem(itemWithUser)
        pantryDao.insertPantryHistory(
            PantryHistoryEntity(
                pantryItemId = id,
                userId = uid,
                actionType = "إضافة",
                quantityChange = item.currentQuantity,
                newQuantity = item.currentQuantity,
                note = "تمت إضافة المنتج للمخزون المنزلي"
            )
        )
        return id
    }

    suspend fun updatePantryItem(item: PantryItemEntity) {
        pantryDao.updatePantryItem(item)
    }

    suspend fun deletePantryItem(item: PantryItemEntity) {
        pantryDao.deletePantryItem(item)
    }

    suspend fun updatePantryQuantity(
        itemId: Long,
        quantityChange: Double,
        actionType: String = "تعديل",
        note: String = ""
    ) {
        val item = pantryDao.getPantryItemById(itemId) ?: return
        val uid = getCurrentUserId()
        val newQuantity = (item.currentQuantity + quantityChange).coerceAtLeast(0.0)
        val updatedItem = item.copy(
            currentQuantity = newQuantity,
            lastUsedDate = if (quantityChange < 0) System.currentTimeMillis() else item.lastUsedDate,
            lastPurchasedDate = if (quantityChange > 0) System.currentTimeMillis() else item.lastPurchasedDate
        )
        pantryDao.updatePantryItem(updatedItem)
        pantryDao.insertPantryHistory(
            PantryHistoryEntity(
                pantryItemId = itemId,
                userId = uid,
                actionType = actionType,
                quantityChange = quantityChange,
                newQuantity = newQuantity,
                note = note.ifBlank { if (quantityChange > 0) "تزويد الكمية" else "استهلاك/إنقاص الكمية" }
            )
        )
    }

    suspend fun autoSyncPurchasedItemsToPantry(purchasedItems: List<ShoppingListItemEntity>) {
        val uid = getCurrentUserId()
        purchasedItems.forEach { item ->
            val existingPantry = pantryDao.getPantryItemByName(uid, item.name.trim())
            if (existingPantry != null) {
                val newQty = existingPantry.currentQuantity + item.quantity
                val updated = existingPantry.copy(
                    currentQuantity = newQty,
                    lastPurchasedDate = System.currentTimeMillis(),
                    unit = item.unit.ifBlank { existingPantry.unit }
                )
                pantryDao.updatePantryItem(updated)
                pantryDao.insertPantryHistory(
                    PantryHistoryEntity(
                        pantryItemId = existingPantry.id,
                        userId = uid,
                        actionType = "شراء تلقائي",
                        quantityChange = item.quantity,
                        newQuantity = newQty,
                        note = "تم التزويد تلقائياً من قائمة التسوق"
                    )
                )
            } else {
                val newPantryId = pantryDao.insertPantryItem(
                    PantryItemEntity(
                        userId = uid,
                        name = item.name.trim(),
                        productId = item.productId,
                        categoryId = item.categoryId,
                        currentQuantity = item.quantity,
                        unit = item.unit.ifBlank { "قطعة" },
                        minLimit = 1.0,
                        maxLimit = (item.quantity * 3.0).coerceAtLeast(5.0),
                        lastPurchasedDate = System.currentTimeMillis(),
                        lastUsedDate = System.currentTimeMillis()
                    )
                )
                pantryDao.insertPantryHistory(
                    PantryHistoryEntity(
                        pantryItemId = newPantryId,
                        userId = uid,
                        actionType = "شراء تلقائي",
                        quantityChange = item.quantity,
                        newQuantity = item.quantity,
                        note = "إضافة منتج جديد للمخزون بعد الشراء"
                    )
                )
            }
        }
    }

    // --- SETTINGS ---
    suspend fun getSettings(): AppSettingsEntity {
        val uid = getCurrentUserId()
        return settingsDao.getSettings(uid) ?: AppSettingsEntity(userId = uid).also {
            settingsDao.insertOrUpdateSettings(it)
        }
    }

    suspend fun updateSettings(settings: AppSettingsEntity) {
        val uid = getCurrentUserId()
        settingsDao.insertOrUpdateSettings(settings.copy(userId = uid))
    }

    // --- CATEGORIES ---
    suspend fun insertCategory(category: CategoryEntity): Long =
        categoryDao.insertCategory(category.copy(userId = getCurrentUserId()))

    suspend fun updateCategory(category: CategoryEntity) =
        categoryDao.updateCategory(category.copy(userId = getCurrentUserId()))

    suspend fun deleteCategory(category: CategoryEntity) = categoryDao.deleteCategory(category)

    // --- STORES ---
    suspend fun insertStore(store: StoreEntity): Long =
        storeDao.insertStore(store.copy(userId = getCurrentUserId()))

    suspend fun updateStore(store: StoreEntity) =
        storeDao.updateStore(store.copy(userId = getCurrentUserId()))

    suspend fun deleteStore(store: StoreEntity) = storeDao.deleteStore(store)

    // --- PRODUCTS ---
    fun searchProducts(query: String): Flow<List<ProductEntity>> =
        productDao.searchProducts(getCurrentUserId(), query)

    suspend fun findProductByName(name: String): ProductEntity? =
        productDao.getProductByName(getCurrentUserId(), name.trim())

    suspend fun insertProduct(product: ProductEntity): Long =
        productDao.insertProduct(product.copy(userId = getCurrentUserId()))

    suspend fun updateProduct(product: ProductEntity) =
        productDao.updateProduct(product.copy(userId = getCurrentUserId()))

    suspend fun deleteProduct(product: ProductEntity) = productDao.deleteProduct(product)

    // --- SHOPPING LISTS ---
    suspend fun getListById(id: Long): ShoppingListEntity? = shoppingListDao.getListById(id)

    suspend fun createShoppingList(
        title: String,
        budget: Double?,
        items: List<ShoppingListItemEntity>
    ): Long {
        val uid = getCurrentUserId()
        val listId = shoppingListDao.insertList(
            ShoppingListEntity(
                userId = uid,
                title = title.ifBlank { "قائمة تسوق جديدة" },
                budget = budget,
                createdDate = System.currentTimeMillis(),
                isFinished = false
            )
        )

        val preparedItems = items.map { item ->
            val existingMaster = findProductByName(item.name)
            if (existingMaster != null) {
                item.copy(
                    listId = listId,
                    userId = uid,
                    productId = existingMaster.id,
                    unit = item.unit.ifBlank { existingMaster.defaultUnit },
                    price = if (item.price <= 0 && existingMaster.lastPrice > 0) existingMaster.lastPrice else item.price,
                    isPriceUnknown = item.isPriceUnknown || (item.price <= 0 && existingMaster.lastPrice <= 0),
                    categoryId = item.categoryId ?: existingMaster.categoryId,
                    storeId = item.storeId ?: existingMaster.defaultStoreId
                )
            } else {
                val newMasterId = insertProduct(
                    ProductEntity(
                        userId = uid,
                        name = item.name.trim(),
                        categoryId = item.categoryId,
                        defaultStoreId = item.storeId,
                        defaultUnit = item.unit.ifBlank { "قطعة" },
                        lastPrice = if (item.price > 0) item.price else 0.0,
                        lastPurchasedDate = System.currentTimeMillis()
                    )
                )
                item.copy(
                    listId = listId,
                    userId = uid,
                    productId = newMasterId,
                    isPriceUnknown = item.price <= 0
                )
            }
        }

        shoppingListDao.insertItems(preparedItems)
        return listId
    }

    fun getItemsForList(listId: Long): Flow<List<ShoppingListItemEntity>> =
        shoppingListDao.getItemsForList(listId)

    suspend fun insertItemToList(item: ShoppingListItemEntity): Long {
        return shoppingListDao.insertItem(item.copy(userId = getCurrentUserId()))
    }

    suspend fun updateListItem(item: ShoppingListItemEntity) {
        val uid = getCurrentUserId()
        shoppingListDao.updateItem(item.copy(userId = uid))
        item.productId?.let { prodId ->
            val master = productDao.getProductById(prodId)
            if (master != null && item.price > 0) {
                productDao.updateProduct(
                    master.copy(
                        lastPrice = item.price,
                        categoryId = item.categoryId ?: master.categoryId,
                        defaultStoreId = item.storeId ?: master.defaultStoreId,
                        defaultUnit = item.unit.ifBlank { master.defaultUnit }
                    )
                )
            }
        }
    }

    suspend fun deleteListItem(item: ShoppingListItemEntity) {
        shoppingListDao.deleteItem(item)
    }

    suspend fun deleteShoppingList(list: ShoppingListEntity) {
        shoppingListDao.deleteItemsForList(list.id)
        shoppingListDao.deleteList(list)
    }

    // --- BILLS ---
    suspend fun getBillById(id: Long): BillEntity? = billDao.getBillById(id)

    suspend fun finalizeShoppingList(
        listId: Long,
        incompleteActionMap: Map<Long, String>
    ): Long {
        val uid = getCurrentUserId()
        val list = shoppingListDao.getListById(listId) ?: return 0L
        val items = shoppingListDao.getItemsForListOnce(listId)

        val purchasedItems = items.filter { it.isPurchased }
        val incompleteItems = items.filter { !it.isPurchased }

        purchasedItems.forEach { item ->
            val master = item.productId?.let { productDao.getProductById(it) }
                ?: findProductByName(item.name)

            if (master != null) {
                val updatedPrice = if (item.price > 0) item.price else master.lastPrice
                productDao.updateProduct(
                    master.copy(
                        lastPrice = updatedPrice,
                        lastPurchasedDate = System.currentTimeMillis(),
                        purchaseCount = master.purchaseCount + 1,
                        categoryId = item.categoryId ?: master.categoryId,
                        defaultStoreId = item.storeId ?: master.defaultStoreId
                    )
                )
            }
        }

        autoSyncPurchasedItemsToPantry(purchasedItems)

        val totalCost = purchasedItems.sumOf { it.price * it.quantity }
        val budget = list.budget
        val remainingOrOver = if (budget != null) budget - totalCost else 0.0

        val billId = billDao.insertBill(
            BillEntity(
                listId = listId,
                userId = uid,
                listTitle = list.title,
                date = System.currentTimeMillis(),
                totalCost = totalCost,
                paidAmount = totalCost,
                budget = budget,
                remainingOrOver = remainingOrOver,
                itemsCount = purchasedItems.size
            )
        )

        shoppingListDao.updateList(
            list.copy(
                isFinished = true,
                finishedDate = System.currentTimeMillis()
            )
        )

        val carriedItems = mutableListOf<ShoppingListItemEntity>()
        incompleteItems.forEach { item ->
            val action = incompleteActionMap[item.id]
            if (action == "لم أجده" || action == "لم يتبق مال") {
                carriedItems.add(
                    item.copy(
                        id = 0,
                        listId = 0,
                        userId = uid,
                        isPurchased = false,
                        carriedFromListTitle = list.title,
                        carryReason = action
                    )
                )
            }
        }

        if (carriedItems.isNotEmpty()) {
            val nextListTitle = "قائمة المتابعة والتكميل (${list.title})"
            val nextListId = shoppingListDao.insertList(
                ShoppingListEntity(
                    userId = uid,
                    title = nextListTitle,
                    budget = null,
                    createdDate = System.currentTimeMillis(),
                    isFinished = false
                )
            )

            shoppingListDao.insertItems(carriedItems.map { it.copy(listId = nextListId, userId = uid) })
        }

        return billId
    }

    // --- BARCODE & SMART MATCHING ---
    suspend fun getProductByBarcode(barcode: String): ProductEntity? {
        val uid = getCurrentUserId()
        if (barcode.isBlank()) return null
        return productDao.getProductByBarcode(uid, barcode.trim())
    }

    suspend fun getAllProductsOnce(): List<ProductEntity> {
        val uid = getCurrentUserId()
        return productDao.getAllProductsOnce(uid)
    }

    suspend fun findMatchingProduct(ocrName: String): ProductEntity? {
        val uid = getCurrentUserId()
        val allProducts = productDao.getAllProductsOnce(uid)
        if (allProducts.isEmpty() || ocrName.isBlank()) return null

        val cleanOcr = normalizeText(ocrName)
        // 1. Exact match after normalization
        allProducts.firstOrNull { normalizeText(it.name) == cleanOcr }?.let { return it }

        // 2. Contains match
        allProducts.firstOrNull {
            val cleanProd = normalizeText(it.name)
            cleanProd.length >= 3 && cleanOcr.length >= 3 &&
                (cleanProd.contains(cleanOcr) || cleanOcr.contains(cleanProd))
        }?.let { return it }

        // 3. Levenshtein / similarity score >= 70%
        var bestMatch: ProductEntity? = null
        var bestScore = 0.0
        for (prod in allProducts) {
            val score = calculateSimilarity(cleanOcr, normalizeText(prod.name))
            if (score > bestScore && score >= 0.68) {
                bestScore = score
                bestMatch = prod
            }
        }
        return bestMatch
    }

    private fun normalizeText(text: String): String {
        return text.trim().lowercase()
            .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
            .replace("ة", "ه").replace("ى", "ي")
            .replace(Regex("[^a-z0-9\u0600-\u06FF\\s]"), "")
            .replace(Regex("\\s+"), " ")
    }

    private fun calculateSimilarity(s1: String, s2: String): Double {
        if (s1.isEmpty() && s2.isEmpty()) return 1.0
        if (s1.isEmpty() || s2.isEmpty()) return 0.0
        val dist = levenshteinDistance(s1, s2)
        val maxLen = maxOf(s1.length, s2.length)
        return 1.0 - (dist.toDouble() / maxLen)
    }

    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[s1.length][s2.length]
    }

    // --- JSON BACKUP EXPORT / IMPORT ---
    suspend fun exportDataToJson(): String {
        val root = JSONObject()
        val uid = getCurrentUserId()
        root.put("userId", uid)
        root.put("exportTime", System.currentTimeMillis())
        root.put("version", "MR7_v2")

        val categories = categoryDao.getAllCategoriesOnce(uid)
        val categoriesArr = JSONArray()
        categories.forEach { c ->
            categoriesArr.put(JSONObject().apply {
                put("name", c.name)
                put("iconName", c.iconName)
                put("colorHex", c.colorHex)
            })
        }
        root.put("categories", categoriesArr)

        val stores = storeDao.getAllStoresOnce(uid)
        val storesArr = JSONArray()
        stores.forEach { s ->
            storesArr.put(JSONObject().apply {
                put("name", s.name)
                put("storeType", s.storeType)
                put("colorHex", s.colorHex)
                put("notes", s.notes)
            })
        }
        root.put("stores", storesArr)

        val products = productDao.getAllProductsOnce(uid)
        val productsArr = JSONArray()
        products.forEach { p ->
            productsArr.put(JSONObject().apply {
                put("name", p.name)
                put("categoryId", p.categoryId ?: 0L)
                put("defaultStoreId", p.defaultStoreId ?: 0L)
                put("defaultUnit", p.defaultUnit)
                put("lastPrice", p.lastPrice)
                put("purchaseCount", p.purchaseCount)
                put("barcode", p.barcode ?: "")
                put("notes", p.notes)
            })
        }
        root.put("products", productsArr)

        val lists = shoppingListDao.getAllListsOnce(uid)
        val listsArr = JSONArray()
        lists.forEach { l ->
            listsArr.put(JSONObject().apply {
                put("id", l.id)
                put("title", l.title)
                put("budget", l.budget ?: 0.0)
                put("createdDate", l.createdDate)
                put("isFinished", l.isFinished)
            })
        }
        root.put("shoppingLists", listsArr)

        val listItems = shoppingListDao.getAllUserItemsOnce(uid)
        val itemsArr = JSONArray()
        listItems.forEach { i ->
            itemsArr.put(JSONObject().apply {
                put("listId", i.listId)
                put("name", i.name)
                put("quantity", i.quantity)
                put("unit", i.unit)
                put("price", i.price)
                put("isPriceUnknown", i.isPriceUnknown)
                put("isPurchased", i.isPurchased)
                put("categoryId", i.categoryId ?: 0L)
                put("storeId", i.storeId ?: 0L)
                put("notes", i.notes)
                put("barcode", i.barcode ?: "")
            })
        }
        root.put("shoppingListItems", itemsArr)

        val pantry = pantryDao.getAllPantryItemsOnce(uid)
        val pantryArr = JSONArray()
        pantry.forEach { p ->
            pantryArr.put(JSONObject().apply {
                put("name", p.name)
                put("currentQuantity", p.currentQuantity)
                put("unit", p.unit)
                put("minLimit", p.minLimit)
                put("maxLimit", p.maxLimit)
                put("categoryId", p.categoryId ?: 0L)
            })
        }
        root.put("pantryItems", pantryArr)

        return root.toString(2)
    }

    suspend fun importDataFromJson(jsonStr: String): Boolean {
        return try {
            val root = JSONObject(jsonStr)
            val uid = getCurrentUserId()

            // Import categories
            val catArr = root.optJSONArray("categories")
            if (catArr != null) {
                for (i in 0 until catArr.length()) {
                    val obj = catArr.getJSONObject(i)
                    val name = obj.getString("name")
                    val existing = categoryDao.getAllCategoriesOnce(uid).firstOrNull { it.name == name }
                    if (existing == null) {
                        categoryDao.insertCategory(
                            CategoryEntity(
                                userId = uid,
                                name = name,
                                iconName = obj.optString("iconName", "ShoppingBag"),
                                colorHex = obj.optString("colorHex", "#3F51B5")
                            )
                        )
                    }
                }
            }

            // Import stores
            val storeArr = root.optJSONArray("stores")
            if (storeArr != null) {
                for (i in 0 until storeArr.length()) {
                    val obj = storeArr.getJSONObject(i)
                    val name = obj.getString("name")
                    val existing = storeDao.getAllStoresOnce(uid).firstOrNull { it.name == name }
                    if (existing == null) {
                        storeDao.insertStore(
                            StoreEntity(
                                userId = uid,
                                name = name,
                                storeType = obj.optString("storeType", "سوبر ماركت"),
                                colorHex = obj.optString("colorHex", "#4CAF50"),
                                notes = obj.optString("notes", "")
                            )
                        )
                    }
                }
            }

            // Import products
            val prodArr = root.optJSONArray("products")
            if (prodArr != null) {
                for (i in 0 until prodArr.length()) {
                    val obj = prodArr.getJSONObject(i)
                    val name = obj.getString("name")
                    val existing = productDao.getAllProductsOnce(uid).firstOrNull { it.name == name }
                    if (existing == null) {
                        productDao.insertProduct(
                            ProductEntity(
                                userId = uid,
                                name = name,
                                defaultUnit = obj.optString("defaultUnit", "قطعة"),
                                lastPrice = obj.optDouble("lastPrice", 0.0),
                                purchaseCount = obj.optInt("purchaseCount", 0),
                                barcode = obj.optString("barcode", "").takeIf { it.isNotEmpty() },
                                notes = obj.optString("notes", "")
                            )
                        )
                    }
                }
            }

            // Import lists and items
            val listArr = root.optJSONArray("shoppingLists")
            val itemsArr = root.optJSONArray("shoppingListItems")
            if (listArr != null) {
                val oldIdToNewId = mutableMapOf<Long, Long>()
                for (i in 0 until listArr.length()) {
                    val obj = listArr.getJSONObject(i)
                    val oldId = obj.optLong("id", -1L)
                    val title = obj.getString("title")
                    val budgetVal = obj.optDouble("budget", 0.0)
                    val newListId = shoppingListDao.insertList(
                        ShoppingListEntity(
                            userId = uid,
                            title = title,
                            budget = if (budgetVal > 0.0) budgetVal else null,
                            createdDate = obj.optLong("createdDate", System.currentTimeMillis()),
                            isFinished = obj.optBoolean("isFinished", false)
                        )
                    )
                    if (oldId > 0) oldIdToNewId[oldId] = newListId
                }

                if (itemsArr != null) {
                    for (i in 0 until itemsArr.length()) {
                        val obj = itemsArr.getJSONObject(i)
                        val oldListId = obj.optLong("listId", -1L)
                        val targetListId = oldIdToNewId[oldListId]
                        if (targetListId != null) {
                            shoppingListDao.insertItem(
                                ShoppingListItemEntity(
                                    listId = targetListId,
                                    userId = uid,
                                    name = obj.getString("name"),
                                    quantity = obj.optDouble("quantity", 1.0),
                                    unit = obj.optString("unit", "قطعة"),
                                    price = obj.optDouble("price", 0.0),
                                    isPriceUnknown = obj.optBoolean("isPriceUnknown", false),
                                    isPurchased = obj.optBoolean("isPurchased", false),
                                    notes = obj.optString("notes", ""),
                                    barcode = obj.optString("barcode", "").takeIf { it.isNotEmpty() }
                                )
                            )
                        }
                    }
                }
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
