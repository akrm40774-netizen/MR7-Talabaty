package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.viewmodel.MainViewModel
import com.example.ui.screens.AboutAppScreen
import com.example.ui.screens.HelpCenterScreen
import com.example.ui.screens.AdminControlPanelScreen
import com.example.ui.screens.BillDetailScreen
import com.example.ui.screens.BillsScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.CreateListScreen
import com.example.ui.screens.ForgotPasswordScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainScreen
import com.example.ui.screens.MyAccountScreen
import com.example.ui.screens.PantryScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ShoppingActiveScreen
import com.example.ui.screens.ShoppingListsScreen
import com.example.ui.screens.SignUpScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.StatisticsScreen
import com.example.ui.screens.StoresScreen
import com.example.ui.screens.WelcomeAuthScreen
import com.example.ui.theme.MR7TalabatiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val mainViewModel: MainViewModel = viewModel()
            val settings by mainViewModel.settingsState.collectAsState()
            val userMessage by mainViewModel.userMessage.collectAsState()
            val context = LocalContext.current

            LaunchedEffect(userMessage) {
                userMessage?.let { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    mainViewModel.clearUserMessage()
                }
            }

            MR7TalabatiTheme(darkTheme = settings.darkTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigation(viewModel = mainViewModel)
                }
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "splash"
    ) {
        composable("splash") {
            SplashScreen(
                onTimeout = {
                    viewModel.checkSession { isValidSession ->
                        if (isValidSession) {
                            navController.navigate("main") {
                                popUpTo("splash") { inclusive = true }
                            }
                        } else {
                            navController.navigate("welcome_auth") {
                                popUpTo("splash") { inclusive = true }
                            }
                        }
                    }
                }
            )
        }

        composable("welcome_auth") {
            WelcomeAuthScreen(
                onNavigateToLogin = { navController.navigate("login") },
                onNavigateToSignUp = { navController.navigate("signup") }
            )
        }

        composable("login") {
            LoginScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onLoginSuccess = {
                    navController.navigate("main") {
                        popUpTo("welcome_auth") { inclusive = true }
                    }
                },
                onNavigateToSignUp = {
                    navController.navigate("signup") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToForgotPassword = {
                    navController.navigate("forgot_password")
                }
            )
        }

        composable("signup") {
            SignUpScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onSignUpSuccess = {
                    navController.navigate("main") {
                        popUpTo("welcome_auth") { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    navController.navigate("login") {
                        popUpTo("signup") { inclusive = true }
                    }
                }
            )
        }

        composable("forgot_password") {
            ForgotPasswordScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onResetSuccess = {
                    navController.navigate("login") {
                        popUpTo("forgot_password") { inclusive = true }
                    }
                }
            )
        }

        composable("main") {
            MainScreen(
                viewModel = viewModel,
                onNavigate = { route ->
                    navController.navigate(route)
                }
            )
        }

        composable("my_account") {
            MyAccountScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onLoggedOut = {
                    navController.navigate("welcome_auth") {
                        popUpTo("main") { inclusive = true }
                    }
                },
                onNavigateToAdminPanel = {
                    navController.navigate("admin_control_panel")
                }
            )
        }

        composable("create_list") {
            CreateListScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onListCreated = { listId ->
                    navController.navigate("shopping_active/$listId") {
                        popUpTo("main")
                    }
                }
            )
        }

        composable("lists") {
            ShoppingListsScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onOpenList = { listId ->
                    navController.navigate("shopping_active/$listId")
                },
                onCreateNewClick = {
                    navController.navigate("create_list")
                }
            )
        }

        composable(
            route = "shopping_active/{listId}",
            arguments = listOf(navArgument("listId") { type = NavType.LongType })
        ) { backStackEntry ->
            val listId = backStackEntry.arguments?.getLong("listId") ?: 0L
            ShoppingActiveScreen(
                listId = listId,
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onFinishToBill = { billId ->
                    navController.navigate("bill_detail/$billId") {
                        popUpTo("main")
                    }
                }
            )
        }

        composable("products") {
            ProductsScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("categories") {
            CategoriesScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("stores") {
            StoresScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("bills") {
            BillsScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onBillClick = { billId ->
                    navController.navigate("bill_detail/$billId")
                }
            )
        }

        composable(
            route = "bill_detail/{billId}",
            arguments = listOf(navArgument("billId") { type = NavType.LongType })
        ) { backStackEntry ->
            val billId = backStackEntry.arguments?.getLong("billId") ?: 0L
            BillDetailScreen(
                billId = billId,
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("statistics") {
            StatisticsScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("pantry") {
            PantryScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onOpenCreateListWithItems = { listId ->
                    navController.navigate("shopping_active/$listId") {
                        popUpTo("main")
                    }
                }
            )
        }

        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onBackClick = { navController.popBackStack() },
                onNavigateToAccount = { navController.navigate("my_account") },
                onNavigateToStores = { navController.navigate("stores") },
                onNavigateToCategories = { navController.navigate("categories") },
                onNavigateToBills = { navController.navigate("bills") },
                onNavigateToHelp = { navController.navigate("help_center") },
                onNavigateToAbout = { navController.navigate("about_app") },
                onNavigateToAdmin = { navController.navigate("admin_control_panel") }
            )
        }

        composable("help_center") {
            HelpCenterScreen(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("about_app") {
            AboutAppScreen(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("admin_control_panel") {
            val currentUser by viewModel.currentUserState.collectAsState()
            currentUser?.let { user ->
                AdminControlPanelScreen(
                    viewModel = viewModel,
                    currentUser = user,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
