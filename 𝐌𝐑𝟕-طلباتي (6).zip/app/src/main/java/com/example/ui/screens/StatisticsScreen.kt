package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.viewmodel.MainViewModel
import com.example.ui.components.AppTopBar
import com.example.ui.components.CurrencyFormatter
import com.example.ui.components.RtlProvider
import com.example.ui.components.StatCard

@Composable
fun StatisticsScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit
) {
    val activeLists by viewModel.activeListsState.collectAsState()
    val finishedLists by viewModel.finishedListsState.collectAsState()
    val bills by viewModel.billsState.collectAsState()
    val products by viewModel.productsState.collectAsState()
    val categories by viewModel.categoriesState.collectAsState()
    val stores by viewModel.storesState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()

    // Analytics calculations
    val totalListsCount = activeLists.size + finishedLists.size
    val totalProductsCount = products.size
    val totalSpent = bills.sumOf { it.totalCost }
    val averageSpendPerList = if (bills.isNotEmpty()) totalSpent / bills.size else 0.0

    val topProduct = remember(products) {
        products.maxByOrNull { it.purchaseCount }?.name ?: "غير متوفر"
    }

    val mostVisitedStore = remember(stores, products) {
        val storeCounts = products.mapNotNull { it.defaultStoreId }.groupingBy { it }.eachCount()
        val topStoreId = storeCounts.maxByOrNull { it.value }?.key
        stores.find { it.id == topStoreId }?.name ?: stores.firstOrNull()?.name ?: "غير متوفر"
    }

    val mostUsedCategory = remember(categories, products) {
        val catCounts = products.mapNotNull { it.categoryId }.groupingBy { it }.eachCount()
        val topCatId = catCounts.maxByOrNull { it.value }?.key
        categories.find { it.id == topCatId }?.name ?: categories.firstOrNull()?.name ?: "غير متوفر"
    }

    RtlProvider {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = "الإحصائيات والتقارير",
                    onBackClick = onBackClick
                )
            }
        ) { paddingValues ->
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Banner Card
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "إجمالي المصروفات والنفقات",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${CurrencyFormatter.format(totalSpent)} ${settings.currency}",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                            Text(
                                text = "متوسط الإنفاق لكل قائمة: ${CurrencyFormatter.format(averageSpendPerList)} ${settings.currency}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            title = "إجمالي القوائم",
                            value = "$totalListsCount قائمة",
                            icon = Icons.Default.FormatListBulleted,
                            accentColor = Color(0xFF0077B6),
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "إجمالي المنتجات",
                            value = "$totalProductsCount منتج",
                            icon = Icons.Default.Inventory,
                            accentColor = Color(0xFF7209B7),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            title = "الفواتير المسجلة",
                            value = "${bills.size} فاتورة",
                            icon = Icons.Default.ReceiptLong,
                            accentColor = Color(0xFF0284C7),
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "المتجر الأوفر زيارة",
                            value = mostVisitedStore,
                            icon = Icons.Default.Store,
                            accentColor = Color(0xFFD97706),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            title = "التصنيف الأكثر استخداماً",
                            value = mostUsedCategory,
                            icon = Icons.Default.Category,
                            accentColor = Color(0xFF3A0CA3),
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "المنتج الأكثر شراءً",
                            value = topProduct,
                            icon = Icons.Default.ShoppingBag,
                            accentColor = Color(0xFF0F684B),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
