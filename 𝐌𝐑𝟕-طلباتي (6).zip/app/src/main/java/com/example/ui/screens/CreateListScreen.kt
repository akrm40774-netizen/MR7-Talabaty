package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.api.GeminiAssistantService
import com.example.data.local.entity.ShoppingListItemEntity
import com.example.data.viewmodel.MainViewModel
import com.example.ui.components.AppTopBar
import com.example.ui.components.CategoryBadge
import com.example.ui.components.CurrencyFormatter
import com.example.ui.components.RtlProvider
import com.example.ui.components.SmartBarcodeDialog
import com.example.ui.components.SmartOcrReviewDialog
import com.example.ui.components.SmartQuickActionBar
import com.example.ui.components.SmartVoiceDialog
import com.example.ui.components.rememberCameraPermissionHandler
import com.example.ui.components.rememberAudioPermissionHandler
import com.example.ui.components.StoreBadge
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateListScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit,
    onListCreated: (Long) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf("محتويات الأسبوع") }
    var budgetText by remember { mutableStateOf("") }

    val categories by viewModel.categoriesState.collectAsState()
    val stores by viewModel.storesState.collectAsState()
    val allProducts by viewModel.productsState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()

    val draftItems = remember { mutableStateOf(listOf<ShoppingListItemEntity>()) }

    // Add item form state
    var itemNameInput by remember { mutableStateOf("") }
    var itemQtyInput by remember { mutableStateOf("1") }
    var itemUnitInput by remember { mutableStateOf("قطعة") }
    var itemPriceInput by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf<Long?>(null) }
    var selectedStoreId by remember { mutableStateOf<Long?>(null) }

    var itemSuggestionsExpanded by remember { mutableStateOf(false) }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }
    var storeDropdownExpanded by remember { mutableStateOf(false) }

    // Gemini AI Assistant state
    var showAiDialog by remember { mutableStateOf(false) }
    var aiPromptInput by remember { mutableStateOf("") }
    var isAiLoading by remember { mutableStateOf(false) }

    // Smart Input Dialogs (OCR, Barcode, Voice)
    var showOcrDialog by remember { mutableStateOf(false) }
    var showBarcodeDialog by remember { mutableStateOf(false) }
    var showVoiceDialog by remember { mutableStateOf(false) }

    val cameraPermissionHandler = rememberCameraPermissionHandler(
        onPermissionGranted = { showOcrDialog = true }
    )
    val barcodePermissionHandler = rememberCameraPermissionHandler(
        onPermissionGranted = { showBarcodeDialog = true }
    )
    val audioPermissionHandler = rememberAudioPermissionHandler(
        onPermissionGranted = { showVoiceDialog = true }
    )

    // Voice recognition launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                itemNameInput = spokenText
                val master = allProducts.find { it.name.equals(spokenText.trim(), ignoreCase = true) }
                if (master != null) {
                    selectedCategoryId = master.categoryId
                    selectedStoreId = master.defaultStoreId
                    itemUnitInput = master.defaultUnit
                    if (master.lastPrice > 0) itemPriceInput = master.lastPrice.toString()
                }
                Toast.makeText(context, "تم الصوت: $spokenText", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun launchVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "𝐌𝐑𝟕 MIC")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "ميزة التعرف على الصوت غير متاحة على هذا الجهاز", Toast.LENGTH_SHORT).show()
        }
    }

    // Auto-fill logic when user selects/types a product
    fun applyMasterProductDefaults(productName: String) {
        val master = allProducts.find { it.name.equals(productName.trim(), ignoreCase = true) }
        if (master != null) {
            selectedCategoryId = master.categoryId
            selectedStoreId = master.defaultStoreId
            itemUnitInput = master.defaultUnit
            if (master.lastPrice > 0) {
                itemPriceInput = master.lastPrice.toString()
            }
        }
    }

    RtlProvider {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = "إنشاء قائمة تسوق جديدة",
                    onBackClick = onBackClick
                )
            },
            bottomBar = {
                Surface(
                    tonalElevation = 6.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = {
                                val budgetVal = budgetText.toDoubleOrNull()
                                viewModel.createList(
                                    title = title,
                                    budget = budgetVal,
                                    items = draftItems.value,
                                    onCreated = onListCreated
                                )
                            },
                            enabled = draftItems.value.isNotEmpty(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_save_and_start"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "بدء التسوق الآن 🛒 (${draftItems.value.size} منتج)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Gemini AI Assistant Banner Button
                item {
                    Card(
                        onClick = { showAiDialog = true },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_gemini_ai_assistant")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "𝐌𝐑𝟕|intelligence",
                                            tint = Color.White
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "المساعد الذكي (𝐌𝐑𝟕|intelligence)",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Text(
                                        text = "أنشئ قائمة التسوق تلقائياً بالذكاء الاصطناعي",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                    )
                                }
                            }
                            Text(
                                text = "توليد ✨",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                // Section 1: Details Card ("تفاصيل القائمة")
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "تفاصيل القائمة",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it },
                                label = { Text("اسم القائمة (مثال: محتويات الأسبوع)") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_list_title")
                            )

                            OutlinedTextField(
                                value = budgetText,
                                onValueChange = { budgetText = it },
                                label = { Text("الميزانية المحددة (${settings.currency}) (اختياري)") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_list_budget")
                            )
                        }
                    }
                }

                // Section 2: Add Products Card ("إضافة منتجات للقائمة")
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "إضافة منتجات للقائمة",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )

                            // Quick Smart Input Bar (OCR, Barcode, Voice)
                            SmartQuickActionBar(
                                onOcrClick = { cameraPermissionHandler.checkAndRequest() },
                                onBarcodeClick = { barcodePermissionHandler.checkAndRequest() },
                                onVoiceClick = { audioPermissionHandler.checkAndRequest() },
                                onShareClick = {}
                            )

                            // Item Name Input with Search icon + Mic icon
                            val matchingProducts = if (itemNameInput.isBlank()) emptyList()
                            else allProducts.filter { it.name.contains(itemNameInput, ignoreCase = true) }

                            ExposedDropdownMenuBox(
                                expanded = itemSuggestionsExpanded && matchingProducts.isNotEmpty(),
                                onExpandedChange = { itemSuggestionsExpanded = !itemSuggestionsExpanded }
                            ) {
                                OutlinedTextField(
                                    value = itemNameInput,
                                    onValueChange = {
                                        itemNameInput = it
                                        itemSuggestionsExpanded = true
                                        applyMasterProductDefaults(it)
                                    },
                                    label = { Text("اسم المنتج") },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Search,
                                            contentDescription = "بحث"
                                        )
                                    },
                                    trailingIcon = {
                                        IconButton(onClick = { launchVoiceInput() }) {
                                            Icon(
                                                imageVector = Icons.Default.Mic,
                                                contentDescription = "إدخال صوتي",
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    },
                                    placeholder = { Text("ابحث أو أنطق اسم المنتج...") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth()
                                        .testTag("input_item_name")
                                )

                                ExposedDropdownMenu(
                                    expanded = itemSuggestionsExpanded && matchingProducts.isNotEmpty(),
                                    onDismissRequest = { itemSuggestionsExpanded = false }
                                ) {
                                    matchingProducts.take(5).forEach { masterProd ->
                                        DropdownMenuItem(
                                            text = {
                                                Column {
                                                    Text(
                                                        masterProd.name,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        "الوحدة: ${masterProd.defaultUnit} | السعر: ${if (masterProd.lastPrice > 0) "${masterProd.lastPrice} ${settings.currency}" else "غير معروف"}",
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            },
                                            onClick = {
                                                itemNameInput = masterProd.name
                                                selectedCategoryId = masterProd.categoryId
                                                selectedStoreId = masterProd.defaultStoreId
                                                itemUnitInput = masterProd.defaultUnit
                                                if (masterProd.lastPrice > 0) {
                                                    itemPriceInput = masterProd.lastPrice.toString()
                                                }
                                                itemSuggestionsExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Row: Qty, Unit, Price
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = itemQtyInput,
                                    onValueChange = { itemQtyInput = it },
                                    label = { Text("الكمية") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_item_qty")
                                )

                                OutlinedTextField(
                                    value = itemUnitInput,
                                    onValueChange = { itemUnitInput = it },
                                    label = { Text("الوحدة") },
                                    placeholder = { Text("قطعة") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .testTag("input_item_unit")
                                )

                                OutlinedTextField(
                                    value = itemPriceInput,
                                    onValueChange = { itemPriceInput = it },
                                    label = { Text("السعر (${settings.currency})") },
                                    placeholder = { Text("0") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .testTag("input_item_price")
                                )
                            }

                            // Row: Category Dropdown ("اختر التصنيف") and Store Dropdown ("اختر المتجر")
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Category Selector Dropdown
                                Box(modifier = Modifier.weight(1f)) {
                                    val currentCatName = categories.find { it.id == selectedCategoryId }?.name ?: "اختر التصنيف"
                                    OutlinedButton(
                                        onClick = { categoryDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = currentCatName,
                                            maxLines = 1,
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                    }

                                    DropdownMenu(
                                        expanded = categoryDropdownExpanded,
                                        onDismissRequest = { categoryDropdownExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("بدون تصنيف") },
                                            onClick = {
                                                selectedCategoryId = null
                                                categoryDropdownExpanded = false
                                            }
                                        )
                                        categories.forEach { cat ->
                                            DropdownMenuItem(
                                                text = { Text(cat.name) },
                                                onClick = {
                                                    selectedCategoryId = cat.id
                                                    categoryDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                // Store Selector Dropdown
                                Box(modifier = Modifier.weight(1f)) {
                                    val currentStoreName = stores.find { it.id == selectedStoreId }?.name ?: "اختر المتجر"
                                    OutlinedButton(
                                        onClick = { storeDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = currentStoreName,
                                            maxLines = 1,
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                    }

                                    DropdownMenu(
                                        expanded = storeDropdownExpanded,
                                        onDismissRequest = { storeDropdownExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("بدون متجر") },
                                            onClick = {
                                                selectedStoreId = null
                                                storeDropdownExpanded = false
                                            }
                                        )
                                        stores.forEach { store ->
                                            DropdownMenuItem(
                                                text = { Text(store.name) },
                                                onClick = {
                                                    selectedStoreId = store.id
                                                    storeDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // Button: "+ إضافة المنتج للقائمة"
                            Button(
                                onClick = {
                                    if (itemNameInput.isNotBlank()) {
                                        val qtyVal = itemQtyInput.toDoubleOrNull() ?: 1.0
                                        val priceVal = itemPriceInput.toDoubleOrNull() ?: 0.0

                                        val newItem = ShoppingListItemEntity(
                                            listId = 0,
                                            name = itemNameInput.trim(),
                                            quantity = qtyVal,
                                            unit = itemUnitInput.ifBlank { "قطعة" },
                                            price = priceVal,
                                            isPriceUnknown = priceVal <= 0,
                                            categoryId = selectedCategoryId,
                                            storeId = selectedStoreId
                                        )

                                        draftItems.value = draftItems.value + newItem

                                        // Reset fields
                                        itemNameInput = ""
                                        itemQtyInput = "1"
                                        itemPriceInput = ""
                                        selectedCategoryId = null
                                        selectedStoreId = null
                                    }
                                },
                                enabled = itemNameInput.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("btn_add_item_to_draft"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "+ إضافة المنتج للقائمة",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                // Section 3: Added Items Header
                item {
                    Text(
                        text = "المنتجات المضافة (${draftItems.value.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (draftItems.value.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "لم تقم بإضافة أي منتجات حتى الآن. أدخل اسم المنتج واضغط إضافة",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(draftItems.value) { item ->
                        val cat = categories.find { it.id == item.categoryId }
                        val store = stores.find { it.id == item.storeId }

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (cat != null) CategoryBadge(categoryName = cat.name, colorHex = cat.colorHex)
                                        if (store != null) StoreBadge(storeName = store.name, colorHex = store.colorHex)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "الكمية: ${item.quantity} ${item.unit} | السعر: ${if (item.price > 0) "${CurrencyFormatter.format(item.price)} ${settings.currency}" else "غير معروف"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        draftItems.value = draftItems.value.filter { it != item }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 𝐌𝐑𝟕|intelligence Assistant Dialog
        if (showAiDialog) {
            AlertDialog(
                onDismissRequest = { if (!isAiLoading) showAiDialog = false },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text("مساعد 𝐌𝐑𝟕|intelligence الذكي")
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "اكتب ما تريد تسوقه أو اختر اقتراحاً، وسيقوم الذكاء الاصطناعي بإنشاء القائمة وإضافة المنتجات تلقائياً:",
                            style = MaterialTheme.typography.bodyMedium
                        )

                        OutlinedTextField(
                            value = aiPromptInput,
                            onValueChange = { aiPromptInput = it },
                            placeholder = { Text("مثال: مقادير كيكة الشوكولاتة، تسوق أسبوعي للمنزل...") },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !isAiLoading
                        )

                        Text(
                            text = "اقتراحات سريعة:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val preset1 = "مقادير كيكة الشوكولاتة"
                            val preset2 = "تسوق أسبوعي للمنزل"
                            val preset3 = "مستلزمات الحفلة"

                            OutlinedButton(
                                onClick = { aiPromptInput = preset1 },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(preset1, fontSize = 10.sp, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { aiPromptInput = preset2 },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(preset2, fontSize = 10.sp, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { aiPromptInput = preset3 },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(preset3, fontSize = 10.sp, maxLines = 1)
                            }
                        }

                        if (isAiLoading) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("جاري إنشاء القائمة بالذكاء الاصطناعي...")
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (aiPromptInput.isNotBlank()) {
                                isAiLoading = true
                                scope.launch {
                                    val res = GeminiAssistantService.generateShoppingList(aiPromptInput)
                                    isAiLoading = false
                                    res.onSuccess { generatedItems ->
                                        val newEntities = generatedItems.map { gen ->
                                            val matchedCat = categories.find { it.name.contains(gen.categoryName, ignoreCase = true) }
                                            ShoppingListItemEntity(
                                                listId = 0,
                                                name = gen.name,
                                                quantity = gen.quantity,
                                                unit = gen.unit,
                                                price = gen.estimatedPrice,
                                                isPriceUnknown = gen.estimatedPrice <= 0,
                                                categoryId = matchedCat?.id
                                            )
                                        }
                                        draftItems.value = draftItems.value + newEntities
                                        Toast.makeText(context, "تمت إضافة ${newEntities.size} منتج بواسطة 𝐌𝐑𝟕|intelligence!", Toast.LENGTH_LONG).show()
                                        showAiDialog = false
                                        aiPromptInput = ""
                                    }.onFailure { err ->
                                        Toast.makeText(context, err.message ?: "حدث خطأ أثناء توليد القائمة", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        },
                        enabled = aiPromptInput.isNotBlank() && !isAiLoading
                    ) {
                        Text("توليد وإضافة ✨")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showAiDialog = false },
                        enabled = !isAiLoading
                    ) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // Smart OCR Review Dialog (Shared OCR Engine)
        if (showOcrDialog) {
            SmartOcrReviewDialog(
                existingProducts = allProducts,
                onDismiss = { showOcrDialog = false },
                onConfirmAdd = { selectedOcrItems ->
                    val newEntities = selectedOcrItems.map { ocrItem ->
                        ShoppingListItemEntity(
                            listId = 0,
                            name = ocrItem.name.trim(),
                            quantity = ocrItem.quantity,
                            unit = ocrItem.unit.ifBlank { "قطعة" },
                            price = 0.0,
                            isPriceUnknown = true,
                            categoryId = null,
                            storeId = selectedStoreId
                        )
                    }
                    draftItems.value = draftItems.value + newEntities
                    Toast.makeText(context, "تمت إضافة ${newEntities.size} منتج من تصوير الورقة", Toast.LENGTH_SHORT).show()
                    showOcrDialog = false
                }
            )
        }

        // Smart Barcode Dialog
        if (showBarcodeDialog) {
            SmartBarcodeDialog(
                existingProducts = allProducts,
                onDismiss = { showBarcodeDialog = false },
                onAddProduct = { name, qty, unit, price, barcode, notes ->
                    val newItem = ShoppingListItemEntity(
                        listId = 0,
                        name = name.trim(),
                        quantity = qty,
                        unit = unit.ifBlank { "قطعة" },
                        price = price,
                        isPriceUnknown = price <= 0.0,
                        categoryId = null,
                        storeId = selectedStoreId
                    )
                    draftItems.value = draftItems.value + newItem
                    Toast.makeText(context, "تمت إضافة $name بالباركود", Toast.LENGTH_SHORT).show()
                    showBarcodeDialog = false
                }
            )
        }

        // Smart Voice Dialog
        if (showVoiceDialog) {
            SmartVoiceDialog(
                existingProducts = allProducts,
                onDismiss = { showVoiceDialog = false },
                onConfirmAdd = { selectedVoiceItems ->
                    val newEntities = selectedVoiceItems.map { voiceItem ->
                        ShoppingListItemEntity(
                            listId = 0,
                            name = voiceItem.name.trim(),
                            quantity = voiceItem.quantity,
                            unit = voiceItem.unit.ifBlank { "قطعة" },
                            price = 0.0,
                            isPriceUnknown = true,
                            categoryId = null,
                            storeId = selectedStoreId
                        )
                    }
                    draftItems.value = draftItems.value + newEntities
                    Toast.makeText(context, "تمت إضافة ${newEntities.size} منتج صوتياً", Toast.LENGTH_SHORT).show()
                    showVoiceDialog = false
                }
            )
        }
    }
}
