package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val HighDensityPrimary = Color(0xFF0061A4)
val HighDensitySecondary = Color(0xFF535F70)
val HighDensityTertiary = Color(0xFF6B5778)

val HighDensityPrimaryContainer = Color(0xFFD1E4FF)
val HighDensityOnPrimaryContainer = Color(0xFF001D35)

val HighDensityDarkPrimary = Color(0xFF9ECAFF)
val HighDensityDarkOnPrimary = Color(0xFF003258)
val HighDensityDarkPrimaryContainer = Color(0xFF00497D)
val HighDensityDarkOnPrimaryContainer = Color(0xFFD1E4FF)

val LightBackground = Color(0xFFF6F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkOnSurface = Color(0xFFF8FAFC)

val GradientStart = Color(0xFF2563EB)
val GradientMiddle = Color(0xFF6366F1)
val GradientEnd = Color(0xFF7C3AED)

