package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.viewmodel.MainViewModel
import com.example.ui.components.CurrencyFormatter
import com.example.ui.components.RtlProvider
import com.example.ui.theme.GradientEnd
import com.example.ui.theme.GradientMiddle
import com.example.ui.theme.GradientStart
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

data class MissingProductSample(
    val id: Int,
    val name: String,
    val countBadge: Int,
    val iconEmoji: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val currentUser by viewModel.currentUserState.collectAsState()
    val activeLists by viewModel.activeListsState.collectAsState()
    val products by viewModel.productsState.collectAsState()
    val stores by viewModel.storesState.collectAsState()
    val categories by viewModel.categoriesState.collectAsState()
    val bills by viewModel.billsState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()
    val pantryItems by viewModel.pantryItemsState.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedBottomTab by remember { mutableIntStateOf(0) } // 0: Home, 1: Lists, 2: Products, 3: Stats, 4: More
    var showMoreBottomSheet by remember { mutableStateOf(false) }
    var showNotificationsDialog by remember { mutableStateOf(false) }
    var showSmartSuggestionAdded by remember { mutableStateOf(false) }

    val sheetState = rememberModalBottomSheetState()

    // Date String
    val currentDateStr = remember {
        try {
            val sdf = SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar"))
            sdf.format(Date())
        } catch (e: Exception) {
            "اليوم"
        }
    }

    // Voice Search Launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                searchQuery = spokenText
                viewModel.setSearchQuery(spokenText)
                onNavigate("products")
            }
        }
    }

    fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "𝐌𝐑𝟕 MIC")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "خاصية البحث الصوتي غير متاحة على هذا الجهاز", Toast.LENGTH_SHORT).show()
        }
    }

    // Dynamic stats
    val totalSpent = remember(bills) { bills.sumOf { it.totalCost } }
    val lastActiveList = activeLists.firstOrNull()

    // Dynamic missing products from pantry or user products
    val missingProducts = remember(pantryItems, products) {
        val fromPantry = pantryItems.filter { it.currentQuantity <= it.minLimit }.map { item ->
            MissingProductSample(
                id = item.id.toInt(),
                name = item.name,
                countBadge = 1,
                iconEmoji = "🛒"
            )
        }
        if (fromPantry.isNotEmpty()) {
            fromPantry
        } else {
            products.take(5).map { p ->
                MissingProductSample(
                    id = p.id.toInt(),
                    name = p.name,
                    countBadge = 1,
                    iconEmoji = "🛒"
                )
            }
        }
    }

    RtlProvider {
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { onNavigate("create_list") },
                    shape = CircleShape,
                    containerColor = Color(0xFF2563EB),
                    contentColor = Color.White,
                    elevation = FloatingActionButtonDefaults.elevation(8.dp),
                    modifier = Modifier
                        .size(60.dp)
                        .testTag("btn_create_list_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "إنشاء قائمة",
                        modifier = Modifier.size(32.dp)
                    )
                }
            },
            bottomBar = {
                Surface(
                    tonalElevation = 8.dp,
                    shadowElevation = 12.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 0.dp,
                        modifier = Modifier.navigationBarsPadding()
                    ) {
                        // 1. Home
                        NavigationBarItem(
                            selected = selectedBottomTab == 0,
                            onClick = { selectedBottomTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
                            label = { Text("الرئيسية", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary
                            )
                        )

                        // 2. Lists
                        NavigationBarItem(
                            selected = selectedBottomTab == 1,
                            onClick = {
                                selectedBottomTab = 1
                                onNavigate("lists")
                            },
                            icon = { Icon(Icons.Default.FormatListBulleted, contentDescription = "القوائم") },
                            label = { Text("القوائم", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("btn_lists")
                        )

                        // 3. Products
                        NavigationBarItem(
                            selected = selectedBottomTab == 2,
                            onClick = {
                                selectedBottomTab = 2
                                onNavigate("products")
                            },
                            icon = { Icon(Icons.Default.Inventory, contentDescription = "المنتجات") },
                            label = { Text("المنتجات", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("btn_products")
                        )

                        // 4. Statistics
                        NavigationBarItem(
                            selected = selectedBottomTab == 3,
                            onClick = {
                                selectedBottomTab = 3
                                onNavigate("statistics")
                            },
                            icon = { Icon(Icons.Default.PieChart, contentDescription = "الإحصائيات") },
                            label = { Text("الإحصائيات", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("btn_statistics")
                        )

                        // 5. More
                        NavigationBarItem(
                            selected = selectedBottomTab == 4,
                            onClick = {
                                showMoreBottomSheet = true
                            },
                            icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "المزيد") },
                            label = { Text("المزيد", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }
        ) { paddingValues ->
            LazyColumn(
                contentPadding = PaddingValues(bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
            ) {
                // HEADER SECTION WITH GRADIENT & SEARCH BAR OVERLAY
                item {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        // Header Gradient Container
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            GradientStart,
                                            GradientMiddle,
                                            GradientEnd
                                        )
                                    )
                                )
                                .padding(horizontal = 20.dp, vertical = 20.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                // Top Row: Avatar + Welcome + App Name & Notification Bell
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // User Avatar & Welcome Text
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        // Profile Avatar Circle
                                        Surface(
                                            shape = CircleShape,
                                            color = Color.White.copy(alpha = 0.25f),
                                            modifier = Modifier
                                                .size(48.dp)
                                                .border(2.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "👤",
                                                    fontSize = 24.sp
                                                )
                                            }
                                        }

                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                val displayName = currentUser?.name?.takeIf { it.isNotBlank() } ?: "عزيزي المستخدم"
                                                Text(
                                                    text = "مرحباً بك، $displayName 👋",
                                                    style = MaterialTheme.typography.titleMedium.copy(
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.White,
                                                        fontSize = 17.sp
                                                    )
                                                )
                                            }
                                            Text(
                                                text = "طلباتي MR7",
                                                style = MaterialTheme.typography.headlineSmall.copy(
                                                    fontWeight = FontWeight.Black,
                                                    color = Color.White,
                                                    fontSize = 22.sp
                                                )
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "📅 $currentDateStr",
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = Color.White.copy(alpha = 0.85f),
                                                    fontSize = 11.sp
                                                )
                                            )
                                        }
                                    }

                                    // Notification Bell with Badge
                                    IconButton(
                                        onClick = { showNotificationsDialog = true },
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.2f))
                                    ) {
                                        BadgedBox(
                                            badge = {
                                                Badge(
                                                    containerColor = Color(0xFFEF4444),
                                                    contentColor = Color.White
                                                ) {
                                                    Text("3", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Notifications,
                                                contentDescription = "الإشعارات",
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Prominent Big Search Bar directly positioned over bottom of header
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp)
                                .align(Alignment.BottomCenter)
                                .shadow(8.dp, RoundedCornerShape(24.dp))
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = {
                                    searchQuery = it
                                    if (it.isNotBlank()) {
                                        viewModel.setSearchQuery(it)
                                    }
                                },
                                placeholder = {
                                    Text(
                                        text = "ابحث عن منتج، متجر، قائمة...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "بحث",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                },
                                trailingIcon = {
                                    IconButton(onClick = { launchVoiceSearch() }) {
                                        Icon(
                                            imageVector = Icons.Default.Mic,
                                            contentDescription = "MR7 MIC",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(24.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    disabledBorderColor = Color.Transparent
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("home_search_bar")
                            )
                        }
                    }
                }

                // DASHBOARD CARDS SECTION (لوحة معلومات)
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            userScrollEnabled = false,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                        ) {
                            // Stat 1: Total Spend
                            item {
                                DashboardStatCard(
                                    title = "إجمالي الإنفاق",
                                    value = "${CurrencyFormatter.format(totalSpent)} ${settings.currency}",
                                    badgeText = "↑ 12%",
                                    badgeColor = Color(0xFF10B981),
                                    icon = Icons.Default.AccountBalanceWallet,
                                    iconBgColor = Color(0xFFEEF2FF),
                                    iconColor = Color(0xFF4F46E5),
                                    onClick = { onNavigate("bills") }
                                )
                            }

                            // Stat 2: Active Lists
                            item {
                                DashboardStatCard(
                                    title = "عدد القوائم",
                                    value = "${activeLists.size} قائمة",
                                    badgeText = "↑ 2",
                                    badgeColor = Color(0xFF10B981),
                                    icon = Icons.Default.ShoppingCart,
                                    iconBgColor = Color(0xFFECFDF5),
                                    iconColor = Color(0xFF059669),
                                    onClick = { onNavigate("lists") }
                                )
                            }

                            // Stat 3: Products Count
                            item {
                                DashboardStatCard(
                                    title = "عدد المنتجات",
                                    value = "${products.size} منتج",
                                    badgeText = "↑ 8",
                                    badgeColor = Color(0xFFF59E0B),
                                    icon = Icons.Default.Inventory,
                                    iconBgColor = Color(0xFFFFFBEB),
                                    iconColor = Color(0xFFD97706),
                                    onClick = { onNavigate("products") }
                                )
                            }

                            // Stat 4: Stores Count
                            item {
                                DashboardStatCard(
                                    title = "عدد المتاجر",
                                    value = "${stores.size} متاجر",
                                    badgeText = "↑ 1",
                                    badgeColor = Color(0xFF0284C7),
                                    icon = Icons.Default.Store,
                                    iconBgColor = Color(0xFFF0F9FF),
                                    iconColor = Color(0xFF0284C7),
                                    onClick = { onNavigate("stores") }
                                )
                            }
                        }
                    }
                }

                // HOME PANTRY / INVENTORY HERO CARD
                item {
                    val lowCount = pantryItems.count { it.currentQuantity <= it.minLimit }
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clickable { onNavigate("pantry") }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0xFF2563EB).copy(alpha = 0.12f),
                                    modifier = Modifier.size(52.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = "🏠", fontSize = 28.sp)
                                    }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            text = "المخزون المنزلي",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                                        )
                                        if (lowCount > 0) {
                                            Surface(
                                                shape = CircleShape,
                                                color = Color(0xFFD97706)
                                            ) {
                                                Text(
                                                    text = "$lowCount ناقص",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = "تتبع احتياجات واستهلاك المنزل (${pantryItems.size} منتج)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Button(
                                onClick = { onNavigate("pantry") },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                            ) {
                                Text("إدارة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // QUICK ACTIONS SECTION (إجراءات سريعة)
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "⚡ إجراءات سريعة",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                )
                            }
                            TextButton(onClick = { onNavigate("settings") }) {
                                Text(
                                    text = "تخصيص ⚙️",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // 1. New List
                            QuickActionButton(
                                title = "قائمة جديدة",
                                icon = Icons.Default.Add,
                                iconBg = Color(0xFF10B981),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_create_list"),
                                onClick = { onNavigate("create_list") }
                            )

                            // 2. New Product
                            QuickActionButton(
                                title = "منتج جديد",
                                icon = Icons.Default.Inventory,
                                iconBg = Color(0xFFF59E0B),
                                modifier = Modifier.weight(1f),
                                onClick = { onNavigate("products") }
                            )

                            // 3. New Store
                            QuickActionButton(
                                title = "متجر جديد",
                                icon = Icons.Default.Store,
                                iconBg = Color(0xFF0284C7),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_stores"),
                                onClick = { onNavigate("stores") }
                            )

                            // 4. New Bill
                            QuickActionButton(
                                title = "فاتورة جديدة",
                                icon = Icons.Default.ReceiptLong,
                                iconBg = Color(0xFF8B5CF6),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_bills"),
                                onClick = { onNavigate("bills") }
                            )
                        }
                    }
                }

                // CONTINUE SHOPPING SECTION (متابعة التسوق)
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "🛒 متابعة التسوق",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            )
                        }

                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("active_shopping_card")
                        ) {
                            if (lastActiveList != null) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(14.dp),
                                                color = Color(0xFFEFF6FF),
                                                modifier = Modifier.size(54.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text("🧺", fontSize = 28.sp)
                                                }
                                            }

                                            Column {
                                                Text(
                                                    text = lastActiveList.title,
                                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = "نشطة • تم تحديثها اليوم",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        Text(
                                            text = "65%",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        )
                                    }

                                    LinearProgressIndicator(
                                        progress = { 0.65f },
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(CircleShape)
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = { onNavigate("shopping_active/${lastActiveList.id}") },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                                        ) {
                                            Text("متابعة التسوق", fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        TextButton(onClick = { onNavigate("lists") }) {
                                            Text("كل القوائم (${activeLists.size})", fontSize = 12.sp)
                                        }
                                    }
                                }
                            } else {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("🛍️ لا يوجد قائمة تسوق نشطة حالياً")
                                    Text(
                                        "أنشئ قائمة جديدة للبدء في التسوق الذكي والمباشر",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Button(
                                        onClick = { onNavigate("create_list") },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.padding(top = 4.dp)
                                    ) {
                                        Text("+ إنشاء قائمة جديدة")
                                    }
                                }
                            }
                        }
                    }
                }

                // MISSING PRODUCTS SECTION (منتجات ناقصة)
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "🍳 منتجات ناقصة",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                )
                            }

                            TextButton(onClick = { onNavigate("products") }) {
                                Text(
                                    text = "عرض الكل >",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(missingProducts) { sample ->
                                MissingProductCard(
                                    sample = sample,
                                    onClick = { onNavigate("create_list") }
                                )
                            }
                        }
                    }
                }

                // SMART SUGGESTIONS SECTION (اقتراحات ذكية)
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "✨ اقتراحات ذكية",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            )
                        }

                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "يبدو أنك تشتري \"حليب\" كل أسبوع",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Color(0xFF065F46)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "هل ترغب في إضافته تلقائياً لقائمتك القادمة؟",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF047857)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            showSmartSuggestionAdded = true
                                            Toast.makeText(context, "تمت إضافة \"حليب\" للقائمة بنجاح ✨", Toast.LENGTH_SHORT).show()
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                    ) {
                                        Text("إضافة الآن", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Surface(
                                    shape = CircleShape,
                                    color = Color.White,
                                    modifier = Modifier.size(60.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("🥛", fontSize = 32.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // MORE OPTIONS BOTTOM SHEET
        if (showMoreBottomSheet) {
            ModalBottomSheet(
                onDismissRequest = { showMoreBottomSheet = false },
                sheetState = sheetState,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "المزيد من الخيارات والأقسام",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MoreMenuItemCard(
                            title = "المخزون المنزلي",
                            subtitle = "${pantryItems.size} منتج",
                            icon = Icons.Default.Inventory,
                            iconBg = Color(0xFF2563EB),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_pantry_more"),
                            onClick = {
                                showMoreBottomSheet = false
                                onNavigate("pantry")
                            }
                        )

                        MoreMenuItemCard(
                            title = "التصنيفات",
                            subtitle = "${categories.size} تصنيف",
                            icon = Icons.Default.Category,
                            iconBg = Color(0xFF6366F1),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_categories"),
                            onClick = {
                                showMoreBottomSheet = false
                                onNavigate("categories")
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MoreMenuItemCard(
                            title = "حسابي والملف الشخصي",
                            subtitle = currentUser?.name ?: "إدارة الحساب",
                            icon = Icons.Default.Person,
                            iconBg = Color(0xFF8B5CF6),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_my_account"),
                            onClick = {
                                showMoreBottomSheet = false
                                onNavigate("my_account")
                            }
                        )

                        MoreMenuItemCard(
                            title = "الإعدادات",
                            subtitle = "المظهر والعملة",
                            icon = Icons.Default.Settings,
                            iconBg = Color(0xFF64748B),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_settings"),
                            onClick = {
                                showMoreBottomSheet = false
                                onNavigate("settings")
                            }
                        )
                    }

                    val isAdminUser = currentUser?.id == 777L || currentUser?.role == "SUPER_ADMIN" || currentUser?.role == "ADMIN"
                    if (isAdminUser) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            MoreMenuItemCard(
                                title = "🛡️ لوحة تحكم الأدمن (MR7)",
                                subtitle = "إدارة النظام والمستخدمين والعمليات",
                                icon = Icons.Default.Security,
                                iconBg = Color(0xFFD97706),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_admin_panel"),
                                onClick = {
                                    showMoreBottomSheet = false
                                    onNavigate("admin_control_panel")
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // NOTIFICATIONS DIALOG
        if (showNotificationsDialog) {
            AlertDialog(
                onDismissRequest = { showNotificationsDialog = false },
                title = { Text("🔔 الإشعارات والإنذارات") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("💡 تذكير أسبوعي", fontWeight = FontWeight.Bold)
                                Text("حان موعد إعداد قائمة التسوق الأسبوعية اليوم!", fontSize = 12.sp)
                            }
                        }
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("✨ اقتراح المساعد الذكي", fontWeight = FontWeight.Bold)
                                Text("يمكنك استخدام 𝐌𝐑𝟕|intelligence لإنشاء القائمة بالكامل بنقرة واحدة.", fontSize = 12.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showNotificationsDialog = false }) {
                        Text("إغلاق")
                    }
                }
            )
        }
    }
}

@Composable
fun DashboardStatCard(
    title: String,
    value: String,
    badgeText: String,
    badgeColor: Color,
    icon: ImageVector,
    iconBgColor: Color,
    iconColor: Color,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxSize()
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = iconBgColor,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = iconColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun QuickActionButton(
    title: String,
    icon: ImageVector,
    iconBg: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .height(86.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = CircleShape,
                color = iconBg,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
fun MissingProductCard(
    sample: MissingProductSample,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .width(100.dp)
            .height(115.dp)
            .clickable(onClick = onClick)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Count badge
            Surface(
                shape = CircleShape,
                color = Color(0xFF2563EB),
                modifier = Modifier
                    .padding(8.dp)
                    .size(22.dp)
                    .align(Alignment.TopStart)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "${sample.countBadge}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = sample.iconEmoji, fontSize = 32.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = sample.name,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun MoreMenuItemCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = modifier
            .height(80.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = iconBg,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
