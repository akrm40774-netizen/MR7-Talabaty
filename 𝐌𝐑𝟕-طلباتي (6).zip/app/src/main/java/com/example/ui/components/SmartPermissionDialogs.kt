package com.example.ui.components

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

class PermissionHandler(
    val checkAndRequest: () -> Unit
)

@Composable
fun rememberCameraPermissionHandler(
    onPermissionGranted: () -> Unit
): PermissionHandler {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    var showRationaleDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var waitingForSettingsReturn by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            showRationaleDialog = false
            showSettingsDialog = false
            onPermissionGranted()
        } else {
            val shouldShowRationale = activity?.let {
                ActivityCompat.shouldShowRequestPermissionRationale(it, Manifest.permission.CAMERA)
            } ?: false

            if (shouldShowRationale) {
                showRationaleDialog = true
            } else {
                showSettingsDialog = true
            }
        }
    }

    // Lifecycle observer to recheck permission when returning from App Settings
    DisposableEffect(lifecycleOwner, waitingForSettingsReturn) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && waitingForSettingsReturn) {
                waitingForSettingsReturn = false
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
                if (granted) {
                    showRationaleDialog = false
                    showSettingsDialog = false
                    onPermissionGranted()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    if (showRationaleDialog) {
        PermissionDialogUI(
            title = "📷 نحتاج إلى صلاحية الكاميرا",
            message = "يحتاج تصوير ورقة المشتريات إلى الوصول إلى الكاميرا. اسمح بالوصول للمتابعة.",
            confirmButtonText = "✅ السماح بالكاميرا",
            onConfirm = {
                showRationaleDialog = false
                permissionLauncher.launch(Manifest.permission.CAMERA)
            },
            onDismiss = { showRationaleDialog = false }
        )
    }

    if (showSettingsDialog) {
        PermissionDialogUI(
            title = "📷 صلاحية الكاميرا غير مفعلة",
            message = "تم منع صلاحية الكاميرا. يمكنك تفعيل الصلاحية من إعدادات التطبيق للمتابعة في تصوير ورقة المشتريات.",
            confirmButtonText = "⚙️ فتح إعدادات التطبيق",
            onConfirm = {
                showSettingsDialog = false
                waitingForSettingsReturn = true
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                }
                context.startActivity(intent)
            },
            onDismiss = { showSettingsDialog = false }
        )
    }

    return remember(context, onPermissionGranted) {
        PermissionHandler {
            val isGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
            if (isGranted) {
                onPermissionGranted()
            } else {
                permissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }
}

@Composable
fun rememberAudioPermissionHandler(
    onPermissionGranted: () -> Unit
): PermissionHandler {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    var showRationaleDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var waitingForSettingsReturn by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            showRationaleDialog = false
            showSettingsDialog = false
            onPermissionGranted()
        } else {
            val shouldShowRationale = activity?.let {
                ActivityCompat.shouldShowRequestPermissionRationale(it, Manifest.permission.RECORD_AUDIO)
            } ?: false

            if (shouldShowRationale) {
                showRationaleDialog = true
            } else {
                showSettingsDialog = true
            }
        }
    }

    DisposableEffect(lifecycleOwner, waitingForSettingsReturn) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && waitingForSettingsReturn) {
                waitingForSettingsReturn = false
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (granted) {
                    showRationaleDialog = false
                    showSettingsDialog = false
                    onPermissionGranted()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    if (showRationaleDialog) {
        PermissionDialogUI(
            title = "🎤 نحتاج إلى صلاحية الميكروفون",
            message = "تحتاج إضافة المنتجات بالصوت إلى صلاحية الميكروفون. اسمح بالوصول للمتابعة.",
            confirmButtonText = "✅ السماح بالميكروفون",
            onConfirm = {
                showRationaleDialog = false
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            onDismiss = { showRationaleDialog = false }
        )
    }

    if (showSettingsDialog) {
        PermissionDialogUI(
            title = "🎤 صلاحية الميكروفون غير مفعلة",
            message = "تم منع صلاحية الميكروفون. يمكنك تفعيل الصلاحية من إعدادات التطبيق للمتابعة في الإضافة الصوتية.",
            confirmButtonText = "⚙️ فتح إعدادات التطبيق",
            onConfirm = {
                showSettingsDialog = false
                waitingForSettingsReturn = true
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                }
                context.startActivity(intent)
            },
            onDismiss = { showSettingsDialog = false }
        )
    }

    return remember(context, onPermissionGranted) {
        PermissionHandler {
            val isGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (isGranted) {
                onPermissionGranted()
            } else {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }
}

@Composable
private fun PermissionDialogUI(
    title: String,
    message: String,
    confirmButtonText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }
                    Button(
                        onClick = onConfirm,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(confirmButtonText, maxLines = 1)
                    }
                }
            }
        }
    }
}
