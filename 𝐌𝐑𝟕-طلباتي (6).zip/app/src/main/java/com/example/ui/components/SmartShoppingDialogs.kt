package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.ProductEntity
import com.example.util.ParsedOcrItem
import com.example.util.ParsedVoiceItem
import com.example.util.SmartOcrParser
import com.example.util.SmartVoiceParser
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartOcrReviewDialog(
    existingProducts: List<ProductEntity>,
    onDismiss: () -> Unit,
    onConfirmAdd: (List<ParsedOcrItem>) -> Unit
) {
    var rawInputText by remember {
        mutableStateOf("")
    }

    var isAnalyzing by remember { mutableStateOf(false) }
    var analyzedItems by remember { mutableStateOf<List<ParsedOcrItem>>(emptyList()) }
    var hasAnalyzed by remember { mutableStateOf(false) }

    // Auto analyze on open
    LaunchedEffect(Unit) {
        analyzedItems = SmartOcrParser.parseOcrText(rawInputText, existingProducts)
        hasAnalyzed = true
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.9f)
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "📸 نظام OCR الذكي — مراجعة القائمة",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Pre-processing info badges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    BadgeChip("🔍 اكتشاف الحدود", MaterialTheme.colorScheme.primary)
                    BadgeChip("📐 تصحيح المنظور", MaterialTheme.colorScheme.secondary)
                    BadgeChip("✨ تحسين التباين", MaterialTheme.colorScheme.tertiary)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Optional textarea for simulated handwritten text correction
                var showRawEditor by remember { mutableStateOf(false) }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "العناصر المقروءة من الورقة (${analyzedItems.size}):",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    TextButton(onClick = { showRawEditor = !showRawEditor }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showRawEditor) "إخفاء النص المقروء" else "تعديل نص الصورة")
                    }
                }

                AnimatedVisibility(visible = showRawEditor) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = rawInputText,
                            onValueChange = {
                                rawInputText = it
                                analyzedItems = SmartOcrParser.parseOcrText(it, existingProducts)
                            },
                            label = { Text("النص المستخرج من الصورة (يدوي / OCR)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp),
                            textStyle = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }

                // Select All / Deselect All
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val allSelected = analyzedItems.isNotEmpty() && analyzedItems.all { it.isSelected }
                    TextButton(
                        onClick = {
                            val target = !allSelected
                            analyzedItems = analyzedItems.map { it.copy(isSelected = target) }
                        }
                    ) {
                        Icon(
                            imageVector = if (allSelected) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (allSelected) "إلغاء تحديد الكل" else "تحديد الكل")
                    }

                    TextButton(
                        onClick = {
                            analyzedItems = analyzedItems + ParsedOcrItem(
                                rawText = "منتج جديد",
                                name = "منتج جديد",
                                quantity = 1.0,
                                unit = "قطعة"
                            )
                        }
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة منتج يدويًا")
                    }
                }

                // List of extracted items
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(analyzedItems, key = { it.id }) { item ->
                        OcrItemReviewCard(
                            item = item,
                            onUpdate = { updated ->
                                analyzedItems = analyzedItems.map { if (it.id == updated.id) updated else it }
                            },
                            onDelete = {
                                analyzedItems = analyzedItems.filter { it.id != item.id }
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val selected = analyzedItems.filter { it.isSelected && it.name.isNotBlank() }
                            onConfirmAdd(selected)
                        },
                        enabled = analyzedItems.any { it.isSelected && it.name.isNotBlank() },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة المحدد إلى القائمة (${analyzedItems.count { it.isSelected }})")
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

@Composable
fun OcrItemReviewCard(
    item: ParsedOcrItem,
    onUpdate: (ParsedOcrItem) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isSelected)
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            else
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Checkbox(
                        checked = item.isSelected,
                        onCheckedChange = { ch -> onUpdate(item.copy(isSelected = ch)) }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            if (item.matchedProduct != null) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "✔ مسجل بـ MR7",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        if (item.confidenceLabel != "HIGH") {
                            Spacer(modifier = Modifier.height(3.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = item.confidenceLabel,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "${item.quantity} ${item.unit}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Suggestions if fuzzy or low confidence
            if (item.suggestions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("اقتراحات:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    item.suggestions.take(3).forEach { sug ->
                        val cleanSug = sug.replace(Regex("^[🧀✏️]+\\s*"), "")
                        Surface(
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.clickable {
                                onUpdate(item.copy(name = cleanSug, confidenceLabel = "HIGH", suggestions = emptyList()))
                            }
                        ) {
                            Text(
                                text = sug,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            // Notes field display/edit
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = item.notes,
                onValueChange = { newNote -> onUpdate(item.copy(notes = newNote)) },
                label = { Text("📝 ملاحظة (مثال: مستوية، طازجة، نوع معين)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                textStyle = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun BadgeChip(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            ),
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartBarcodeDialog(
    existingProducts: List<ProductEntity>,
    onDismiss: () -> Unit,
    onAddProduct: (name: String, qty: Double, unit: String, price: Double, barcode: String, notes: String) -> Unit
) {
    var barcodeInput by remember { mutableStateOf("6221000123456") }
    var searched by remember { mutableStateOf(true) }
    var matchedProduct by remember { mutableStateOf<ProductEntity?>(null) }

    // New product form fallback
    var newName by remember { mutableStateOf("") }
    var newQtyText by remember { mutableStateOf("1") }
    var newUnit by remember { mutableStateOf("قطعة") }
    var newPriceText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    fun searchBarcode(code: String) {
        val found = existingProducts.firstOrNull { it.barcode == code }
        matchedProduct = found
        if (found != null) {
            newName = found.name
            newUnit = found.defaultUnit
            newPriceText = if (found.lastPrice > 0) found.lastPrice.toString() else ""
        }
        searched = true
    }

    LaunchedEffect(barcodeInput) {
        searchBarcode(barcodeInput)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("📦 إضافة منتج بالباركود — Barcode Scan")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "وجّه الكاميرا أو أدخل الباركود للتعرف التلقائي على المنتج:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = barcodeInput,
                    onValueChange = {
                        barcodeInput = it
                        searchBarcode(it)
                    },
                    label = { Text("رقم الباركود (EAN / UPC)") },
                    trailingIcon = {
                        Icon(imageVector = Icons.Default.CameraAlt, contentDescription = "كاميرا")
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (matchedProduct != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "✅ تم التعرف على المنتج في قاعدة MR7:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = matchedProduct!!.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "🆕 منتج جديد: سيتم حفظ بياناته تلقائيًا في قاعدة منتجات MR7 لاستخدامه مستقبلًا",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("اسم المنتج") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newQtyText,
                        onValueChange = { newQtyText = it },
                        label = { Text("الكمية") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = newUnit,
                        onValueChange = { newUnit = it },
                        label = { Text("الوحدة") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = newPriceText,
                    onValueChange = { newPriceText = it },
                    label = { Text("السعر التقديري (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("📝 ملاحظات (مثال: طازج، الحجم الكبير)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qVal = newQtyText.toDoubleOrNull() ?: 1.0
                    val pVal = newPriceText.toDoubleOrNull() ?: 0.0
                    onAddProduct(
                        newName.trim(),
                        qVal,
                        newUnit,
                        pVal,
                        barcodeInput.trim(),
                        notes.trim()
                    )
                },
                enabled = newName.isNotBlank()
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("إضافة للقائمة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartVoiceDialog(
    existingProducts: List<ProductEntity>,
    onDismiss: () -> Unit,
    onConfirmAdd: (List<ParsedVoiceItem>) -> Unit
) {
    var spokenText by remember {
        mutableStateOf("")
    }

    var parsedItems by remember { mutableStateOf<List<ParsedVoiceItem>>(emptyList()) }

    LaunchedEffect(spokenText) {
        parsedItems = SmartVoiceParser.parseVoiceCommand(spokenText, existingProducts)
    }

    val sampleVoiceCommands = listOf(
        "اسم المنتج + الكمية (مثال: طماطم 2 كيلو)",
        "اذكر عدة منتجات معاً في جملة واحدة"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🎤 إضافة المنتجات بالصوت — Smart Voice",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "يمكنك التحدث بالعربية أو اختيار جملة صوتية للتجربة السريعة:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Voice usage tips
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    sampleVoiceCommands.forEach { cmd ->
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "💡 $cmd",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = spokenText,
                    onValueChange = { spokenText = it },
                    label = { Text("النص المسموع (Voice Command)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    textStyle = MaterialTheme.typography.bodySmall
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "العناصر المستخرجة تلقائيًا (${parsedItems.size}):",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(parsedItems, key = { it.id }) { item ->
                        VoiceItemCard(
                            item = item,
                            onUpdate = { updated ->
                                parsedItems = parsedItems.map { if (it.id == updated.id) updated else it }
                            },
                            onDelete = {
                                parsedItems = parsedItems.filter { it.id != item.id }
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val selected = parsedItems.filter { it.isSelected && it.name.isNotBlank() }
                            onConfirmAdd(selected)
                        },
                        enabled = parsedItems.any { it.isSelected && it.name.isNotBlank() },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة للقائمة (${parsedItems.count { it.isSelected }})")
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

@Composable
fun VoiceItemCard(
    item: ParsedVoiceItem,
    onUpdate: (ParsedVoiceItem) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isSelected)
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Checkbox(
                    checked = item.isSelected,
                    onCheckedChange = { ch -> onUpdate(item.copy(isSelected = ch)) }
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        if (item.matchedProduct != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "✔ MR7",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    if (item.notes.isNotBlank()) {
                        Text(
                            text = "📝 ${item.notes}",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${item.quantity} ${item.unit}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ShareListDialog(
    listTitle: String,
    itemsCount: Int,
    purchasedCount: Int,
    formattedShareText: String,
    onDismiss: () -> Unit
) {
    var shareMethod by remember { mutableStateOf("WHATSAPP") } // WHATSAPP, DIRECT_LINK, MR7_SYNC
    val shareUrl = "https://mr7-shopping.app/share/list/${java.util.UUID.randomUUID().toString().take(8)}"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("👨👩👦 مشاركة قائمة المشتريات — MR7 Share")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "مشاركة قائمة: «$listTitle» ($purchasedCount / $itemsCount تم شراؤه)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )

                // Share Method selection
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = shareMethod == "WHATSAPP",
                        onClick = { shareMethod = "WHATSAPP" },
                        label = { Text("نص منسق (واتساب)") },
                        leadingIcon = { Icon(Icons.Default.TextSnippet, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    FilterChip(
                        selected = shareMethod == "DIRECT_LINK",
                        onClick = { shareMethod = "DIRECT_LINK" },
                        label = { Text("رابط مباشر") },
                        leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                if (shareMethod == "WHATSAPP") {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "معاينة الرسالة المشاركة:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = formattedShareText,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 8
                            )
                        }
                    }
                } else {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "🔗 رابط المشاركة المباشر:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = shareUrl,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "يمكن لأفراد العائلة فتح الرابط ومتابعة حالة المشتريات والملاحظات في الوقت الفعلي.",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onDismiss() },
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("إرسال ومشاركة الآن")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

@Composable
fun SmartQuickActionBar(
    onOcrClick: () -> Unit,
    onBarcodeClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onShareClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SmartActionChip(
                text = "📸 ورقة OCR",
                icon = Icons.Default.CameraAlt,
                color = MaterialTheme.colorScheme.primary,
                onClick = onOcrClick
            )
            SmartActionChip(
                text = "📦 باركود",
                icon = Icons.Default.QrCodeScanner,
                color = MaterialTheme.colorScheme.secondary,
                onClick = onBarcodeClick
            )
            SmartActionChip(
                text = "🎤 صوت",
                icon = Icons.Default.Mic,
                color = MaterialTheme.colorScheme.tertiary,
                onClick = onVoiceClick
            )
            SmartActionChip(
                text = "👨👩👦 مشاركة",
                icon = Icons.Default.Share,
                color = MaterialTheme.colorScheme.primary,
                onClick = onShareClick
            )
        }
    }
}

@Composable
fun SmartActionChip(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = color
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreDialog(
    onDismiss: () -> Unit,
    onExport: ((String) -> Unit) -> Unit,
    onImport: (String, (Boolean) -> Unit) -> Unit
) {
    var mode by remember { mutableStateOf("EXPORT") } // EXPORT, IMPORT
    var exportedJsonText by remember { mutableStateOf("") }
    var importJsonText by remember { mutableStateOf("") }
    var isBusy by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf("") }

    LaunchedEffect(mode) {
        if (mode == "EXPORT" && exportedJsonText.isEmpty()) {
            isBusy = true
            onExport { json ->
                exportedJsonText = json
                isBusy = false
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CloudSync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("☁️ النسخ الاحتياطي والاسترجاع — MR7 Cloud & Backup")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = mode == "EXPORT",
                        onClick = { mode = "EXPORT" },
                        label = { Text("📤 أخذ نسخة احتياطية (Export)") }
                    )
                    FilterChip(
                        selected = mode == "IMPORT",
                        onClick = { mode = "IMPORT" },
                        label = { Text("📥 استعادة البيانات (Restore)") }
                    )
                }

                if (mode == "EXPORT") {
                    Text(
                        text = "يحتوي ملف النسخة الاحتياطية على جميع المنتجات، المتاجر، الأقسام، القوائم، الملاحظات والأسعار:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isBusy) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    } else {
                        OutlinedTextField(
                            value = exportedJsonText,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("ملف النسخة الاحتياطية (MR7 Backup JSON)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            textStyle = MaterialTheme.typography.labelSmall
                        )
                    }
                } else {
                    Text(
                        text = "الصق نص النسخة الاحتياطية (JSON) هنا لاسترجاع كافة البيانات دون حذف بياناتك الحالية:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = importJsonText,
                        onValueChange = { importJsonText = it },
                        label = { Text("لصق نص النسخة الاحتياطية هنا") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        textStyle = MaterialTheme.typography.labelSmall
                    )
                }

                if (statusMsg.isNotEmpty()) {
                    Text(
                        text = statusMsg,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (statusMsg.contains("نجاح")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            if (mode == "IMPORT") {
                Button(
                    onClick = {
                        if (importJsonText.isNotBlank()) {
                            isBusy = true
                            onImport(importJsonText) { success ->
                                isBusy = false
                                statusMsg = if (success) "✅ تمت استعادة كافة بيانات MR7 بنجاح" else "❌ حدث خطأ في تحليل ملف النسخة الاحتياطية"
                            }
                        }
                    },
                    enabled = importJsonText.isNotBlank() && !isBusy,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Restore, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("استعادة البيانات الآن")
                }
            } else {
                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("تم")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

