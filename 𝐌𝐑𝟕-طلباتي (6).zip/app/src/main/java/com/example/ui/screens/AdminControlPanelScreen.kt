package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.AdminLogEntity
import com.example.data.local.entity.AdminNotificationEntity
import com.example.data.local.entity.UserEntity
import com.example.data.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminControlPanelScreen(
    viewModel: MainViewModel,
    currentUser: UserEntity,
    onBack: () -> Unit
) {
    val isUnlocked by viewModel.isAdminPanelUnlocked.collectAsState()

    var passwordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var isChecking by remember { mutableStateOf(false) }

    // Check if Super Admin (777)
    val isSuperAdmin = currentUser.id == 777L || currentUser.role == "SUPER_ADMIN"

    // If locked, show Password Screen first
    if (!isUnlocked) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "🛡️ لوحة تحكم الأدمن — MR7",
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                )
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🎩", fontSize = 36.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "🔐 كلمة سر لوحة تحكم الأدمن",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "هذه كلمة سر مستقلة تمامًا ومشفرة لحماية الإعدادات والعمليات الإدارية في نظام MR7.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = {
                                passwordInput = it
                                errorMessage = ""
                            },
                            label = { Text("كلمة سر لوحة التحكم") },
                            placeholder = { Text("أدخل كلمة المرور الخاصة بلوحة التحكم") },
                            singleLine = true,
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "إظهار/إخفاء"
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )

                        if (errorMessage.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = errorMessage,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                if (passwordInput.isBlank()) {
                                    errorMessage = "يرجى إدخال كلمة سر لوحة التحكم"
                                    return@Button
                                }
                                isChecking = true
                                viewModel.verifyAdminPanelPassword(passwordInput) { success ->
                                    isChecking = false
                                    if (!success) {
                                        errorMessage = "🚨 كلمة سر لوحة التحكم غير صحيحة"
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            enabled = !isChecking
                        ) {
                            if (isChecking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = "دخول إلى لوحة التحكم 🛡️",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
        return
    }

    // --- MAIN ADMIN CONTROL PANEL TABS ---
    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = remember(isSuperAdmin) {
        if (isSuperAdmin) {
            listOf("📊 الإحصائيات", "👥 المستخدمون", "🔔 الإشعارات", "📜 السجل", "👑 إدارة الأدمنز")
        } else {
            listOf("📊 الإحصائيات", "👥 المستخدمون", "🔔 الإشعارات", "📜 السجل")
        }
    }

    // Refresh stats when opening panel
    LaunchedEffect(Unit) {
        viewModel.refreshAdminStatistics()
    }

    val stats by viewModel.adminStatistics.collectAsState()
    val allUsers by viewModel.adminUsersList.collectAsState()
    val allAdmins by viewModel.adminAdminsList.collectAsState()
    val adminLogs by viewModel.adminLogsList.collectAsState()
    val adminNotifications by viewModel.adminNotificationsList.collectAsState()

    // State for ban modal
    var banTargetUser by remember { mutableStateOf<UserEntity?>(null) }
    // State for user detail modal
    var selectedUserDetail by remember { mutableStateOf<UserEntity?>(null) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("🛡️ لوحة تحكم الأدمن — MR7", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Badge(containerColor = if (isSuperAdmin) Color(0xFFFFD700) else MaterialTheme.colorScheme.primary) {
                                Text(
                                    text = if (isSuperAdmin) "777 SUPER" else "ADMIN",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            viewModel.logoutAdminPanel()
                            onBack()
                        }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "خروج")
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.refreshAdminStatistics() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "تحديث")
                        }
                        IconButton(onClick = {
                            viewModel.logoutAdminPanel()
                            onBack()
                        }) {
                            Icon(Icons.Default.Lock, contentDescription = "قفل اللوحة", tint = MaterialTheme.colorScheme.error)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                )

                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTabIndex) {
                0 -> AdminStatisticsTab(stats = stats)
                1 -> AdminUsersTab(
                    users = allUsers,
                    currentAdmin = currentUser,
                    onSelectUser = { selectedUserDetail = it },
                    onBanClick = { banTargetUser = it }
                )
                2 -> AdminNotificationsTab(
                    notifications = adminNotifications,
                    onUserClick = { userId ->
                        viewModel.getUserByIdForAdmin(userId) { user ->
                            if (user != null) {
                                selectedUserDetail = user
                            }
                        }
                    },
                    onDeleteNotification = { viewModel.deleteAdminNotification(it) },
                    onMarkAllRead = { viewModel.markAllAdminNotificationsRead() }
                )
                3 -> AdminLogsTab(logs = adminLogs)
                4 -> if (isSuperAdmin) {
                    AdminManagementTab(
                        admins = allAdmins,
                        currentSuperAdmin = currentUser,
                        onAddAdmin = { n, e, l, c -> viewModel.addAdmin(n, e, l, c) { _, _ -> } },
                        onUpdateAdmin = { id, n, e, l, c -> viewModel.updateAdmin(id, n, e, l, c) { _, _ -> } },
                        onRemoveAdmin = { id -> viewModel.removeAdmin(id) { _, _ -> } }
                    )
                }
            }
        }
    }

    // Ban / Unban Modal
    if (banTargetUser != null) {
        BanUserDialog(
            user = banTargetUser!!,
            currentAdmin = currentUser,
            onDismiss = { banTargetUser = null },
            onConfirmBan = { isPermanent, banDays, reason ->
                viewModel.banUser(banTargetUser!!.id, isPermanent, banDays, reason) { _, _ ->
                    banTargetUser = null
                }
            },
            onConfirmUnban = {
                viewModel.unbanUser(banTargetUser!!.id) { _, _ ->
                    banTargetUser = null
                }
            }
        )
    }

    // User Details Modal
    if (selectedUserDetail != null) {
        UserDetailsDialog(
            user = selectedUserDetail!!,
            currentAdmin = currentUser,
            onDismiss = { selectedUserDetail = null },
            onBanClick = {
                val target = selectedUserDetail
                selectedUserDetail = null
                banTargetUser = target
            }
        )
    }
}

// --- STATS TAB ---
@Composable
fun AdminStatisticsTab(stats: Map<String, Any>) {
    val totalUsers = (stats["totalUsers"] as? Int) ?: 0
    val activeUsers = (stats["activeUsers"] as? Int) ?: 0
    val bannedUsers = (stats["bannedUsers"] as? Int) ?: 0
    val adminCount = (stats["adminCount"] as? Int) ?: 0
    val dailyNew = (stats["dailyNew"] as? Int) ?: 0
    val weeklyNew = (stats["weeklyNew"] as? Int) ?: 0
    val monthlyNew = (stats["monthlyNew"] as? Int) ?: 0

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "👑 MR7 ON TOP 111 — إحصائيات النظام",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ملخص مباشر لحسابات المستخدمين، حالات الحظر، ونمو التسجيل في التطبيق.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AdminStatCard(
                    icon = "👥",
                    title = "إجمالي المستخدمين",
                    value = totalUsers.toString(),
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    icon = "🟢",
                    title = "المستخدمون النشطون",
                    value = activeUsers.toString(),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AdminStatCard(
                    icon = "🚫",
                    title = "المستخدمون المحظورون",
                    value = bannedUsers.toString(),
                    modifier = Modifier.weight(1f),
                    valueColor = MaterialTheme.colorScheme.error
                )
                AdminStatCard(
                    icon = "🛡️",
                    title = "عدد الأدمنز في النظام",
                    value = adminCount.toString(),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Text(
                text = "📈 إحصائيات التسجيل والنمو",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("📅 التسجيلات الجديدة اليوم (24 ساعة):", fontWeight = FontWeight.Medium)
                        Text("$dailyNew مستخدم", fontWeight = FontWeight.Bold)
                    }
                    Divider()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("📅 التسجيلات خلال الأسبوع (7 أيام):", fontWeight = FontWeight.Medium)
                        Text("$weeklyNew مستخدم", fontWeight = FontWeight.Bold)
                    }
                    Divider()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("📅 التسجيلات خلال الشهر (30 يوم):", fontWeight = FontWeight.Medium)
                        Text("$monthlyNew مستخدم", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    icon: String,
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, fontSize = 28.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        }
    }
}

// --- USERS LIST AND SEARCH TAB ---
@Composable
fun AdminUsersTab(
    users: List<UserEntity>,
    currentAdmin: UserEntity,
    onSelectUser: (UserEntity) -> Unit,
    onBanClick: (UserEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterStatus by remember { mutableStateOf("ALL") } // ALL, ACTIVE, BANNED, ADMINS

    val filteredUsers = remember(users, searchQuery, filterStatus) {
        users.filter { user ->
            val matchesSearch = if (searchQuery.isBlank()) {
                true
            } else {
                val q = searchQuery.trim()
                user.id.toString().contains(q) ||
                        user.name.contains(q, ignoreCase = true) ||
                        user.email.contains(q, ignoreCase = true)
            }

            val matchesStatus = when (filterStatus) {
                "ACTIVE" -> user.status == "ACTIVE"
                "BANNED" -> user.status == "BANNED" || user.status == "TEMP_BANNED"
                "ADMINS" -> user.role == "SUPER_ADMIN" || user.role == "ADMIN"
                else -> true
            }

            matchesSearch && matchesStatus
        }.sortedByDescending { it.createdAt }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search & Filter header
        Card(
            shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("🔎 البحث بالـ ID أو الاسم أو الإيميل") },
                    placeholder = { Text("ابحث بالمعرف أو الاسم أو البريد الإلكتروني...") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = filterStatus == "ALL",
                        onClick = { filterStatus = "ALL" },
                        label = { Text("الكل (${users.size})") }
                    )
                    FilterChip(
                        selected = filterStatus == "ACTIVE",
                        onClick = { filterStatus = "ACTIVE" },
                        label = { Text("🟢 نشط") }
                    )
                    FilterChip(
                        selected = filterStatus == "BANNED",
                        onClick = { filterStatus = "BANNED" },
                        label = { Text("🚫 محظور") }
                    )
                    FilterChip(
                        selected = filterStatus == "ADMINS",
                        onClick = { filterStatus = "ADMINS" },
                        label = { Text("🛡️ أدمنز") }
                    )
                }
            }
        }

        if (filteredUsers.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "لا يوجد مستخدمين مطابقين للبحث",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredUsers, key = { it.id }) { user ->
                    UserCardItem(
                        user = user,
                        currentAdmin = currentAdmin,
                        onClick = { onSelectUser(user) },
                        onBanClick = { onBanClick(user) }
                    )
                }
            }
        }
    }
}

@Composable
fun UserCardItem(
    user: UserEntity,
    currentAdmin: UserEntity,
    onClick: () -> Unit,
    onBanClick: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale("ar")) }
    val isSuper = user.id == 777L || user.role == "SUPER_ADMIN"
    val isAdmin = user.role == "ADMIN"
    val isBanned = user.status == "BANNED" || user.status == "TEMP_BANNED"

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isBanned) {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
            } else if (isSuper) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isSuper) "👑" else if (isAdmin) "🛡️" else user.avatarUri,
                    fontSize = 24.sp
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = user.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (isSuper) {
                        Badge(containerColor = Color(0xFFFFD700)) {
                            Text("777 Super Admin", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    } else if (isAdmin) {
                        Badge(containerColor = MaterialTheme.colorScheme.primary) {
                            Text("Admin", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Text(
                    text = "📧 ${user.email}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "🆔 ID: ${user.id}  •  📅 ${dateFormat.format(Date(user.createdAt))}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    if (isBanned) {
                        Text(
                            text = if (user.status == "BANNED") "🚫 محظور دائمًا" else "⏳ محظور مؤقتًا",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    } else {
                        Text(
                            text = "🟢 نشط",
                            color = Color(0xFF2E7D32),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Action button (Ban/Unban)
            if (user.id != 777L) {
                // Check if currentAdmin can manage this user
                val canManage = currentAdmin.role == "SUPER_ADMIN" ||
                        (currentAdmin.role == "ADMIN" && user.role == "USER")

                if (canManage) {
                    IconButton(
                        onClick = onBanClick,
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                color = if (isBanned) Color(0xFF2E7D32).copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer,
                                shape = CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = if (isBanned) Icons.Default.CheckCircle else Icons.Default.Block,
                            contentDescription = if (isBanned) "فك الحظر" else "حظر",
                            tint = if (isBanned) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

// --- BAN USER / UNBAN MODAL ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BanUserDialog(
    user: UserEntity,
    currentAdmin: UserEntity,
    onDismiss: () -> Unit,
    onConfirmBan: (isPermanent: Boolean, banDays: Int?, reason: String) -> Unit,
    onConfirmUnban: () -> Unit
) {
    val isCurrentlyBanned = user.status == "BANNED" || user.status == "TEMP_BANNED"
    var isPermanent by remember { mutableStateOf(true) }
    var banDaysText by remember { mutableStateOf("7") }
    var banReason by remember { mutableStateOf("") }
    var step by remember { mutableStateOf(1) } // 1 = enter reason/type, 2 = confirm
    var errorMessage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isCurrentlyBanned) "✅ فك الحظر عن المستخدم" else "🚫 حظر المستخدم",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("👤 الاسم: ${user.name}", fontWeight = FontWeight.Bold)
                        Text("📧 البريد: ${user.email}", style = MaterialTheme.typography.bodySmall)
                        Text("🆔 ID: ${user.id}", style = MaterialTheme.typography.bodySmall)
                        Text("🟢 الحالة الحالية: ${if (isCurrentlyBanned) "محظور (${user.banReason ?: ""})" else "نشط"}", style = MaterialTheme.typography.bodySmall)
                    }
                }

                if (isCurrentlyBanned) {
                    Text(
                        text = "هل أنت متأكد من رغبتك في فك الحظر عن هذا الحساب وإعادة تنشيطه؟",
                        style = MaterialTheme.typography.bodyMedium
                    )
                } else {
                    if (step == 1) {
                        Text("اختر نوع الحظر:", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = isPermanent,
                                onClick = { isPermanent = true },
                                label = { Text("🚫 حظر دائم") }
                            )
                            FilterChip(
                                selected = !isPermanent,
                                onClick = { isPermanent = false },
                                label = { Text("⏳ حظر مؤقت") }
                            )
                        }

                        if (!isPermanent) {
                            OutlinedTextField(
                                value = banDaysText,
                                onValueChange = { banDaysText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("عدد أيام الحظر المؤقت") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Text("✍️ اكتب سبب الحظر:", fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = banReason,
                            onValueChange = {
                                banReason = it
                                errorMessage = ""
                            },
                            placeholder = { Text("مثال: مخالفة شروط الاستخدام أو سلوك مسيء") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                        )

                        if (errorMessage.isNotEmpty()) {
                            Text(
                                text = errorMessage,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    } else {
                        // Confirmation Screen step 2
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("🚫 تأكيد الحظر؟", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                Text("👤 اسم المستخدم: ${user.name}")
                                Text("🆔 ID المستخدم: ${user.id}")
                                Text("⏳ نوع الحظر: ${if (isPermanent) "دائم" else "مؤقت (${banDaysText} أيام)"}")
                                Text("📝 سبب الحظر: ${banReason.ifBlank { "مخالفة شروط الاستخدام" }}")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (isCurrentlyBanned) {
                Button(onClick = onConfirmUnban) {
                    Text("✅ تأكيد فك الحظر")
                }
            } else {
                if (step == 1) {
                    Button(
                        onClick = {
                            if (banReason.isBlank()) {
                                errorMessage = "يرجى كتابة سبب الحظر للمستخدم"
                                return@Button
                            }
                            step = 2
                        }
                    ) {
                        Text("التالي ⬅️")
                    }
                } else {
                    Button(
                        onClick = {
                            val days = banDaysText.toIntOrNull() ?: 7
                            onConfirmBan(isPermanent, days, banReason)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("🚫 تأكيد الحظر")
                    }
                }
            }
        },
        dismissButton = {
            TextButton(onClick = {
                if (step == 2) step = 1 else onDismiss()
            }) {
                Text(if (step == 2) "السابق" else "إلغاء")
            }
        }
    )
}

// --- USER DETAILS DIALOG ---
@Composable
fun UserDetailsDialog(
    user: UserEntity,
    currentAdmin: UserEntity,
    onDismiss: () -> Unit,
    onBanClick: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale("ar")) }
    val isBanned = user.status == "BANNED" || user.status == "TEMP_BANNED"

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(user.avatarUri, fontSize = 32.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = user.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = user.email,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                Divider()

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DetailRow("🆔 رقم ID:", user.id.toString())
                    DetailRow("🟢 حالة الحساب:", if (isBanned) "محظور (${user.status})" else "نشط")
                    DetailRow("🛡️ الصلاحية:", if (user.id == 777L) "Super Admin (777)" else if (user.role == "ADMIN") "Admin" else "مستخدم عادي")
                    DetailRow("📅 تاريخ إنشاء الحساب:", dateFormat.format(Date(user.createdAt)))
                    DetailRow("📱 تاريخ أول تشغيل مسجل:", dateFormat.format(Date(user.firstLaunchAt)))
                    DetailRow("🕐 آخر نشاط مسجل:", dateFormat.format(Date(user.lastActiveAt)))

                    if (isBanned) {
                        Divider()
                        Text("📝 سبب الحظر:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        Text(user.banReason ?: "غير محدد", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        if (user.bannedBy != null) {
                            Text("👮 بواسطة: ${user.bannedBy}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                Divider()

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إغلاق")
                    }

                    if (user.id != 777L && (currentAdmin.role == "SUPER_ADMIN" || user.role == "USER")) {
                        Button(
                            onClick = onBanClick,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isBanned) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isBanned) "✅ فك الحظر" else "🚫 حظر")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

// --- ADMIN NOTIFICATIONS TAB ---
@Composable
fun AdminNotificationsTab(
    notifications: List<AdminNotificationEntity>,
    onUserClick: (Long) -> Unit,
    onDeleteNotification: (Long) -> Unit,
    onMarkAllRead: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale("ar")) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "🔔 إشعارات النظام والمستخدمين الجدد",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (notifications.isNotEmpty()) {
                TextButton(onClick = onMarkAllRead) {
                    Text("تحديد الكل كمقروء")
                }
            }
        }

        if (notifications.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "لا توجد إشعارات حالية في النظام",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(notifications, key = { it.id }) { item ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (!item.isRead) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                            } else {
                                MaterialTheme.colorScheme.surface
                            }
                        ),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onUserClick(item.userId) }
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(14.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🔔", fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    item.body,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "📅 ${dateFormat.format(Date(item.timestamp))}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onDeleteNotification(item.id) }) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "حذف الإشعار",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- ADMIN LOGS TAB ---
@Composable
fun AdminLogsTab(logs: List<AdminLogEntity>) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale("ar")) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "📜 سجل عمليات الإدارة والحظر",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (logs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "سجل العمليات الإدارية فارغ حاليًا",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(logs, key = { it.id }) { log ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(14.dp)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = log.actionType,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = dateFormat.format(Date(log.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Text(
                                text = "👤 الهدف: ${log.targetUserName} (ID: ${log.targetUserId})",
                                style = MaterialTheme.typography.bodyMedium
                            )

                            Text(
                                text = "📝 السبب: ${log.reason}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Text(
                                text = "👮 بواسطة: ${log.performedByName} [${log.performedByRole}]",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- ADMINS MANAGEMENT TAB (SUPER ADMIN 777 ONLY) ---
@Composable
fun AdminManagementTab(
    admins: List<UserEntity>,
    currentSuperAdmin: UserEntity,
    onAddAdmin: (name: String, email: String, loginPass: String, controlPass: String) -> Unit,
    onUpdateAdmin: (adminId: Long, name: String, email: String, loginPass: String?, controlPass: String?) -> Unit,
    onRemoveAdmin: (adminId: Long) -> Unit
) {
    var showAddAdminDialog by remember { mutableStateOf(false) }
    var editTargetAdmin by remember { mutableStateOf<UserEntity?>(null) }
    var confirmRemoveAdmin by remember { mutableStateOf<UserEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            shape = RoundedCornerShape(0.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFD700).copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "👑 إدارة الأدمنز — محجوز للأدمن الأساسي (ID 777)",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "يمكنك إضافة أدمنز بصلاحيات مستقلة، ولكل أدمن ID وإيميل وكلمتي سر منفصلتين.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { showAddAdminDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("➕ إضافة أدمن")
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(admins, key = { it.id }) { admin ->
                val is777 = admin.id == 777L
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (is777) Color(0xFFFFD700).copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(if (is777) Color(0xFFFFD700) else MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(if (is777) "👑" else "🛡️", fontSize = 24.sp)
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(admin.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Badge(containerColor = if (is777) Color(0xFFFFD700) else MaterialTheme.colorScheme.primary) {
                                    Text(
                                        if (is777) "777 Super Admin" else "Admin",
                                        color = if (is777) Color.Black else Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text("📧 ${admin.email}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("🆔 ID: ${admin.id}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }

                        if (!is777) {
                            Row {
                                IconButton(onClick = { editTargetAdmin = admin }) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(onClick = { confirmRemoveAdmin = admin }) {
                                    Icon(Icons.Default.Delete, contentDescription = "إزالة", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Admin Dialog
    if (showAddAdminDialog) {
        AddOrEditAdminDialog(
            admin = null,
            onDismiss = { showAddAdminDialog = false },
            onConfirm = { name, email, loginP, controlP ->
                onAddAdmin(name, email, loginP ?: "", controlP ?: "")
                showAddAdminDialog = false
            }
        )
    }

    // Edit Admin Dialog
    if (editTargetAdmin != null) {
        AddOrEditAdminDialog(
            admin = editTargetAdmin,
            onDismiss = { editTargetAdmin = null },
            onConfirm = { name, email, loginP, controlP ->
                onUpdateAdmin(editTargetAdmin!!.id, name, email, loginP, controlP)
                editTargetAdmin = null
            }
        )
    }

    // Confirm Remove Admin Dialog
    if (confirmRemoveAdmin != null) {
        AlertDialog(
            onDismissRequest = { confirmRemoveAdmin = null },
            title = { Text("🗑️ إزالة صلاحيات الأدمن", fontWeight = FontWeight.Bold) },
            text = {
                Text("هل أنت متأكد من رغبتك في إزالة حساب الأدمن (${confirmRemoveAdmin!!.name}) وتحويله إلى مستخدم عادي؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRemoveAdmin(confirmRemoveAdmin!!.id)
                        confirmRemoveAdmin = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("🗑️ إزالة الأدمن")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmRemoveAdmin = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun AddOrEditAdminDialog(
    admin: UserEntity?,
    onDismiss: () -> Unit,
    onConfirm: (name: String, email: String, loginPass: String?, controlPass: String?) -> Unit
) {
    var name by remember { mutableStateOf(admin?.name ?: "") }
    var email by remember { mutableStateOf(admin?.email ?: "") }
    var loginPass by remember { mutableStateOf("") }
    var controlPass by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val isEdit = admin != null

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (isEdit) "✏️ تعديل بيانات أدمن (${admin?.id})" else "👑 إضافة أدمن جديد",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الأدمن") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("البريد الإلكتروني") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = loginPass,
                    onValueChange = { loginPass = it },
                    label = { Text(if (isEdit) "كلمة سر الدخول الجديدة (اختياري)" else "كلمة سر تسجيل الدخول") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = controlPass,
                    onValueChange = { controlPass = it },
                    label = { Text(if (isEdit) "كلمة سر لوحة التحكم الجديدة (اختياري)" else "كلمة سر لوحة التحكم") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("إلغاء")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isBlank() || email.isBlank()) {
                                errorMessage = "يرجى ملء الاسم والبريد الإلكتروني"
                                return@Button
                            }
                            if (!isEdit && (loginPass.length < 6 || controlPass.length < 6)) {
                                errorMessage = "كلمات المرور يجب ألا تقل عن 6 أحرف"
                                return@Button
                            }
                            onConfirm(name, email, loginPass.ifBlank { null }, controlPass.ifBlank { null })
                        }
                    ) {
                        Text(if (isEdit) "حفظ التعديلات" else "إضافة الأدمن")
                    }
                }
            }
        }
    }
}
