package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.data.local.entity.ProductEntity
import com.example.data.viewmodel.MainViewModel
import com.example.ui.components.AppTopBar
import com.example.ui.components.CategoryBadge
import com.example.ui.components.CurrencyFormatter
import com.example.ui.components.CustomSearchBar
import com.example.ui.components.RtlProvider
import com.example.ui.components.StoreBadge

val StandardUnits = listOf("قطعة", "علبة", "عبوة", "كجم", "جرام", "لتر", "ربطة", "كرتونة", "كيس", "أنبوب")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductsScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit
) {
    val searchResults by viewModel.searchResults.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val categories by viewModel.categoriesState.collectAsState()
    val stores by viewModel.storesState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var productToDelete by remember { mutableStateOf<ProductEntity?>(null) }

    val context = LocalContext.current
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.setSearchQuery(spokenText)
                Toast.makeText(context, "بحث عن: $spokenText", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "𝐌𝐑𝟕 MIC")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "خاصية البحث الصوتي غير متاحة على هذا الجهاز", Toast.LENGTH_SHORT).show()
        }
    }

    RtlProvider {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = "قاعدة بيانات المنتجات",
                    onBackClick = onBackClick
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = {
                        editingProduct = null
                        showAddDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_product")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "إضافة منتج")
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                CustomSearchBar(
                    query = searchQuery,
                    onQueryChange = { viewModel.setSearchQuery(it) },
                    placeholderText = "ابحث بالاسم عن أي منتج...",
                    onVoiceClick = { launchVoiceSearch() },
                    modifier = Modifier.padding(16.dp)
                )

                if (searchResults.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isBlank()) "لا توجد منتجات مسجلة. اضغط + لإضافة منتج جديد"
                            else "لا توجد نتائج بحث تطابق \"$searchQuery\"",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(searchResults) { product ->
                            val cat = categories.find { it.id == product.categoryId }
                            val store = stores.find { it.id == product.defaultStoreId }

                            ProductItemRow(
                                product = product,
                                categoryName = cat?.name,
                                categoryColorHex = cat?.colorHex ?: "#3F51B5",
                                storeName = store?.name,
                                storeColorHex = store?.colorHex ?: "#4CAF50",
                                currency = settings.currency,
                                onEdit = {
                                    editingProduct = product
                                    showAddDialog = true
                                },
                                onDelete = {
                                    productToDelete = product
                                }
                            )
                        }
                    }
                }
            }

            if (showAddDialog) {
                ProductEditDialog(
                    product = editingProduct,
                    categories = categories,
                    stores = stores,
                    onDismiss = { showAddDialog = false },
                    onSave = { product ->
                        viewModel.saveProduct(product)
                        showAddDialog = false
                    }
                )
            }

            productToDelete?.let { product ->
                AlertDialog(
                    onDismissRequest = { productToDelete = null },
                    title = { Text("تأكيد الحذف") },
                    text = { Text("هل أنت تأكد من حذف المنتج \"${product.name}\" من قاعدة البيانات؟") },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.deleteProduct(product)
                                productToDelete = null
                            }
                        ) {
                            Text("حذف")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { productToDelete = null }) {
                            Text("إلغاء")
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun ProductItemRow(
    product: ProductEntity,
    categoryName: String?,
    categoryColorHex: String,
    storeName: String?,
    storeColorHex: String,
    currency: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!categoryName.isNullOrBlank()) {
                            CategoryBadge(categoryName = categoryName, colorHex = categoryColorHex)
                        }
                        if (!storeName.isNullOrBlank()) {
                            StoreBadge(storeName = storeName, colorHex = storeColorHex)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "آخر سعر: ${if (product.lastPrice > 0) "${CurrencyFormatter.format(product.lastPrice)} $currency" else "غير معروف"} / ${product.defaultUnit}",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            Row {
                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "تعديل",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductEditDialog(
    product: ProductEntity?,
    categories: List<com.example.data.local.entity.CategoryEntity>,
    stores: List<com.example.data.local.entity.StoreEntity>,
    onDismiss: () -> Unit,
    onSave: (ProductEntity) -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var selectedCategoryId by remember { mutableStateOf(product?.categoryId) }
    var selectedStoreId by remember { mutableStateOf(product?.defaultStoreId) }
    var unit by remember { mutableStateOf(product?.defaultUnit ?: "قطعة") }
    var lastPriceText by remember { mutableStateOf(if ((product?.lastPrice ?: 0.0) > 0) product?.lastPrice.toString() else "") }

    var catDropdownExpanded by remember { mutableStateOf(false) }
    var storeDropdownExpanded by remember { mutableStateOf(false) }
    var unitDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (product == null) "إضافة منتج لقاعدة البيانات" else "تعديل المنتج") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المنتج") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category
                Text("التصنيف:", style = MaterialTheme.typography.bodyMedium)
                ExposedDropdownMenuBox(
                    expanded = catDropdownExpanded,
                    onExpandedChange = { catDropdownExpanded = !catDropdownExpanded }
                ) {
                    val catName = categories.find { it.id == selectedCategoryId }?.name ?: "اختر التصنيف"
                    OutlinedTextField(
                        value = catName,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = catDropdownExpanded,
                        onDismissRequest = { catDropdownExpanded = false }
                    ) {
                        categories.forEach { c ->
                            DropdownMenuItem(
                                text = { Text(c.name) },
                                onClick = {
                                    selectedCategoryId = c.id
                                    // Also set default store if category has one
                                    if (c.defaultStoreId != null && selectedStoreId == null) {
                                        selectedStoreId = c.defaultStoreId
                                    }
                                    catDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Default Store
                Text("المتجر الافتراضي:", style = MaterialTheme.typography.bodyMedium)
                ExposedDropdownMenuBox(
                    expanded = storeDropdownExpanded,
                    onExpandedChange = { storeDropdownExpanded = !storeDropdownExpanded }
                ) {
                    val storeName = stores.find { it.id == selectedStoreId }?.name ?: "اختر المتجر"
                    OutlinedTextField(
                        value = storeName,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = storeDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = storeDropdownExpanded,
                        onDismissRequest = { storeDropdownExpanded = false }
                    ) {
                        stores.forEach { s ->
                            DropdownMenuItem(
                                text = { Text(s.name) },
                                onClick = {
                                    selectedStoreId = s.id
                                    storeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Unit
                Text("الوحدة الأساسية:", style = MaterialTheme.typography.bodyMedium)
                ExposedDropdownMenuBox(
                    expanded = unitDropdownExpanded,
                    onExpandedChange = { unitDropdownExpanded = !unitDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = unitDropdownExpanded,
                        onDismissRequest = { unitDropdownExpanded = false }
                    ) {
                        StandardUnits.forEach { u ->
                            DropdownMenuItem(
                                text = { Text(u) },
                                onClick = {
                                    unit = u
                                    unitDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Price
                OutlinedTextField(
                    value = lastPriceText,
                    onValueChange = { lastPriceText = it },
                    label = { Text("آخر سعر معروف (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val priceVal = lastPriceText.toDoubleOrNull() ?: 0.0
                        onSave(
                            ProductEntity(
                                id = product?.id ?: 0L,
                                name = name.trim(),
                                categoryId = selectedCategoryId,
                                defaultStoreId = selectedStoreId,
                                defaultUnit = unit.ifBlank { "قطعة" },
                                lastPrice = priceVal,
                                lastPurchasedDate = System.currentTimeMillis()
                            )
                        )
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
