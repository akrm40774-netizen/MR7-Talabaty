package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppTopBar
import com.example.ui.components.RtlProvider

data class HelpSectionItem(
    val id: String,
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val content: @Composable () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpCenterScreen(
    onBackClick: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var expandedIds by remember { mutableStateOf<Set<String>>(setOf("quick_start")) } // quick_start expanded by default

    val allSections = remember {
        listOf(
            HelpSectionItem(
                id = "quick_start",
                title = "🚀 البدء السريع",
                icon = Icons.Default.RocketLaunch,
                color = Color(0xFFE91E63)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "مرحبًا بك في تطبيق 𝐌𝐑𝟕 طلباتي! إليك خطوات سريعة ومختصرة للبدء في تنظيم مشترياتك بسهولة:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    NumberedStep(number = 1, text = "أنشئ قائمة مشتريات جديدة من الشاشة الرئيسية أو من زر الإضافة السريعة.")
                    NumberedStep(number = 2, text = "أضف المنتجات بالطريقة التي تناسبك (يدويًا، سريعًا، عبر الكاميرا OCR، بالصوت، أو بالباركود).")
                    NumberedStep(number = 3, text = "حدد الكمية والسعر التقديري عند الحاجة لمتابعة إجمالي الفاتورة.")
                    NumberedStep(number = 4, text = "استخدم المتاجر والأقسام لتنظيم المشتريات وترتيبها حسب خط سير التسوق.")
                    NumberedStep(number = 5, text = "أثناء التسوق علّم المنتجات التي تم شراؤها بالنقر على مربع الاختيار.")
                    NumberedStep(number = 6, text = "عند الانتهاء أنهِ القائمة أو احتفظ بها في الأرشيف للعودة إليها لاحقًا.")
                }
            },

            HelpSectionItem(
                id = "lists",
                title = "🛒 القوائم وإدارة المشتريات",
                icon = Icons.Default.ShoppingCart,
                color = Color(0xFF2196F3)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "تتيح لك القوائم التحكم الكامل في منتجاتك أثناء التسوق وقبله:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("إنشاء قائمة جديدة: انقر على زر (+) أو «قائمة جديدة» واكتب اسم القائمة.")
                    BulletPoint("إضافة المنتجات: اختر الإضافة اليدوية أو الذكية لإضافة العناصر داخل القائمة.")
                    BulletPoint("تعديل المنتجات: انقر على أي منتج داخل القائمة لتعديل اسمه أو وحدته أو متجره.")
                    BulletPoint("تغيير الكمية: استخدم أزرار الزيادة والنقصان أو اكتب الكمية المطلوبة مباشرة.")
                    BulletPoint("تعديل السعر: أدخل السعر ليتم احتساب الإجمالي التلقائي لمشترياتك.")
                    BulletPoint("إضافة الملاحظات: اكتب ملاحظة خاصة (مثل: «مستوية شوية»، «حجم كبير»، «ماركة معينة»).")
                    BulletPoint("تعليم المنتج كمُشترى: اضغط على علامة (✔) بجانب المنتج عند وضعه في عربة التسوق.")
                    BulletPoint("إنهاء القائمة: عند إتمام الشراء، انقر على «إنهاء القائمة» لنقلها للأرشيف أو حفظ المتبقي.")
                    BulletPoint("التعامل مع المنتجات التي لم يتم شراؤها: يمكنك نقل العناصر المتبقية لقائمة جديدة أو الاحتفاظ بها.")
                    BulletPoint("الوصول إلى القوائم القديمة: يمكنك مراجعة كافة قوائمك السابقة من قسم «الأرشيف» في أي وقت.")
                }
            },

            HelpSectionItem(
                id = "stores_categories",
                title = "🏪 المتاجر والأقسام",
                icon = Icons.Default.Store,
                color = Color(0xFF4CAF50)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "تنظيم المشتريات حسب المتاجر والأقسام يوفر عليك الوقت والجهد داخل السوبر ماركت:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("إنشاء متجر: أضف أسماء المتاجر التي تتسوق منها (مثل: سوبر ماركت، خضري، صيدلية).")
                    BulletPoint("إنشاء الأقسام: صنف المنتجات حسب أقسام السوبر ماركت (ألبان، خضروات، لحوم، منظفات).")
                    BulletPoint("ربط المنتجات بالمتاجر والأقسام: اربط كل منتج بمتجره وقسمه المفضل ليظهر مرتبًا تلقائيًا.")
                    BulletPoint("تعديل البيانات: يمكنك تعديل أسماء المتاجر والأقسام وألوانها من شاشة المتاجر والأقسام.")
                    BulletPoint("الاستفادة من حفظ المنتجات المتكرر: يتذكر التطبيق متجر وقسم المنتجات التي تشتريها دائمًا.")
                }
            },

            HelpSectionItem(
                id = "ocr",
                title = "📸 إضافة المنتجات من صورة (Smart OCR)",
                icon = Icons.Default.CameraAlt,
                color = Color(0xFF9C27B0)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "يحتوي تطبيق 𝐌𝐑𝟕 طلباتي على نظام OCR ذكي يتيح لك تصوير ورقة المشتريات واستخراج المنتجات منها تلقائيًا:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    HelpFeatureChip(text = "✔ الكتابة المطبوعة والكتابة اليدوية")
                    HelpFeatureChip(text = "✔ الخطوط المختلفة الواضحة")
                    HelpFeatureChip(text = "✔ التعرف على اللغة العربية والإنجليزية")
                    HelpFeatureChip(text = "✔ استخراج الكميات والوحدات عند وضوحها")
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "💡 مراجعة النتائج: يعرض لك التطبيق قائمة بالعناصر المستخرجة مع إمكانية التعديل، الحذف، أو تصحيح الأسماء والكميات قبل اعتماد إضافتها للقائمة.",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },

            HelpSectionItem(
                id = "barcode",
                title = "📦 إضافة بالباركود (Barcode Scan)",
                icon = Icons.Default.QrCodeScanner,
                color = Color(0xFFFF9800)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "يمكنك التعرف الفوري على المنتجات عبر باركود العبوة من خلال الخطوات التالية:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    NumberedStep(number = 1, text = "افتح خيار «إضافة بالباركود» داخل القائمة.")
                    NumberedStep(number = 2, text = "وجّه الكاميرا نحو الباركود المطبوع على المنتج.")
                    NumberedStep(number = 3, text = "انتظر التعرف عليه ومطابقته بقاعدة بيانات MR7.")
                    NumberedStep(number = 4, text = "راجع بيانات المنتج والكمية المقترحة.")
                    NumberedStep(number = 5, text = "اضغط على «إضافة للقائمة».")
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "💡 إذا لم يكن المنتج معروفًا: يتيح لك التطبيق إدخال بياناته يدويًا لمرة واحدة، وسيتم حفظ الباركود تلقائيًا في قاعدة منتجات MR7 للتعرف عليه مستقبليًا.",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },

            HelpSectionItem(
                id = "voice",
                title = "🎤 الإضافة بالصوت (Smart Voice)",
                icon = Icons.Default.Mic,
                color = Color(0xFF3F51B5)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "تتيح لك الإضافة الصوتية نطق جملة تحتوي على أكثر من منتج دفعة واحدة، وسيحاول التطبيق بذكاء تحويل الكلام إلى قائمة منتجات وكميات:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "🗣️ مثال صوتي:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "«اذكر أسماء المنتجات والكمية المطلوبة بصوتك»",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "يستطيع المستخدم مراجعة كافة المنتجات المستخرجة، تعديل كمياتها أو ملاحظاتها، ثم حفظها بضغطة واحدة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },

            HelpSectionItem(
                id = "quick_add",
                title = "⚡ الإضافة السريعة",
                icon = Icons.Default.FlashOn,
                color = Color(0xFFFFC107)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "صُممت الإضافة السريعة لتكون أسرع طريقة لإضافة منتج على الإطلاق عند عدم رغبتك في إدخال تفاصيل مطولة:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("تطلب فقط: اسم المنتج + الكمية + السعر.")
                    BulletPoint("ولا تطلب أي تفاصيل إضافية غير ضرورية، لتسجيل المشتريات في ثوانٍ.")
                }
            },

            HelpSectionItem(
                id = "in_store_mode",
                title = "📍 أنا في المتجر",
                icon = Icons.Default.Place,
                color = Color(0xFF009688)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "هذا الوضع مخصص عندما تكون متواجدًا بالفعل داخل متجر معين وترغب في التركيز على مشتريات هذا المتجر فقط:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("تظهر المنتجات الخاصة بهذا المتجر فقط.")
                    BulletPoint("تقل المشتتات والمنتجات التابعة لمتاجر أخرى.")
                    BulletPoint("يصبح التسوق أسرع وأسهل وبدون تشتت بين الرفوف.")
                }
            },

            HelpSectionItem(
                id = "store_alerts",
                title = "🔔 تنبيهات المتاجر",
                icon = Icons.Default.NotificationsActive,
                color = Color(0xFFE91E63)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "يمكن للتطبيق إرسال تنبيه ذكي عندما تقترب من متجر محفوظ لديك في القائمة، إذا كانت الميزة مفعلة في الإعدادات:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "ℹ️ تنبيه الخصوصية: يتم استخدام الموقع الجغرافي لمعرفة القرب من المتجر فقط لتذكيرك بمشترياتك، وليس لمعرفة أماكن المنتجات داخل المتجر أو تتبع حركتك.",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },

            HelpSectionItem(
                id = "share_lists",
                title = "👥 مشاركة القوائم",
                icon = Icons.Default.Share,
                color = Color(0xFF673AB7)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "يمكنك مشاركة قائمة المشتريات مع أفراد العائلة أو الأصدقاء عبر واتساب أو رابط مباشر:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("مشاركة القائمة لا تعني مشاركة جميع بيانات التطبيق؛ يتم فقط مشاركة القائمة المحددة.")
                    BulletPoint("يمكن أن تحتوي القوائم المشتركة على سجل نشاط يوضح التغييرات التي قام بها المشاركون لحظة بلحظة.")
                }
            },

            HelpSectionItem(
                id = "activity_log",
                title = "🕘 سجل النشاط",
                icon = Icons.Default.History,
                color = Color(0xFF795548)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "يظهر سجل النشاط داخل القوائم المشتركة فقط لضمان الشفافية ومتابعة التحديثات العائلية:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("يعرض من أضاف منتجًا جديدًا للقائمة.")
                    BulletPoint("يعرض من حذف منتجًا.")
                    BulletPoint("يعرض من عدّل كمية أو سعر أي عنصر.")
                    BulletPoint("يعرض من علّم على منتج كمُشترى.")
                    BulletPoint("يوضح وقت وتاريخ حدوث كل عملية بالتفصيل.")
                }
            },

            HelpSectionItem(
                id = "archive",
                title = "🗄️ الأرشيف",
                icon = Icons.Default.Archive,
                color = Color(0xFF607D8B)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "يحتفظ الأرشيف بالقوائم السابقة بدل فقدانها، ليكون مرجعًا دائمًا لمشترياتك:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("فتح قائمة قديمة والإطلاع على تفاصيلها.")
                    BulletPoint("البحث عن القوائم والمشتريات السابقة.")
                    BulletPoint("مراجعة أسعار وتاريخ عمليات الشراء.")
                    BulletPoint("إعادة استخدام قائمة سابقة أو نسخ منتجاتها لقائمة جديدة.")
                    BulletPoint("حذف القوائم نهائيًا عند الحاجة.")
                }
            },

            HelpSectionItem(
                id = "undo_restore",
                title = "↩️ التراجع والاسترجاع",
                icon = Icons.Default.Undo,
                color = Color(0xFF00BCD4)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "يوفر التطبيق حماية من التعديلات والحذف غير المقصود:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("بعض العمليات يمكن التراجع عنها فورًا إذا حدثت بالخطأ (مثال: عند حذف منتج — تظهر رسالة التراجع ↩️ تراجع).")
                    BulletPoint("إمكانية التراجع تعتمد على نوع العملية وما إذا كانت في القائمة النشطة أو السجلات.")
                }
            },

            HelpSectionItem(
                id = "backup_cloud",
                title = "☁️ النسخ الاحتياطي والاسترجاع",
                icon = Icons.Default.CloudSync,
                color = Color(0xFF2196F3)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "نظام النسخ الاحتياطي في 𝐌𝐑𝟕 طلباتي يضمن عدم ضياع بياناتك أبدًا:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("لماذا النسخ الاحتياطي مهم: لحماية منتجاتك وقوائمك وأسعارك من الضياع عند تغيير الهاتف أو إعادة تثبيت التطبيق.")
                    BulletPoint("كيف ينشئ المستخدم نسخة احتياطية: من شاشة الإعدادات أو زر المشاركة في القائمة السريعة انقر على «إنشاء نسخة احتياطية محلية (Export JSON)»، ثم انسخ الملف أو احفظه.")
                    BulletPoint("كيف يستعيد بياناته: انقر على «استعادة نسخة احتياطية (Import JSON)» والصق نص النسخة الاحتياطية لاستعادة كافة البيانات.")
                    BulletPoint("ما البيانات التي يشملها النسخ الاحتياطي: يشمل جميع المنتجات، المتاجر، الأقسام، القوائم، الملاحظات، والأسعار المسجلة في التطبيق.")
                }
            },

            HelpSectionItem(
                id = "security_lock",
                title = "🔒 الأمان والقفل",
                icon = Icons.Default.Lock,
                color = Color(0xFF3E2723)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "خصوصية قائمة مشترياتك وميزانيتك المنزلية محمية بالكامل:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BulletPoint("إمكانية حماية التطبيق باستخدام وسائل القفل المدعومة على جهازك (رمز PIN أو البصمة).")
                    BulletPoint("أهمية عدم مشاركة رمز PIN مع الآخرين للحفاظ على سرية بياناتك وقوائمك.")
                }
            },

            HelpSectionItem(
                id = "common_problems",
                title = "❓ حل المشاكل الشائعة",
                icon = Icons.Default.HelpOutline,
                color = Color(0xFFF44336)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "إليك حلول سريعة لأكثر الأسئلة والمشاكل شيوعًا:",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    FaqCard(
                        question = "الكاميرا لا تعمل؟",
                        answer = "تحقق من صلاحية الكاميرا من إعدادات الهاتف (تطبيقات -> 𝐌𝐑𝟕 طلباتي -> الأذونات)."
                    )
                    FaqCard(
                        question = "الإضافة الصوتية لا تعمل؟",
                        answer = "تحقق من صلاحية الميكروفون واتصال الإنترنت إذا كان النظام يحتاج إليه للتعرف على الصوت."
                    )
                    FaqCard(
                        question = "الباركود لم يتم التعرف عليه؟",
                        answer = "حاول تحسين الإضاءة وإبقاء الباركود داخل إطار الكاميرا، أو أدخل المنتج يدويًا لمرة واحدة ليتم حفظه بقاعدة MR7."
                    )
                    FaqCard(
                        question = "لم تظهر البيانات بعد الاسترجاع؟",
                        answer = "تحقق من اختيار النسخة الاحتياطية الصحيحة ثم أعد عملية الاستعادة وفق النظام المتاح."
                    )
                    FaqCard(
                        question = "لا تصل تنبيهات المتاجر؟",
                        answer = "تحقق من صلاحية الموقع والإشعارات ومن تفعيل ميزة التنبيهات من إعدادات التطبيق."
                    )
                }
            },

            HelpSectionItem(
                id = "contact_support",
                title = "📩 التواصل والدعم",
                icon = Icons.Default.SupportAgent,
                color = Color(0xFF009688)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "إذا واجهت أي استفسار أو مشكلة، يمكنك التواصل مع الدعم المباشر لتطبيق 𝐌𝐑𝟕 طلباتي:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.HeadsetMic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "فريق دعم 𝐌𝐑𝟕 طلباتي الرسمي",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = "💬 معرف الدعم عبر تيليجرام: @MR7_Orders_Support",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                            )
                            Text(
                                text = "🌐 بوابة مساعدة MR7: https://mr7-shopping.app/support",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                            )
                            Text(
                                text = "ملاحظة: وسيلة التواصل المحددة هنا يتم إدارتها وقابلة للتعديل من إعدادات المشروع بواسطة مطور التطبيق دون استخدام عناوين بريد وهمية.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        )
    }

    val filteredSections = remember(searchQuery, allSections) {
        if (searchQuery.isBlank()) {
            allSections
        } else {
            allSections.filter {
                it.title.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    RtlProvider {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = "🆘 مركز مساعدة 𝐌𝐑𝟕 طلباتي",
                    onBackClick = onBackClick
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(10.dp))

                // Top controls & Search
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث في مركز المساعدة (مثال: باركود، صوت، أرشيف)...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Expand / Collapse all button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الأقسام (${filteredSections.size}):",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    TextButton(
                        onClick = {
                            if (expandedIds.size == allSections.size) {
                                expandedIds = emptySet()
                            } else {
                                expandedIds = allSections.map { it.id }.toSet()
                            }
                        }
                    ) {
                        Text(if (expandedIds.size == allSections.size) "إغلاق كافة الأقسام" else "فتح كافة الأقسام")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredSections, key = { it.id }) { section ->
                        val isExpanded = expandedIds.contains(section.id)
                        ExpandableHelpSection(
                            title = section.title,
                            icon = section.icon,
                            color = section.color,
                            isExpanded = isExpanded,
                            onToggle = {
                                expandedIds = if (isExpanded) {
                                    expandedIds - section.id
                                } else {
                                    expandedIds + section.id
                                }
                            },
                            content = section.content
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExpandableHelpSection(
    title: String,
    icon: ImageVector,
    color: Color,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onToggle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = color.copy(alpha = 0.15f),
                        shape = CircleShape,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = color,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "إغلاق" else "فتح",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(12.dp))
                    content()
                }
            }
        }
    }
}

@Composable
fun NumberedStep(number: Int, text: String) {
    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = CircleShape,
            modifier = Modifier
                .size(22.dp)
                .padding(top = 1.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = "$number",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun BulletPoint(text: String) {
    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "•",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(end = 8.dp)
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun HelpFeatureChip(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 2.dp)
    )
}

@Composable
fun FaqCard(question: String, answer: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "❓ $question",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = answer,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
