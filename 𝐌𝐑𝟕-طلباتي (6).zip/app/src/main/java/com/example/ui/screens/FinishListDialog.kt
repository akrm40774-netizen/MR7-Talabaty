package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.ShoppingListItemEntity

val IncompleteReasons = listOf(
    "لم أجده",
    "لم يتبق مال",
    "لم أعد أحتاجه"
)

@Composable
fun IncompleteItemsDialog(
    incompleteItems: List<ShoppingListItemEntity>,
    onDismiss: () -> Unit,
    onConfirmed: (Map<Long, String>) -> Unit
) {
    val actionMap = remember { mutableStateMapOf<Long, String>() }

    // Set default reason for all incomplete items to "لم أجده"
    incompleteItems.forEach { item ->
        if (!actionMap.containsKey(item.id)) {
            actionMap[item.id] = IncompleteReasons[0]
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "منتجات غير مكتملة في القائمة (${incompleteItems.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "يرجى تحديد سبب عدم شراء كل منتج لترتيب نقله للقائمة القادمة:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.height(260.dp)
                ) {
                    items(incompleteItems) { item ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = item.name,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                IncompleteReasons.forEach { reason ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        RadioButton(
                                            selected = actionMap[item.id] == reason,
                                            onClick = { actionMap[item.id] = reason }
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = reason,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmed(actionMap) }
            ) {
                Text("تأكيد المتابعة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun UnknownPricesDialog(
    unknownItems: List<ShoppingListItemEntity>,
    currency: String,
    onDismiss: () -> Unit,
    onSavePrices: (List<ShoppingListItemEntity>) -> Unit
) {
    val updatedPricesMap = remember { mutableStateMapOf<Long, String>() }

    unknownItems.forEach { item ->
        if (!updatedPricesMap.containsKey(item.id)) {
            updatedPricesMap[item.id] = if (item.price > 0) item.price.toString() else ""
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إدخال الأسعار غير معروفة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "يرجى كتابة أسعار المنتجات المشتراة لإكمال الفاتورة وتحديث قاعدة البيانات:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.height(240.dp)
                ) {
                    items(unknownItems) { item ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.Bold)
                                    Text(
                                        "الكمية: ${item.quantity} ${item.unit}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                OutlinedTextField(
                                    value = updatedPricesMap[item.id] ?: "",
                                    onValueChange = { updatedPricesMap[item.id] = it },
                                    label = { Text("السعر ($currency)") },
                                    singleLine = true,
                                    modifier = Modifier.width(120.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val resolvedList = unknownItems.map { item ->
                        val p = updatedPricesMap[item.id]?.toDoubleOrNull() ?: 0.0
                        item.copy(price = p, isPriceUnknown = false)
                    }
                    onSavePrices(resolvedList)
                }
            ) {
                Text("حفظ الأسعار والفاتورة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
