package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch

import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ShoppingListEntity
import com.example.data.local.entity.ShoppingListItemEntity
import com.example.data.viewmodel.MainViewModel
import com.example.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingActiveScreen(
    listId: Long,
    viewModel: MainViewModel,
    onBackClick: () -> Unit,
    onFinishToBill: (Long) -> Unit
) {
    val items by viewModel.activeListItemsState.collectAsState()
    val categories by viewModel.categoriesState.collectAsState()
    val stores by viewModel.storesState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()

    val coroutineScope = rememberCoroutineScope()
    var activeList by remember { mutableStateOf<ShoppingListEntity?>(null) }
    var allProducts by remember { mutableStateOf<List<ProductEntity>>(emptyList()) }

    var showOcrDialog by remember { mutableStateOf(false) }
    var showBarcodeDialog by remember { mutableStateOf(false) }
    var showVoiceDialog by remember { mutableStateOf(false) }
    var showShareDialog by remember { mutableStateOf(false) }

    val cameraPermissionHandler = rememberCameraPermissionHandler(
        onPermissionGranted = { showOcrDialog = true }
    )
    val barcodePermissionHandler = rememberCameraPermissionHandler(
        onPermissionGranted = { showBarcodeDialog = true }
    )
    val audioPermissionHandler = rememberAudioPermissionHandler(
        onPermissionGranted = { showVoiceDialog = true }
    )

    LaunchedEffect(listId) {
        viewModel.selectList(listId)
        activeList = viewModel.getListById(listId)
        allProducts = viewModel.getAllProductsOnce()
    }

    // Sort Option
    var sortOption by remember { mutableStateOf(settings.defaultSortOrder) } // STORE, CATEGORY, MANUAL

    // Dialog States
    var editingItem by remember { mutableStateOf<ShoppingListItemEntity?>(null) }
    var showAddItemDialog by remember { mutableStateOf(false) }

    var showIncompleteDialog by remember { mutableStateOf(false) }
    var showUnknownPricesDialog by remember { mutableStateOf(false) }

    var pendingIncompleteMap by remember { mutableStateOf<Map<Long, String>>(emptyMap()) }

    // Progress
    val purchasedCount = items.count { it.isPurchased }
    val totalCount = items.size
    val progress = if (totalCount > 0) purchasedCount.toFloat() / totalCount else 0f

    // Total Paid Calculations
    val totalPaid = items.filter { it.isPurchased }.sumOf { it.price * it.quantity }
    val budget = activeList?.budget

    // Sorting/Grouping items
    val sortedItems = remember(items, sortOption, stores, categories) {
        when (sortOption) {
            "STORE" -> items.sortedWith(compareBy({ it.isPurchased }, { it.storeId }, { it.name }))
            "CATEGORY" -> items.sortedWith(compareBy({ it.isPurchased }, { it.categoryId }, { it.name }))
            else -> items.sortedWith(compareBy({ it.isPurchased }, { it.id }))
        }
    }

    fun initiateFinishFlow() {
        val incompleteList = items.filter { !it.isPurchased }
        if (incompleteList.isNotEmpty()) {
            showIncompleteDialog = true
        } else {
            // Check unknown prices for completed items
            val unknownItems = items.filter { it.isPurchased && (it.isPriceUnknown || it.price <= 0) }
            if (unknownItems.isNotEmpty()) {
                showUnknownPricesDialog = true
            } else {
                viewModel.finalizeList(listId, emptyMap()) { billId ->
                    onFinishToBill(billId)
                }
            }
        }
    }

    var isFinishing by remember { mutableStateOf(false) }

    LaunchedEffect(items) {
        if (items.isNotEmpty() && items.all { it.isPurchased }) {
            if (!isFinishing) {
                isFinishing = true
                initiateFinishFlow()
            }
        } else {
            isFinishing = false
        }
    }

    RtlProvider {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = activeList?.title ?: "قائمة التسوق",
                    onBackClick = onBackClick,
                    actions = {
                        IconButton(onClick = {
                            sortOption = when (sortOption) {
                                "STORE" -> "CATEGORY"
                                "CATEGORY" -> "MANUAL"
                                else -> "STORE"
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "ترتيب",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showAddItemDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_item_active")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "إضافة منتج")
                }
            },
            bottomBar = {
                Surface(
                    tonalElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Financial summary row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "المدفوع حالياً:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${CurrencyFormatter.format(totalPaid)} ${settings.currency}",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }

                            if (budget != null && budget > 0) {
                                val remaining = budget - totalPaid
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (remaining >= 0) "المتبقي من الميزانية:" else "تجاوز الميزانية بـ:",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${CurrencyFormatter.format(Math.abs(remaining))} ${settings.currency}",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (remaining >= 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                                        )
                                    )
                                }
                            }
                        }

                        // Big Finish Button
                        Button(
                            onClick = { initiateFinishFlow() },
                            enabled = items.isNotEmpty(),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_finish_shopping")
                        ) {
                            Icon(imageVector = Icons.Default.DoneAll, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إنهاء التسوق وإصدار الفاتورة",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Header Status Card (Progress Ratio)
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "نسبة الإنجاز: $purchasedCount من $totalCount منتجًا",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )

                            Text(
                                text = "الترتيب: ${
                                    when (sortOption) {
                                        "STORE" -> "حسب المتجر"
                                        "CATEGORY" -> "حسب التصنيف"
                                        else -> "ترتيب يدوي"
                                    }
                                }",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(CircleShape),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }

                // Smart Quick Action Bar (OCR, Barcode, Voice, Share)
                SmartQuickActionBar(
                    onOcrClick = {
                        coroutineScope.launch {
                            allProducts = viewModel.getAllProductsOnce()
                            cameraPermissionHandler.checkAndRequest()
                        }
                    },
                    onBarcodeClick = {
                        coroutineScope.launch {
                            allProducts = viewModel.getAllProductsOnce()
                            barcodePermissionHandler.checkAndRequest()
                        }
                    },
                    onVoiceClick = {
                        coroutineScope.launch {
                            allProducts = viewModel.getAllProductsOnce()
                            audioPermissionHandler.checkAndRequest()
                        }
                    },
                    onShareClick = { showShareDialog = true }
                )

                if (sortedItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "القائمة فارغة. اضغط على زر + لإضافة منتجات جديدة",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(sortedItems, key = { it.id }) { item ->
                            val cat = categories.find { it.id == item.categoryId }
                            val store = stores.find { it.id == item.storeId }

                            ShoppingItemRow(
                                item = item,
                                categoryName = cat?.name,
                                categoryColorHex = cat?.colorHex ?: "#3F51B5",
                                storeName = store?.name,
                                storeColorHex = store?.colorHex ?: "#4CAF50",
                                currency = settings.currency,
                                onTogglePurchased = { viewModel.toggleItemPurchased(item) },
                                onEdit = { editingItem = item },
                                onDelete = { viewModel.deleteListItem(item) }
                            )
                        }
                    }
                }
            }

            // Dialog for editing existing item
            editingItem?.let { item ->
                EditItemDialog(
                    item = item,
                    categories = categories,
                    stores = stores,
                    currency = settings.currency,
                    onDismiss = { editingItem = null },
                    onSave = { updated ->
                        viewModel.updateListItem(updated)
                        editingItem = null
                    }
                )
            }

            // Dialog for adding item on the fly
            if (showAddItemDialog) {
                AddItemOnTheFlyDialog(
                    categories = categories,
                    stores = stores,
                    currency = settings.currency,
                    onDismiss = { showAddItemDialog = false },
                    onAdd = { name, qty, unit, price, sId, cId ->
                        viewModel.addItemToActiveList(listId, name, qty, unit, price, sId, cId)
                        showAddItemDialog = false
                    }
                )
            }

            // Incomplete Items Handler Dialog
            if (showIncompleteDialog) {
                val incompleteItems = items.filter { !it.isPurchased }
                IncompleteItemsDialog(
                    incompleteItems = incompleteItems,
                    onDismiss = { showIncompleteDialog = false },
                    onConfirmed = { actionMap ->
                        pendingIncompleteMap = actionMap
                        showIncompleteDialog = false

                        val unknownItems = items.filter { it.isPurchased && (it.isPriceUnknown || it.price <= 0) }
                        if (unknownItems.isNotEmpty()) {
                            showUnknownPricesDialog = true
                        } else {
                            viewModel.finalizeList(listId, pendingIncompleteMap) { billId ->
                                onFinishToBill(billId)
                            }
                        }
                    }
                )
            }

            // Unknown Prices Handler Dialog
            if (showUnknownPricesDialog) {
                val unknownItems = items.filter { it.isPurchased && (it.isPriceUnknown || it.price <= 0) }
                UnknownPricesDialog(
                    unknownItems = unknownItems,
                    currency = settings.currency,
                    onDismiss = { showUnknownPricesDialog = false },
                    onSavePrices = { resolvedItems ->
                        resolvedItems.forEach { viewModel.updateListItem(it) }
                        showUnknownPricesDialog = false
                        viewModel.finalizeList(listId, pendingIncompleteMap) { billId ->
                            onFinishToBill(billId)
                        }
                    }
                )
            }

            // Smart OCR Dialog
            if (showOcrDialog) {
                SmartOcrReviewDialog(
                    existingProducts = allProducts,
                    onDismiss = { showOcrDialog = false },
                    onConfirmAdd = { selectedOcrItems ->
                        selectedOcrItems.forEach { ocrItem ->
                            viewModel.addSmartItemToList(
                                listId = listId,
                                name = ocrItem.name,
                                quantity = ocrItem.quantity,
                                unit = ocrItem.unit,
                                notes = ocrItem.notes
                            )
                        }
                        showOcrDialog = false
                    }
                )
            }

            // Smart Barcode Dialog
            if (showBarcodeDialog) {
                SmartBarcodeDialog(
                    existingProducts = allProducts,
                    onDismiss = { showBarcodeDialog = false },
                    onAddProduct = { name, qty, unit, price, barcode, notes ->
                        viewModel.addSmartItemToList(
                            listId = listId,
                            name = name,
                            quantity = qty,
                            unit = unit,
                            price = price,
                            barcode = barcode,
                            notes = notes
                        )
                        showBarcodeDialog = false
                    }
                )
            }

            // Smart Voice Dialog
            if (showVoiceDialog) {
                SmartVoiceDialog(
                    existingProducts = allProducts,
                    onDismiss = { showVoiceDialog = false },
                    onConfirmAdd = { selectedVoiceItems ->
                        selectedVoiceItems.forEach { voiceItem ->
                            viewModel.addSmartItemToList(
                                listId = listId,
                                name = voiceItem.name,
                                quantity = voiceItem.quantity,
                                unit = voiceItem.unit,
                                notes = voiceItem.notes
                            )
                        }
                        showVoiceDialog = false
                    }
                )
            }

            // Share List Dialog
            if (showShareDialog) {
                val formattedShare = remember(items, activeList) {
                    val sb = StringBuilder()
                    sb.appendLine("🛒 قائمة: ${activeList?.title ?: "مشتريات"}")
                    sb.appendLine("-------------------")
                    items.forEachIndexed { i, item ->
                        val check = if (item.isPurchased) "☑" else "☐"
                        sb.appendLine("$check ${i + 1}. ${item.name} — ${item.quantity} ${item.unit}")
                        if (item.notes.isNotBlank()) {
                            sb.appendLine("   📝 ملاحظة: ${item.notes}")
                        }
                    }
                    sb.appendLine("-------------------")
                    sb.appendLine("📱 تطبيق MR7 طلباتي")
                    sb.toString()
                }

                ShareListDialog(
                    listTitle = activeList?.title ?: "قائمة التسوق",
                    itemsCount = items.size,
                    purchasedCount = purchasedCount,
                    formattedShareText = formattedShare,
                    onDismiss = { showShareDialog = false }
                )
            }
        }
    }
}

@Composable
fun ShoppingItemRow(
    item: ShoppingListItemEntity,
    categoryName: String?,
    categoryColorHex: String,
    storeName: String?,
    storeColorHex: String,
    currency: String,
    onTogglePurchased: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val cardBgColor by animateColorAsState(
        targetValue = if (item.isPurchased) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        else MaterialTheme.colorScheme.surface,
        animationSpec = tween(300),
        label = "bgColor"
    )

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (item.isPurchased) 0.dp else 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTogglePurchased() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Animated Check Button
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (item.isPurchased) MaterialTheme.colorScheme.primary
                                else Color.Transparent
                            )
                            .border(
                                width = 2.dp,
                                color = if (item.isPurchased) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                shape = CircleShape
                            )
                            .clickable { onTogglePurchased() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (item.isPurchased) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "تم الشراء",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                textDecoration = if (item.isPurchased) TextDecoration.LineThrough else TextDecoration.None
                            ),
                            color = if (item.isPurchased) MaterialTheme.colorScheme.onSurfaceVariant
                            else MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (!categoryName.isNullOrBlank()) {
                                CategoryBadge(categoryName = categoryName, colorHex = categoryColorHex)
                            }
                            if (!storeName.isNullOrBlank()) {
                                StoreBadge(storeName = storeName, colorHex = storeColorHex)
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${item.quantity} ${item.unit}",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (item.price > 0) "${CurrencyFormatter.format(item.price * item.quantity)} $currency"
                            else "غير معروف",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (item.price > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }

                    IconButton(onClick = onEdit) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            // Display carried note if item was carried over
            if (!item.carriedFromListTitle.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "من قائمة: (${item.carriedFromListTitle}) — السبب: (${item.carryReason ?: "مرحّل"})",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }

            if (item.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "📝 ${item.notes}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium, fontSize = 12.sp),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (!item.barcode.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "📦 باركود: ${item.barcode}",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditItemDialog(
    item: ShoppingListItemEntity,
    categories: List<com.example.data.local.entity.CategoryEntity>,
    stores: List<com.example.data.local.entity.StoreEntity>,
    currency: String,
    onDismiss: () -> Unit,
    onSave: (ShoppingListItemEntity) -> Unit
) {
    var name by remember { mutableStateOf(item.name) }
    var qtyText by remember { mutableStateOf(item.quantity.toString()) }
    var unit by remember { mutableStateOf(item.unit) }
    var priceText by remember { mutableStateOf(if (item.price > 0) item.price.toString() else "") }
    var selectedCategoryId by remember { mutableStateOf(item.categoryId) }
    var selectedStoreId by remember { mutableStateOf(item.storeId) }

    var catDropdownExpanded by remember { mutableStateOf(false) }
    var storeDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل منتج بالقائمة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المنتج") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("الكمية") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("الوحدة") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("السعر ($currency)") },
                    placeholder = { Text("غير معروف") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selection
                ExposedDropdownMenuBox(
                    expanded = catDropdownExpanded,
                    onExpandedChange = { catDropdownExpanded = !catDropdownExpanded }
                ) {
                    val catName = categories.find { it.id == selectedCategoryId }?.name ?: "بدون تصنيف"
                    OutlinedTextField(
                        value = catName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("التصنيف") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = catDropdownExpanded,
                        onDismissRequest = { catDropdownExpanded = false }
                    ) {
                        categories.forEach { c ->
                            DropdownMenuItem(
                                text = { Text(c.name) },
                                onClick = {
                                    selectedCategoryId = c.id
                                    catDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Store selection
                ExposedDropdownMenuBox(
                    expanded = storeDropdownExpanded,
                    onExpandedChange = { storeDropdownExpanded = !storeDropdownExpanded }
                ) {
                    val storeName = stores.find { it.id == selectedStoreId }?.name ?: "بدون متجر"
                    OutlinedTextField(
                        value = storeName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("المتجر") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = storeDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = storeDropdownExpanded,
                        onDismissRequest = { storeDropdownExpanded = false }
                    ) {
                        stores.forEach { s ->
                            DropdownMenuItem(
                                text = { Text(s.name) },
                                onClick = {
                                    selectedStoreId = s.id
                                    storeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pVal = priceText.toDoubleOrNull() ?: 0.0
                    val qVal = qtyText.toDoubleOrNull() ?: 1.0
                    onSave(
                        item.copy(
                            name = name.trim(),
                            quantity = qVal,
                            unit = unit,
                            price = pVal,
                            isPriceUnknown = pVal <= 0,
                            categoryId = selectedCategoryId,
                            storeId = selectedStoreId
                        )
                    )
                },
                enabled = name.isNotBlank()
            ) {
                Text("حفظ التعديل")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddItemOnTheFlyDialog(
    categories: List<com.example.data.local.entity.CategoryEntity>,
    stores: List<com.example.data.local.entity.StoreEntity>,
    currency: String,
    onDismiss: () -> Unit,
    onAdd: (String, Double, String, Double, Long?, Long?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("قطعة") }
    var priceText by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf<Long?>(null) }
    var selectedStoreId by remember { mutableStateOf<Long?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة منتج للقائمة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المنتج") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("الكمية") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("الوحدة") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("السعر ($currency)") },
                    placeholder = { Text("غير معروف") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pVal = priceText.toDoubleOrNull() ?: 0.0
                    val qVal = qtyText.toDoubleOrNull() ?: 1.0
                    onAdd(name.trim(), qVal, unit, pVal, selectedStoreId, selectedCategoryId)
                },
                enabled = name.isNotBlank()
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
