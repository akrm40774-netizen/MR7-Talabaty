package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.PantryHistoryEntity
import com.example.data.local.entity.PantryItemEntity
import com.example.data.viewmodel.MainViewModel
import com.example.ui.components.RtlProvider
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class PantryFilterStatus {
    ALL, GOOD, LOW, OUT
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantryScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit,
    onOpenCreateListWithItems: (Long) -> Unit
) {
    val context = LocalContext.current
    val pantryItems by viewModel.pantryItemsState.collectAsState()
    val categories by viewModel.categoriesState.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterStatus by remember { mutableStateOf(PantryFilterStatus.ALL) }
    var selectedCategoryId by remember { mutableStateOf<Long?>(null) }

    // Dialog States
    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<PantryItemEntity?>(null) }
    var historyItem by remember { mutableStateOf<PantryItemEntity?>(null) }

    // Statistics Calculations
    val totalCount = pantryItems.size
    val lowStockItems = pantryItems.filter { it.currentQuantity > 0 && it.currentQuantity <= it.minLimit }
    val outOfStockItems = pantryItems.filter { it.currentQuantity == 0.0 }
    val goodStockItems = pantryItems.filter { it.currentQuantity > it.minLimit }

    // Filtered List
    val filteredItems = pantryItems.filter { item ->
        val matchesQuery = searchQuery.isBlank() || item.name.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategoryId == null || item.categoryId == selectedCategoryId
        val matchesStatus = when (selectedFilterStatus) {
            PantryFilterStatus.ALL -> true
            PantryFilterStatus.GOOD -> item.currentQuantity > item.minLimit
            PantryFilterStatus.LOW -> item.currentQuantity > 0 && item.currentQuantity <= item.minLimit
            PantryFilterStatus.OUT -> item.currentQuantity == 0.0
        }
        matchesQuery && matchesCategory && matchesStatus
    }

    RtlProvider {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "المخزون المنزلي 🏠",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "تتبع احتياجات ومخزون المنزل الذكي",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.testTag("btn_back_pantry")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = {
                        editingItem = null
                        showAddEditDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.testTag("btn_add_pantry_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "إضافة للمخزون")
                }
            }
        ) { paddingValues ->
            LazyColumn(
                contentPadding = PaddingValues(bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                // 1. DASHBOARD SUMMARY CARDS
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Total Items
                            PantryStatCard(
                                title = "إجمالي المنتجات",
                                count = "$totalCount منتج",
                                subtitle = "مسجلة بالمخزون",
                                icon = Icons.Default.Inventory2,
                                color = Color(0xFF2563EB),
                                modifier = Modifier.weight(1f)
                            )

                            // Low Stock
                            PantryStatCard(
                                title = "اقترب من النفاد",
                                count = "${lowStockItems.size} منتج",
                                subtitle = "تحتاج لتزويد",
                                icon = Icons.Default.Warning,
                                color = Color(0xFFD97706),
                                modifier = Modifier.weight(1f)
                            )

                            // Out of Stock
                            PantryStatCard(
                                title = "نفد تماماً",
                                count = "${outOfStockItems.size} منتج",
                                subtitle = "شراء فوري",
                                icon = Icons.Default.Delete,
                                color = Color(0xFFDC2626),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Auto Add Low Stock to Shopping List Quick Button
                        if (lowStockItems.isNotEmpty() || outOfStockItems.isNotEmpty()) {
                            val missingItems = lowStockItems + outOfStockItems
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "لديك ${missingItems.size} منتج ينقصك في البيت ⚠️",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF92400E)
                                            )
                                        )
                                        Text(
                                            text = "انقر لإضافتهم تلقائياً لقائمة تسوق جديدة",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFFB45309)
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.addLowStockPantryItemsToShoppingList(missingItems) { listId ->
                                                onOpenCreateListWithItems(listId)
                                            }
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                                    ) {
                                        Text("+ إضافة للتسوق", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. SEARCH & STATUS CHIP FILTERS
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Search bar
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("بحث داخل المخزون المنزلي...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Status Filters LazyRow
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                FilterChipItem(
                                    label = "الكل ($totalCount)",
                                    selected = selectedFilterStatus == PantryFilterStatus.ALL,
                                    onClick = { selectedFilterStatus = PantryFilterStatus.ALL }
                                )
                            }
                            item {
                                FilterChipItem(
                                    label = "🟢 جيدة (${goodStockItems.size})",
                                    selected = selectedFilterStatus == PantryFilterStatus.GOOD,
                                    onClick = { selectedFilterStatus = PantryFilterStatus.GOOD }
                                )
                            }
                            item {
                                FilterChipItem(
                                    label = "🟡 اقترب النفاد (${lowStockItems.size})",
                                    selected = selectedFilterStatus == PantryFilterStatus.LOW,
                                    onClick = { selectedFilterStatus = PantryFilterStatus.LOW }
                                )
                            }
                            item {
                                FilterChipItem(
                                    label = "🔴 نفد تماماً (${outOfStockItems.size})",
                                    selected = selectedFilterStatus == PantryFilterStatus.OUT,
                                    onClick = { selectedFilterStatus = PantryFilterStatus.OUT }
                                )
                            }
                        }

                        // Category Chips LazyRow
                        if (categories.isNotEmpty()) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    AssistChip(
                                        onClick = { selectedCategoryId = null },
                                        label = { Text("جميع التصنيفات") },
                                        colors = AssistChipDefaults.assistChipColors(
                                            containerColor = if (selectedCategoryId == null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                                        )
                                    )
                                }
                                items(categories) { cat ->
                                    AssistChip(
                                        onClick = { selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id },
                                        label = { Text(cat.name) },
                                        colors = AssistChipDefaults.assistChipColors(
                                            containerColor = if (selectedCategoryId == cat.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // 3. PANTRY ITEM CARDS LIST
                if (filteredItems.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("📦", fontSize = 48.sp)
                                Text(
                                    text = "لا توجد منتجات مطابقة في المخزون",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "قم بإضافة منتج جديد أو تغيير الفلتر",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(filteredItems, key = { it.id }) { item ->
                        PantryItemCard(
                            item = item,
                            categoryName = categories.find { it.id == item.categoryId }?.name ?: "عام",
                            onIncrease = {
                                viewModel.updatePantryQuantity(item.id, +1.0, actionType = "تزويد", note = "تزويد يدوي")
                            },
                            onDecrease = {
                                viewModel.updatePantryQuantity(item.id, -1.0, actionType = "استخدام", note = "استهلاك يدوي")
                            },
                            onViewHistory = {
                                historyItem = item
                            },
                            onEdit = {
                                editingItem = item
                                showAddEditDialog = true
                            },
                            onDelete = {
                                viewModel.deletePantryItem(item)
                            },
                            onAddToShoppingList = {
                                viewModel.addLowStockPantryItemsToShoppingList(listOf(item)) { listId ->
                                    onOpenCreateListWithItems(listId)
                                }
                            }
                        )
                    }
                }
            }
        }

        // ADD / EDIT PANTRY ITEM DIALOG
        if (showAddEditDialog) {
            AddEditPantryItemDialog(
                initialItem = editingItem,
                categories = categories,
                onDismiss = { showAddEditDialog = false },
                onSave = { item ->
                    if (editingItem == null) {
                        viewModel.insertPantryItem(item)
                    } else {
                        viewModel.updatePantryItem(item)
                    }
                    showAddEditDialog = false
                }
            )
        }

        // ITEM MOVEMENT HISTORY DIALOG
        if (historyItem != null) {
            PantryHistoryDialog(
                item = historyItem!!,
                historyFlow = viewModel.getPantryHistoryForItem(historyItem!!.id),
                onDismiss = { historyItem = null }
            )
        }
    }
}

@Composable
fun PantryStatCard(
    title: String,
    count: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = color.copy(alpha = 0.12f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
            Text(
                text = count,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = color
                ),
                fontSize = 15.sp
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                fontSize = 9.sp
            )
        }
    }
}

@Composable
fun FilterChipItem(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        contentColor = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
        shadowElevation = if (selected) 2.dp else 0.dp,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun PantryItemCard(
    item: PantryItemEntity,
    categoryName: String,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    onViewHistory: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onAddToShoppingList: () -> Unit
) {
    val context = LocalContext.current

    // Status Indicator
    val statusColor = when {
        item.currentQuantity == 0.0 -> Color(0xFFDC2626) // Out of stock (Red)
        item.currentQuantity <= item.minLimit -> Color(0xFFD97706) // Low stock (Yellow/Orange)
        else -> Color(0xFF059669) // Good stock (Green)
    }

    val statusBadgeText = when {
        item.currentQuantity == 0.0 -> "🔴 نفد تماماً"
        item.currentQuantity <= item.minLimit -> "🟡 اقترب من النفاد"
        else -> "🟢 الكمية جيدة"
    }

    val progress = if (item.maxLimit > 0) {
        (item.currentQuantity / item.maxLimit).toFloat().coerceIn(0f, 1f)
    } else 0.5f

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top Row: Item Name, Category, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "التصنيف: $categoryName • الحد الأدنى: ${item.minLimit.toInt()} ${item.unit}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = statusColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = statusBadgeText,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Quantity display with Progress bar
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "الكمية المتاحة: ${if (item.currentQuantity % 1.0 == 0.0) item.currentQuantity.toInt() else item.currentQuantity} ${item.unit}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    )
                    Text(
                        text = "الحد الأقصى: ${item.maxLimit.toInt()} ${item.unit}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                LinearProgressIndicator(
                    progress = { progress },
                    color = statusColor,
                    trackColor = statusColor.copy(alpha = 0.15f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape)
                )
            }

            // Quick Actions Bar (+ and - buttons and History/Edit/Delete)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quantity Incrementor / Decrementor
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onDecrease,
                        enabled = item.currentQuantity > 0,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (item.currentQuantity > 0) MaterialTheme.colorScheme.surfaceVariant else Color.LightGray.copy(alpha = 0.3f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "إنقاص الكمية",
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${if (item.currentQuantity % 1.0 == 0.0) item.currentQuantity.toInt() else item.currentQuantity}",
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    IconButton(
                        onClick = onIncrease,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "تزويد الكمية",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // History & Edit / Delete Buttons
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onViewHistory) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "السجل",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(onClick = onEdit) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "تعديل",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = Color(0xFFEF4444)
                        )
                    }
                }
            }

            // Prominent button to add to shopping list if low or out of stock
            if (item.currentQuantity <= item.minLimit) {
                Button(
                    onClick = onAddToShoppingList,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (item.currentQuantity == 0.0) Color(0xFFDC2626) else Color(0xFFD97706)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (item.currentQuantity == 0.0) "إضافة فورية لقائمة التسوق (نفد)" else "تزويد عبر قائمة التسوق",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AddEditPantryItemDialog(
    initialItem: PantryItemEntity?,
    categories: List<com.example.data.local.entity.CategoryEntity>,
    onDismiss: () -> Unit,
    onSave: (PantryItemEntity) -> Unit
) {
    var name by remember { mutableStateOf(initialItem?.name ?: "") }
    var currentQuantityStr by remember { mutableStateOf(initialItem?.currentQuantity?.toString() ?: "1.0") }
    var unit by remember { mutableStateOf(initialItem?.unit ?: "قطعة") }
    var minLimitStr by remember { mutableStateOf(initialItem?.minLimit?.toString() ?: "1.0") }
    var maxLimitStr by remember { mutableStateOf(initialItem?.maxLimit?.toString() ?: "5.0") }
    var selectedCategoryId by remember { mutableStateOf(initialItem?.categoryId) }
    var notes by remember { mutableStateOf(initialItem?.notes ?: "") }

    val commonUnits = listOf("قطعة", "كجم", "لتر", "عبوة", "علبة", "ربطة", "أنبوب")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialItem == null) "إضافة منتج للمخزون المنزلي" else "تعديل بيانات المنتج",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المنتج") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = currentQuantityStr,
                        onValueChange = { currentQuantityStr = it },
                        label = { Text("الكمية الحالية") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("الوحدة") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Quick unit selector chips
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(commonUnits) { u ->
                        AssistChip(
                            onClick = { unit = u },
                            label = { Text(u, fontSize = 11.sp) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = if (unit == u) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                            )
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = minLimitStr,
                        onValueChange = { minLimitStr = it },
                        label = { Text("الحد الأدنى 🟡") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = maxLimitStr,
                        onValueChange = { maxLimitStr = it },
                        label = { Text("الحد الأقصى") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات / مكان التخزين") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val currentQty = currentQuantityStr.toDoubleOrNull() ?: 1.0
                        val minLim = minLimitStr.toDoubleOrNull() ?: 1.0
                        val maxLim = maxLimitStr.toDoubleOrNull() ?: 10.0

                        val item = initialItem?.copy(
                            name = name.trim(),
                            currentQuantity = currentQty,
                            unit = unit.ifBlank { "قطعة" },
                            minLimit = minLim,
                            maxLimit = maxLim,
                            categoryId = selectedCategoryId,
                            notes = notes
                        ) ?: PantryItemEntity(
                            name = name.trim(),
                            currentQuantity = currentQty,
                            unit = unit.ifBlank { "قطعة" },
                            minLimit = minLim,
                            maxLimit = maxLim,
                            categoryId = selectedCategoryId,
                            notes = notes
                        )

                        onSave(item)
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun PantryHistoryDialog(
    item: PantryItemEntity,
    historyFlow: kotlinx.coroutines.flow.Flow<List<PantryHistoryEntity>>,
    onDismiss: () -> Unit
) {
    val historyList by historyFlow.collectAsState(initial = emptyList())
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("سجل حركات المنتج 🕒", fontWeight = FontWeight.Bold)
                Text(item.name, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
            }
        },
        text = {
            if (historyList.isEmpty()) {
                Text("لا توجد حركات مسجلة حتى الآن لهذا المنتج.")
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    items(historyList) { history ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${history.actionType}: ${if (history.quantityChange > 0) "+${history.quantityChange}" else "${history.quantityChange}"}",
                                        fontWeight = FontWeight.Bold,
                                        color = if (history.quantityChange >= 0) Color(0xFF059669) else Color(0xFFDC2626)
                                    )
                                    Text(
                                        text = "المجموع: ${history.newQuantity} ${item.unit}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                if (history.note.isNotBlank()) {
                                    Text(
                                        text = history.note,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = dateFormat.format(Date(history.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}
