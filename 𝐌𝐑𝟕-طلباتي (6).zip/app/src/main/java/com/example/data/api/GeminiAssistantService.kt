package com.example.data.api

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class GeneratedProduct(
    val name: String,
    val quantity: Double = 1.0,
    val unit: String = "قطعة",
    val estimatedPrice: Double = 0.0,
    val categoryName: String = "عام"
)

object GeminiAssistantService {

    suspend fun generateShoppingList(prompt: String): Result<List<GeneratedProduct>> = withContext(Dispatchers.IO) {
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(Exception("يرجى التأكد من إضافة مفتاح Gemini API في إعدادات التطبيق أو الخادم."))
            }

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.doOutput = true

            val systemPrompt = """
                أنت مساعد تسوق ذكي. يُطلب منك إنشاء قائمة تسوق بناءً على طلب المستخدم التالي: "$prompt".
                قم بالرد بـ JSON فقط يمثل مصفوفة من المنتجات دون أي نص آخر أو تنسيق markdown:
                [
                  {
                    "name": "اسم المنتج بالعربية",
                    "quantity": 1.0,
                    "unit": "كجم أو قطعة أو علبة أو لتر",
                    "estimatedPrice": 10.0,
                    "categoryName": "طعام أو خضروات أو أدوية أو منظفات أو مشروبات"
                  }
                ]
            """.trimIndent()

            val jsonBody = JSONObject().apply {
                val contentsArr = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArr = JSONArray().apply {
                            val partObj = JSONObject().apply {
                                put("text", systemPrompt)
                            }
                            put(partObj)
                        }
                        put("parts", partsArr)
                    }
                    put(contentObj)
                }
                put("contents", contentsArr)
            }

            val writer = OutputStreamWriter(conn.outputStream)
            writer.write(jsonBody.toString())
            writer.flush()
            writer.close()

            val responseCode = conn.responseCode
            if (responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                val responseText = reader.readText()
                reader.close()

                val root = JSONObject(responseText)
                val candidates = root.optJSONArray("candidates")
                val textResult = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text") ?: ""

                // Clean markdown code blocks if any
                val cleanJson = textResult.replace("```json", "").replace("```", "").trim()
                val jsonArray = JSONArray(cleanJson)
                val itemsList = mutableListOf<GeneratedProduct>()

                for (i in 0 until jsonArray.length()) {
                    val item = jsonArray.getJSONObject(i)
                    itemsList.add(
                        GeneratedProduct(
                            name = item.optString("name", "منتج"),
                            quantity = item.optDouble("quantity", 1.0),
                            unit = item.optString("unit", "قطعة"),
                            estimatedPrice = item.optDouble("estimatedPrice", 0.0),
                            categoryName = item.optString("categoryName", "عام")
                        )
                    )
                }

                Result.success(itemsList)
            } else {
                val reader = BufferedReader(InputStreamReader(conn.errorStream ?: conn.inputStream))
                val errText = reader.readText()
                reader.close()
                Result.failure(Exception("خطأ من خادم Gemini ($responseCode)"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
