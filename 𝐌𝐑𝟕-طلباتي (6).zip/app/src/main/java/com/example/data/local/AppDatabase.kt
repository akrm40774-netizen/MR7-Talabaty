package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.AdminLogDao
import com.example.data.local.dao.AdminNotificationDao
import com.example.data.local.dao.AppSettingsDao
import com.example.data.local.dao.BillDao
import com.example.data.local.dao.CategoryDao
import com.example.data.local.dao.PantryDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.ShoppingListDao
import com.example.data.local.dao.StoreDao
import com.example.data.local.dao.UserDao
import com.example.data.local.entity.AdminLogEntity
import com.example.data.local.entity.AdminNotificationEntity
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.PantryHistoryEntity
import com.example.data.local.entity.PantryItemEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ShoppingListEntity
import com.example.data.local.entity.ShoppingListItemEntity
import com.example.data.local.entity.StoreEntity
import com.example.data.local.entity.UserEntity

@Database(
    entities = [
        UserEntity::class,
        CategoryEntity::class,
        StoreEntity::class,
        ProductEntity::class,
        ShoppingListEntity::class,
        ShoppingListItemEntity::class,
        BillEntity::class,
        AppSettingsEntity::class,
        PantryItemEntity::class,
        PantryHistoryEntity::class,
        AdminLogEntity::class,
        AdminNotificationEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun categoryDao(): CategoryDao
    abstract fun storeDao(): StoreDao
    abstract fun productDao(): ProductDao
    abstract fun shoppingListDao(): ShoppingListDao
    abstract fun billDao(): BillDao
    abstract fun appSettingsDao(): AppSettingsDao
    abstract fun pantryDao(): PantryDao
    abstract fun adminLogDao(): AdminLogDao
    abstract fun adminNotificationDao(): AdminNotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mr7_talabati_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
