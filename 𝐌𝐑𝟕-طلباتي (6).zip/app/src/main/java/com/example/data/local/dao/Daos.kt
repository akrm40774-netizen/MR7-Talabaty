package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.AdminLogEntity
import com.example.data.local.entity.AdminNotificationEntity
import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.PantryHistoryEntity
import com.example.data.local.entity.PantryItemEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ShoppingListEntity
import com.example.data.local.entity.ShoppingListItemEntity
import com.example.data.local.entity.StoreEntity
import com.example.data.local.entity.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE LOWER(TRIM(email)) = LOWER(TRIM(:email)) LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users")
    suspend fun getAllUsers(): List<UserEntity>

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE role IN ('SUPER_ADMIN', 'ADMIN') ORDER BY id ASC")
    fun getAdminsFlow(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserById(id: Long): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id")
    fun getUserByIdFlow(id: Long): Flow<UserEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Delete
    suspend fun deleteUser(user: UserEntity)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories WHERE userId = :userId ORDER BY displayOrder ASC, id ASC")
    fun getAllCategories(userId: Long): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryEntity): Long

    @Update
    suspend fun updateCategory(category: CategoryEntity)

    @Delete
    suspend fun deleteCategory(category: CategoryEntity)

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getCategoryById(id: Long): CategoryEntity?

    @Query("SELECT * FROM categories WHERE userId = :userId")
    suspend fun getAllCategoriesOnce(userId: Long): List<CategoryEntity>
}

@Dao
interface StoreDao {
    @Query("SELECT * FROM stores WHERE userId = :userId ORDER BY name ASC")
    fun getAllStores(userId: Long): Flow<List<StoreEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStore(store: StoreEntity): Long

    @Update
    suspend fun updateStore(store: StoreEntity)

    @Delete
    suspend fun deleteStore(store: StoreEntity)

    @Query("SELECT * FROM stores WHERE id = :id")
    suspend fun getStoreById(id: Long): StoreEntity?

    @Query("SELECT * FROM stores WHERE userId = :userId")
    suspend fun getAllStoresOnce(userId: Long): List<StoreEntity>
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE userId = :userId ORDER BY name ASC")
    fun getAllProducts(userId: Long): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE userId = :userId ORDER BY name ASC")
    suspend fun getAllProductsOnce(userId: Long): List<ProductEntity>

    @Query("SELECT * FROM products WHERE userId = :userId AND barcode = :barcode LIMIT 1")
    suspend fun getProductByBarcode(userId: Long, barcode: String): ProductEntity?

    @Query("SELECT * FROM products WHERE userId = :userId AND name LIKE '%' || :query || '%' ORDER BY purchaseCount DESC, name ASC")
    fun searchProducts(userId: Long, query: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE userId = :userId AND LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun getProductByName(userId: Long, name: String): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: Long): ProductEntity?
}

@Dao
interface ShoppingListDao {
    @Query("SELECT * FROM shopping_lists WHERE userId = :userId ORDER BY createdDate DESC")
    fun getAllLists(userId: Long): Flow<List<ShoppingListEntity>>

    @Query("SELECT * FROM shopping_lists WHERE userId = :userId AND isFinished = 0 ORDER BY createdDate DESC")
    fun getActiveLists(userId: Long): Flow<List<ShoppingListEntity>>

    @Query("SELECT * FROM shopping_lists WHERE userId = :userId AND isFinished = 1 ORDER BY finishedDate DESC")
    fun getFinishedLists(userId: Long): Flow<List<ShoppingListEntity>>

    @Query("SELECT * FROM shopping_lists WHERE id = :id")
    suspend fun getListById(id: Long): ShoppingListEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertList(list: ShoppingListEntity): Long

    @Update
    suspend fun updateList(list: ShoppingListEntity)

    @Delete
    suspend fun deleteList(list: ShoppingListEntity)

    @Query("SELECT * FROM shopping_lists WHERE userId = :userId ORDER BY createdDate DESC")
    suspend fun getAllListsOnce(userId: Long): List<ShoppingListEntity>

    @Query("SELECT * FROM shopping_list_items WHERE userId = :userId")
    suspend fun getAllUserItemsOnce(userId: Long): List<ShoppingListItemEntity>

    // Items
    @Query("SELECT * FROM shopping_list_items WHERE listId = :listId")
    fun getItemsForList(listId: Long): Flow<List<ShoppingListItemEntity>>

    @Query("SELECT * FROM shopping_list_items WHERE listId = :listId")
    suspend fun getItemsForListOnce(listId: Long): List<ShoppingListItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: ShoppingListItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<ShoppingListItemEntity>)

    @Update
    suspend fun updateItem(item: ShoppingListItemEntity)

    @Delete
    suspend fun deleteItem(item: ShoppingListItemEntity)

    @Query("DELETE FROM shopping_list_items WHERE listId = :listId")
    suspend fun deleteItemsForList(listId: Long)
}

@Dao
interface BillDao {
    @Query("SELECT * FROM bills WHERE userId = :userId ORDER BY date DESC")
    fun getAllBills(userId: Long): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE userId = :userId ORDER BY date DESC")
    suspend fun getAllBillsOnce(userId: Long): List<BillEntity>

    @Query("SELECT * FROM bills WHERE id = :id")
    suspend fun getBillById(id: Long): BillEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: BillEntity): Long

    @Delete
    suspend fun deleteBill(bill: BillEntity)
}

@Dao
interface AppSettingsDao {
    @Query("SELECT * FROM app_settings WHERE userId = :userId")
    fun getSettingsFlow(userId: Long): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE userId = :userId")
    suspend fun getSettings(userId: Long): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: AppSettingsEntity)
}

@Dao
interface PantryDao {
    @Query("SELECT * FROM pantry_items WHERE userId = :userId ORDER BY name ASC")
    fun getAllPantryItems(userId: Long): Flow<List<PantryItemEntity>>

    @Query("SELECT * FROM pantry_items WHERE userId = :userId ORDER BY name ASC")
    suspend fun getAllPantryItemsOnce(userId: Long): List<PantryItemEntity>

    @Query("SELECT * FROM pantry_items WHERE id = :id")
    suspend fun getPantryItemById(id: Long): PantryItemEntity?

    @Query("SELECT * FROM pantry_items WHERE userId = :userId AND LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun getPantryItemByName(userId: Long, name: String): PantryItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPantryItem(item: PantryItemEntity): Long

    @Update
    suspend fun updatePantryItem(item: PantryItemEntity)

    @Delete
    suspend fun deletePantryItem(item: PantryItemEntity)

    @Query("SELECT * FROM pantry_history WHERE pantryItemId = :pantryItemId ORDER BY timestamp DESC")
    fun getPantryHistoryForItem(pantryItemId: Long): Flow<List<PantryHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPantryHistory(history: PantryHistoryEntity): Long
}

@Dao
interface AdminLogDao {
    @Query("SELECT * FROM admin_logs ORDER BY timestamp DESC")
    fun getAllLogsFlow(): Flow<List<AdminLogEntity>>

    @Query("SELECT * FROM admin_logs WHERE targetUserId = :userId ORDER BY timestamp DESC")
    fun getLogsForUser(userId: Long): Flow<List<AdminLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AdminLogEntity): Long
}

@Dao
interface AdminNotificationDao {
    @Query("SELECT * FROM admin_notifications ORDER BY timestamp DESC")
    fun getAllNotificationsFlow(): Flow<List<AdminNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AdminNotificationEntity): Long

    @Query("UPDATE admin_notifications SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("DELETE FROM admin_notifications WHERE id = :id")
    suspend fun deleteNotification(id: Long)
}


