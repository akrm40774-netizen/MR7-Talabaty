package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = false) val id: Long,
    val name: String,
    val email: String,
    val passwordHash: String,
    val avatarUri: String = "👤",
    val createdAt: Long = System.currentTimeMillis(),
    val firstLaunchAt: Long = System.currentTimeMillis(),
    val lastActiveAt: Long = System.currentTimeMillis(),
    val role: String = "USER", // "SUPER_ADMIN", "ADMIN", "USER"
    val status: String = "ACTIVE", // "ACTIVE", "BANNED", "TEMP_BANNED"
    val controlPanelPasswordHash: String? = null,
    val banReason: String? = null,
    val banStartDate: Long? = null,
    val banEndDate: Long? = null,
    val bannedBy: String? = null
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long = 0,
    val name: String,
    val colorHex: String = "#3F51B5",
    val iconName: String = "ShoppingBag",
    val displayOrder: Int = 0,
    val defaultStoreId: Long? = null
)

@Entity(tableName = "stores")
data class StoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long = 0,
    val name: String,
    val storeType: String = "سوبر ماركت",
    val colorHex: String = "#4CAF50",
    val notes: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val address: String = ""
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long = 0,
    val name: String,
    val categoryId: Long? = null,
    val defaultStoreId: Long? = null,
    val defaultUnit: String = "قطعة",
    val lastPrice: Double = 0.0,
    val lastPurchasedDate: Long = System.currentTimeMillis(),
    val purchaseCount: Int = 0,
    val barcode: String? = null,
    val notes: String = ""
)

@Entity(tableName = "shopping_lists")
data class ShoppingListEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long = 0,
    val title: String,
    val budget: Double? = null,
    val createdDate: Long = System.currentTimeMillis(),
    val finishedDate: Long? = null,
    val isFinished: Boolean = false
)

@Entity(tableName = "shopping_list_items")
data class ShoppingListItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val listId: Long,
    val userId: Long = 0,
    val productId: Long? = null,
    val name: String,
    val quantity: Double = 1.0,
    val unit: String = "قطعة",
    val price: Double = 0.0, // 0.0 means unknown price if not set
    val isPriceUnknown: Boolean = false,
    val isPurchased: Boolean = false,
    val categoryId: Long? = null,
    val storeId: Long? = null,
    val carriedFromListTitle: String? = null,
    val carryReason: String? = null,
    val notes: String = "",
    val barcode: String? = null
)

@Entity(tableName = "bills")
data class BillEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val listId: Long,
    val userId: Long = 0,
    val listTitle: String,
    val date: Long = System.currentTimeMillis(),
    val totalCost: Double,
    val paidAmount: Double,
    val budget: Double? = null,
    val remainingOrOver: Double = 0.0,
    val itemsCount: Int = 0
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val userId: Long = 0,
    val darkTheme: Boolean = false,
    val currency: String = "ج.م",
    val defaultSortOrder: String = "STORE", // STORE, CATEGORY, MANUAL
    val vibrationEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val autoStoreSwitch: Boolean = true,
    // Admin notification toggles
    val notifyNewUser: Boolean = true,
    val notifySuggestion: Boolean = true,
    val notifyRating: Boolean = true,
    val notifyMessage: Boolean = true,
    val notifyUserBanned: Boolean = true,
    val notifyFailedAdminLogin: Boolean = true,
    val notifyNewDeviceLogin: Boolean = true,
    val notifyUnauthorizedAccess: Boolean = true
)

@Entity(tableName = "pantry_items")
data class PantryItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long = 0,
    val name: String,
    val productId: Long? = null,
    val categoryId: Long? = null,
    val currentQuantity: Double = 1.0,
    val unit: String = "قطعة",
    val minLimit: Double = 1.0,
    val maxLimit: Double = 10.0,
    val lastPurchasedDate: Long = System.currentTimeMillis(),
    val lastUsedDate: Long = System.currentTimeMillis(),
    val averageConsumption: Double = 0.5, // e.g. units per week/day
    val notes: String = ""
)

@Entity(tableName = "pantry_history")
data class PantryHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pantryItemId: Long,
    val userId: Long = 0,
    val actionType: String, // "إضافة", "استخدام", "تعديل", "شراء تلقائي"
    val quantityChange: Double,
    val newQuantity: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(tableName = "admin_logs")
data class AdminLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val targetUserId: Long,
    val targetUserName: String,
    val actionType: String, // e.g. "حظر دائم", "حظر مؤقت", "فك الحظر", "إضافة أدمن", "تعديل أدمن", "إزالة أدمن"
    val reason: String,
    val performedByRole: String, // "SUPER_ADMIN" or "ADMIN"
    val performedByName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "admin_notifications")
data class AdminNotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val userName: String,
    val userEmail: String,
    val title: String,
    val body: String,
    val type: String = "NEW_USER",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)


