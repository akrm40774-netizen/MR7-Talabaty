package com.example.util

import com.example.data.local.entity.ProductEntity

data class ParsedVoiceItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    var name: String,
    var quantity: Double = 1.0,
    var unit: String = "قطعة",
    var notes: String = "",
    var isSelected: Boolean = true,
    var matchedProduct: ProductEntity? = null
)

object SmartVoiceParser {

    private val numberWordsMap = mapOf(
        "نص" to 0.5, "نصف" to 0.5, "ربع" to 0.25,
        "واحد" to 1.0, "واحده" to 1.0, "واحدة" to 1.0,
        "اتنين" to 2.0, "اثنين" to 2.0, "اثنان" to 2.0, "زوج" to 2.0,
        "تلاته" to 3.0, "ثلاثه" to 3.0, "ثلاثة" to 3.0, "تلاتة" to 3.0,
        "اربعة" to 4.0, "أربعة" to 4.0, "اربعه" to 4.0,
        "خمسة" to 5.0, "خمسا" to 5.0, "خمسه" to 5.0,
        "ستة" to 6.0, "سته" to 6.0,
        "سبعة" to 7.0, "سبعه" to 7.0,
        "ثمانية" to 8.0, "تمنية" to 8.0, "تمانية" to 8.0,
        "تسعة" to 9.0, "تسعه" to 9.0,
        "عشرة" to 10.0, "عشره" to 10.0
    )

    private val unitWords = listOf(
        "كيلو", "كجم", "جرام", "جم", "لتر", "مل", "عبوة", "علبة", "كيس", "قطعة", "حبة",
        "كرتونة", "زجاجة", "ازازة", "برطمان", "kg", "g", "l", "ml", "pack", "box"
    )

    /**
     * Parses Arabic/English spoken shopping instructions like:
     * "ضيف لبن وجبنة وسكر واتنين زيت و 3 كيلو طماطم تكون مستوية"
     * into a list of structured items.
     */
    fun parseVoiceCommand(
        spokenText: String,
        existingProducts: List<ProductEntity>
    ): List<ParsedVoiceItem> {
        var clean = spokenText.trim()
            .replace(Regex("^(?:ضيف|أضف|اضف|حط|احتاج|هات|جيب|اريد|اشتري|شراء)\\s+"), "")
            .replace(" وكمان ", " و ")
            .replace(" ثم ", " و ")
            .replace("،", " و ")
            .replace(",", " و ")
            .replace(" and ", " و ")

        val segments = clean.split(Regex("\\s+و\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        val resultList = mutableListOf<ParsedVoiceItem>()

        for (seg in segments) {
            val parsed = parseSegment(seg, existingProducts)
            if (parsed != null && parsed.name.isNotBlank()) {
                resultList.add(parsed)
            }
        }

        if (resultList.isEmpty() && clean.isNotBlank()) {
            val single = parseSegment(clean, existingProducts)
            if (single != null && single.name.isNotBlank()) {
                resultList.add(single)
            }
        }

        return resultList
    }

    private fun parseSegment(segment: String, existingProducts: List<ProductEntity>): ParsedVoiceItem? {
        var text = segment.trim()
        if (text.isEmpty()) return null

        var qty = 1.0
        var unit = "قطعة"
        var notes = ""

        // Check for trailing notes
        val noteSymbols = listOf("تكون", "يكون", "ملاحظة", "ملحوظة", "نوع", "طازج", "مستوي", "مستوية")
        for (sym in noteSymbols) {
            val idx = text.indexOf(" $sym ")
            if (idx > 0) {
                notes = text.substring(idx + 1).trim()
                text = text.substring(0, idx).trim()
                break
            }
        }

        val words = text.split(Regex("\\s+"))
        val remainingWords = mutableListOf<String>()

        var i = 0
        while (i < words.size) {
            val word = words[i]
            val num = word.replace(",", ".").toDoubleOrNull()
            if (num != null && num > 0) {
                qty = num
                if (i + 1 < words.size && isUnit(words[i + 1])) {
                    unit = normalizeUnit(words[i + 1])
                    i += 2
                    continue
                }
                i++
                continue
            } else if (numberWordsMap.containsKey(word)) {
                qty = numberWordsMap[word] ?: 1.0
                if (i + 1 < words.size && isUnit(words[i + 1])) {
                    unit = normalizeUnit(words[i + 1])
                    i += 2
                    continue
                }
                i++
                continue
            }
            remainingWords.add(word)
            i++
        }

        val itemName = remainingWords.joinToString(" ").trim()
        if (itemName.isEmpty()) return null

        val matchedProd = findBestMatch(itemName, existingProducts)
        val finalName = matchedProd?.name ?: itemName
        val finalUnit = matchedProd?.defaultUnit ?: unit

        return ParsedVoiceItem(
            name = finalName,
            quantity = qty,
            unit = finalUnit,
            notes = notes,
            isSelected = true,
            matchedProduct = matchedProd
        )
    }

    private fun isUnit(word: String): Boolean {
        val lower = word.lowercase().trim()
        return unitWords.any { lower == it || lower.startsWith(it) }
    }

    private fun normalizeUnit(word: String): String {
        val lower = word.lowercase().trim()
        return when {
            lower.contains("كيلو") -> "كيلو"
            lower.contains("جرام") -> "جرام"
            lower.contains("لتر") -> "لتر"
            lower.contains("عبو") || lower.contains("علب") -> "عبوة"
            lower.contains("كيس") -> "كيس"
            else -> word
        }
    }

    private fun findBestMatch(name: String, existingProducts: List<ProductEntity>): ProductEntity? {
        if (existingProducts.isEmpty() || name.isBlank()) return null
        val clean = normalizeText(name)
        existingProducts.firstOrNull { normalizeText(it.name) == clean }?.let { return it }
        existingProducts.firstOrNull {
            val c = normalizeText(it.name)
            c.length >= 3 && clean.length >= 3 && (c.contains(clean) || clean.contains(c))
        }?.let { return it }
        return null
    }

    private fun normalizeText(text: String): String {
        return text.trim().lowercase()
            .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
            .replace("ة", "ه").replace("ى", "ي")
            .replace(Regex("[^a-z0-9\\u0600-\\u06FF\\s]"), "")
            .replace(Regex("\\s+"), " ")
    }
}
