package com.example.util

import com.example.data.local.entity.ProductEntity

data class ParsedOcrItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    var rawText: String,
    var name: String,
    var quantity: Double = 1.0,
    var unit: String = "قطعة",
    var notes: String = "",
    var isSelected: Boolean = true,
    var confidenceScore: Float = 0.95f, // 0.0 to 1.0
    var confidenceLabel: String = "HIGH", // "HIGH", "MEDIUM", "LOW" ("⚠️ يحتاج مراجعة")
    var matchedProduct: ProductEntity? = null,
    var suggestions: List<String> = emptyList()
)

object SmartOcrParser {

    private val commonUnits = listOf(
        "كيلو", "كجم", "كغ", "جرام", "جم", "غرام",
        "لتر", "مل", "ملي", "عبوة", "علبة", "كيس",
        "قطعة", "حبة", "كرتونة", "زجاجة", "ازازة", "برطمان",
        "kg", "g", "l", "ml", "pack", "box", "piece", "pcs"
    )

    private val arabicNumberMap = mapOf(
        "نصف" to 0.5, "نص" to 0.5, "ربع" to 0.25,
        "واحد" to 1.0, "واحدة" to 1.0, "اتنين" to 2.0, "اثنان" to 2.0, "اثنين" to 2.0,
        "ثلاثة" to 3.0, "تلاتة" to 3.0, "اربعة" to 4.0, "أربعة" to 4.0,
        "خمسة" to 5.0, "ستة" to 6.0, "سبعة" to 7.0, "ثمانية" to 8.0,
        "تسعة" to 9.0, "عشرة" to 10.0
    )

    /**
     * Parse raw OCR or handwritten list text into structured items,
     * matching against existing MR7 products to prevent duplicates.
     */
    fun parseOcrText(
        rawText: String,
        existingProducts: List<ProductEntity>
    ): List<ParsedOcrItem> {
        val lines = rawText.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !isHeaderOrNoise(it) }

        return lines.map { line ->
            parseSingleLine(line, existingProducts)
        }
    }

    private fun isHeaderOrNoise(line: String): Boolean {
        val lower = line.lowercase()
        val noiseWords = listOf(
            "قائمة", "مشتريات", "الطلبات", "طلبات", "shopping", "list", "total", "المجموع",
            "date", "التاريخ", "سوبرماركت", "فاتورة"
        )
        if (line.length <= 1) return true
        return noiseWords.any { lower == it || lower == "=== $it ===" }
    }

    private fun parseSingleLine(
        rawLine: String,
        existingProducts: List<ProductEntity>
    ): ParsedOcrItem {
        var text = rawLine
            .replace(Regex("^[-*•✓✔☑️xX\\d]+[.)]?:?\\s*"), "") // remove bullets and checkmarks
            .trim()

        var quantity = 1.0
        var unit = "قطعة"
        var notes = ""

        // 1. Check for explicit notes in parentheses or after note symbols
        val noteRegex = Regex("(?:\\(|—|--|📝|ملاحظة:|ملحوظة:)(.*?)(?:\\)\$|\$)")
        val noteMatch = noteRegex.find(text)
        if (noteMatch != null) {
            notes = noteMatch.groupValues[1].trim()
            text = text.replace(noteMatch.value, "").trim()
        }

        // 2. Check for quantity and unit patterns (e.g., "2 كيلو", "3 ×", "x2")
        // Pattern A: Number + Optional Unit (e.g., "2 كيلو", "2.5 لتر", "3 كيس")
        val numUnitRegex = Regex("(\\d+(?:[.,]\\d+)?)\\s*([a-zA-Z\\u0600-\\u06FF]+)?")
        val xRegex = Regex("×\\s*(\\d+(?:[.,]\\d+)?)")
        val xMatch = xRegex.find(text)
        if (xMatch != null) {
            quantity = xMatch.groupValues[1].replace(",", ".").toDoubleOrNull() ?: 1.0
            text = text.replace(xMatch.value, "").trim()
        } else {
            // Check if line ends or starts with a number + unit
            val tokens = text.split(Regex("\\s+"))
            var remainingTokens = mutableListOf<String>()
            var i = 0
            while (i < tokens.size) {
                val token = tokens[i]
                val num = token.replace(",", ".").toDoubleOrNull()
                if (num != null && num > 0) {
                    quantity = num
                    // Check if next token is a unit
                    if (i + 1 < tokens.size && isUnitWord(tokens[i + 1])) {
                        unit = normalizeUnit(tokens[i + 1])
                        i += 2
                        continue
                    }
                    i++
                    continue
                } else if (arabicNumberMap.containsKey(token)) {
                    quantity = arabicNumberMap[token] ?: 1.0
                    if (i + 1 < tokens.size && isUnitWord(tokens[i + 1])) {
                        unit = normalizeUnit(tokens[i + 1])
                        i += 2
                        continue
                    }
                }
                remainingTokens.add(token)
                i++
            }
            if (remainingTokens.isNotEmpty()) {
                text = remainingTokens.joinToString(" ")
            }
        }

        // Clean trailing separators
        text = text.trim('-', '_', ':', '.', ',', ' ')

        // 3. Match against existing MR7 products
        val cleanName = text.trim()
        val matchedProd = findBestProductMatch(cleanName, existingProducts)

        var confScore = 0.95f
        var confLabel = "HIGH"
        var suggestions = emptyList<String>()

        if (matchedProd != null) {
            confScore = 0.98f
            confLabel = "HIGH"
            unit = matchedProd.defaultUnit
        } else {
            // Check for potential OCR typos or incomplete words (e.g. "جبنه دومـ", "سكـ")
            val fuzzySuggestions = findFuzzySuggestions(cleanName, existingProducts)
            if (fuzzySuggestions.isNotEmpty()) {
                confScore = 0.65f
                confLabel = "⚠️ يحتاج مراجعة"
                suggestions = fuzzySuggestions.map { "🧀 ${it.name}" } + listOf("✏️ إبقاء '$cleanName'")
            } else if (cleanName.length <= 2 || cleanName.contains("...")) {
                confScore = 0.50f
                confLabel = "⚠️ يحتاج مراجعة"
            }
        }

        return ParsedOcrItem(
            rawText = rawLine,
            name = matchedProd?.name ?: cleanName,
            quantity = quantity,
            unit = unit,
            notes = notes,
            isSelected = true,
            confidenceScore = confScore,
            confidenceLabel = confLabel,
            matchedProduct = matchedProd,
            suggestions = suggestions
        )
    }

    private fun isUnitWord(word: String): Boolean {
        val lower = word.lowercase().trim()
        return commonUnits.any { lower == it || lower.startsWith(it) }
    }

    private fun normalizeUnit(word: String): String {
        val lower = word.lowercase().trim()
        return when {
            lower.contains("كيلو") || lower == "كجم" || lower == "kg" -> "كيلو"
            lower.contains("جرام") || lower == "جم" || lower == "g" -> "جرام"
            lower.contains("لتر") || lower == "l" -> "لتر"
            lower.contains("عبو") || lower == "علب" || lower == "pack" -> "عبوة"
            lower.contains("كيس") -> "كيس"
            else -> word
        }
    }

    private fun findBestProductMatch(name: String, existingProducts: List<ProductEntity>): ProductEntity? {
        if (existingProducts.isEmpty() || name.isBlank()) return null
        val clean = normalizeText(name)
        // 1. Exact clean match
        existingProducts.firstOrNull { normalizeText(it.name) == clean }?.let { return it }
        // 2. Contains match if length >= 3
        existingProducts.firstOrNull {
            val prodClean = normalizeText(it.name)
            prodClean.length >= 3 && clean.length >= 3 &&
                (prodClean == clean || prodClean.contains(clean) || clean.contains(prodClean))
        }?.let { return it }
        return null
    }

    private fun findFuzzySuggestions(name: String, existingProducts: List<ProductEntity>): List<ProductEntity> {
        if (existingProducts.isEmpty() || name.isBlank()) return emptyList()
        val clean = normalizeText(name)
        return existingProducts.filter { prod ->
            val prodClean = normalizeText(prod.name)
            if (prodClean.isEmpty() || clean.isEmpty()) false
            else {
                val sim = similarity(clean, prodClean)
                sim >= 0.55 && sim < 0.99
            }
        }.take(4)
    }

    private fun normalizeText(text: String): String {
        return text.trim().lowercase()
            .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
            .replace("ة", "ه").replace("ى", "ي")
            .replace(Regex("[^a-z0-9\\u0600-\\u06FF\\s]"), "")
            .replace(Regex("\\s+"), " ")
    }

    private fun similarity(s1: String, s2: String): Double {
        val maxLen = maxOf(s1.length, s2.length)
        if (maxLen == 0) return 1.0
        val dist = levenshtein(s1, s2)
        return 1.0 - (dist.toDouble() / maxLen)
    }

    private fun levenshtein(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[s1.length][s2.length]
    }
}
