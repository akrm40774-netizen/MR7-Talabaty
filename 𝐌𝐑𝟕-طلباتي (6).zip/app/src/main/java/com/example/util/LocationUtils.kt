package com.example.util

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object LocationUtils {

    // Default reference location (Cairo Center: 30.0444° N, 31.2357° E)
    const val DEFAULT_USER_LAT = 30.0444
    const val DEFAULT_USER_LNG = 31.2357

    /**
     * Calculates distance between two latitude/longitude points in meters using Haversine formula.
     */
    fun calculateDistanceMeters(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val r = 6371000.0 // Earth radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    /**
     * Formats distance in meters or kilometers nicely in Arabic.
     */
    fun formatDistance(meters: Double): String {
        return if (meters < 1000) {
            "على بُعد ${meters.toInt()} متر"
        } else {
            val km = String.format("%.1f", meters / 1000.0)
            "على بُعد $km كم"
        }
    }

    /**
     * Returns description label based on sorted store proximity index.
     * Index 0 -> "الأقرب إلى موقعك الحالي"
     * Index 1 -> "ثاني أقرب متجر"
     * Index 2 -> "ثالث أقرب متجر"
     * etc.
     */
    fun getStoreRankLabel(index: Int): String {
        return when (index) {
            0 -> "الأقرب إلى موقعك الحالي"
            1 -> "ثاني أقرب متجر"
            2 -> "ثالث أقرب متجر"
            3 -> "رابع أقرب متجر"
            4 -> "خامس أقرب متجر"
            5 -> "سادس أقرب متجر"
            else -> "متجر رقم ${index + 1} بالقرب من موقعك"
        }
    }
}
